//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrVersion.h
///
//==================================================================================
#pragma once

// Driver version
/// \def DRIVER_VERSION The version format is:
/// [31-24]: pwr prof major, [23-16]: pwr prof minor, [15-0]: pwr prof build
#define DRIVER_VERSION 0x01000000
#define PCORE_MAJOR_VERSION  5
#define PCORE_MINOR_VERSION  4
#define PCORE_BUILD_VERSION  0
#define PWRPROF_MAJOR_VERSION  10
#define PWRPROF_MINOR_VERSION  0
#define PWRPROF_BUILD_VERSION  0

// Linux version
// Once version is changed backend and driver needs to be updated
// Major version should be changed after every release
// Minor version should be changed for any change in driver code
// Please update the version number in file located at ../Linux/AMDPowerProfilerVersion
#define LINUX_PWR_DRV_MAJOR 10
#define LINUX_PWR_DRV_MINOR 0

#define POWER_PROFILE_DRIVER_VERSION \
    DRIVER_VERSION | ((uint64)PCORE_MAJOR_VERSION << 56) | ((uint64)PCORE_MINOR_VERSION << 48) | ((uint64)PCORE_BUILD_VERSION << 32) \
    | ((uint64)PWRPROF_MAJOR_VERSION << 28) | ((uint64)PWRPROF_MINOR_VERSION << 24) | ((uint64)PWRPROF_BUILD_VERSION << 20)


#define PWRPROF_MAJOR_MASK      0xf
#define PWRPROF_MAJOR_SHIFT     28

#define PWRPROF_MINOR_MASK      0xf
#define PWRPROF_MINOR_SHIFT     24
