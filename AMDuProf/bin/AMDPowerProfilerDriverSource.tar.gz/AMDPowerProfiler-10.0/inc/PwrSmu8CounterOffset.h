//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrSmu8CounterOffset.h
///
//==================================================================================
#pragma once
#include <PwrSmu8CounterTable.h>

// This is an auto generated file. Whenever new version of this table is added by SMU,
// this table must be regenerated

CounterTableInfo CounterTableOffsetList[] =
{
    // TABLE VERSION 2
    {
        2,    // Table version
        {

            {
                40,     //T_calc_cu[0]
                44      //T_calc_cu[1]
            },
            52,     //T_calc_vddgfx
            {
                56,     //P_calc_cu[0]
                60      //P_calc_cu[1]
            },
            64,     //P_calc_vddgfx
            68,     //P_calc_vddnb
            72,     //P_calc_vddio
            76,     //P_calc_vddp
            80,     //P_calc_roc
            84,     //P_calc_apu
            88,     //P_calc_uvd
            92,     //P_calc_vce
            96,     //P_calc_acp
            100,     //P_calc_unb
            104,     //P_calc_smu
            112,     //I_calc_vdd
            120,     //I_calc_vddgfx
            128,     //I_calc_vddnb
            132,     //V_calc_vdd
            136,     //V_calc_vddgfx
            140,     //V_calc_vddnb
            368,     //Sclk_frequency
            388,     //Aclk_frequency
            {
                500,     //C0_residency[0]
                504      //C0_residency[1]
            },
            {
                508,     //C1_residency[0]
                512      //C1_residency[1]
            },
            {
                516,     //CC6_residency[0]
                520      //CC6_residency[1]
            },
            664,     //Tdp
        }
    },
    // TABLE VERSION 4
    {
        4,    // Table version
        {
            {
                40,     //T_calc_cu[0]
                44      //T_calc_cu[1]
            },
            52,     //T_calc_vddgfx
            {
                56,     //P_calc_cu[0]
                60      //P_calc_cu[1]
            },
            64,     //P_calc_vddgfx
            68,     //P_calc_vddnb
            72,     //P_calc_vddio
            76,     //P_calc_vddp
            80,     //P_calc_roc
            84,     //P_calc_apu
            88,     //P_calc_uvd
            92,     //P_calc_vce
            96,     //P_calc_acp
            100,     //P_calc_unb
            104,     //P_calc_smu
            112,     //I_calc_vdd
            120,     //I_calc_vddgfx
            128,     //I_calc_vddnb
            132,     //V_calc_vdd
            136,     //V_calc_vddgfx
            140,     //V_calc_vddnb
            348,     //Sclk_frequency
            364,     //Aclk_frequency
            {
                476,     //C0_residency[0]
                480      //C0_residency[1]
            },
            {
                484,     //C1_residency[0]
                488      //C1_residency[1]
            },
            {
                492,     //CC6_residency[0]
                496      //CC6_residency[1]
            },
            648,     //Tdp
        }
    },

};

