//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrSmu8Interface.cpp
///
//==================================================================================
#pragma once

// LOCAL INCLUDES
#include "PwrDriverTypedefs.h"

// Smu8SRBMMessage: SRBM message interface
typedef struct _Smu8SRBMMessage
{
    uint64 m_msg;                  // Message id
    uint64 m_arg;                  // Argument
    uint64 m_resp;                 // Response
    uint8  m_requestCounterTable;  // Counter table request message id
    uint8  m_releaseCounterTable;  // Counter table release message id
    uint16 m_fill[3];
} Smu8SRBMMessage;

// Smu8MMAccess: Channel-9 data index pair
typedef struct _Smu8MMAccess
{
    uint64 m_index;
    uint64 m_data;
} Smu8MMAccess;

// Smu8Interface: Access interface for Smu8
typedef struct
{
    uint64               m_gpuBaseAddr;
    uint64               m_mappedGMMMxSpace;
    uint64               m_mappedSize;
    Smu8SRBMMessage      m_srbmMsg;
    Smu8MMAccess         m_gmmxPair;
    uint64               m_tableBase;
    uint32               m_tableId;
    uint32               m_tableVersion;
} Smu8Interface;

bool FillSmu8InterfaceInfo(Smu8Interface* pSmu);

// CollectSMU8RegisterValues: Collect all SMU counterr values
// based on the mask set and fill in the pData
bool CollectSMU8RegisterValues(void* pSmu,
                               uint8* pData,
                               uint32* pLength);

// Smu8SessionInitialize:
bool Smu8SessionInitialize(void* pSmu);

// Smu8SessionClose
bool Smu8SessionClose(void* pSmu);

// GetSmu8CounterSize
uint32 GetSmu8CounterSize(uint32 counterId);

