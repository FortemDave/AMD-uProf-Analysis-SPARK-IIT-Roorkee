//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcUtils.h
///
//==================================================================================
#pragma once

#include <PmcTypes.h>
#include <PmcInterface.h>

#ifdef __cplusplus
extern "C" {
#endif

const char* GetPmcTypeString(PmcPmuType type);

uint64_t* GetCoreMaskArray(CountModeProfileConfig* pConfig,
                           PmcPmuType type);

uint64_t* GetPmcConfigArray(CountModeGroupConfig* pConfig);

PmcPmuType GetPmcType(GroupType groupType);

#ifdef __cplusplus
}
#endif