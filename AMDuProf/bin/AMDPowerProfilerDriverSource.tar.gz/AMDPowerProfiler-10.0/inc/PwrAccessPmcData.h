//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrAccessPmcData.cpp
///
//==================================================================================
#pragma once
#include <PwrProfInternal.h>
#include <PwrCommonDataTypes.h>

typedef struct PmcCounters
{
    uint32   m_controlMSR;
    uint32   m_dataMSR;
} PmcCounters;

// InitializePMCCounters
bool InitializePMCCounters(PmcCounters* pPmc);

// ReadPmcCounterData: Read PMC counter values
uint32 ReadPmcCounterData(PmcCounters* pPmc, uint64* pData);

// ResetPMCCounters: Reset PCM counter values
bool ResetPMCCounters(PmcCounters* pPmc);

// ResetPMCControl: Reset PMC counter control data
bool ResetPMCControl(PmcCounters* pPmc);

