//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcInterface.h
///
//==================================================================================
#pragma once

#include <PmcTypes.h>

#define INVALID_CLIENT_ID       0xffffffff
#define PMC_CLIENT_ID           0x1

// Maximum cores 16*64 (1024)
#define PMC_CORE_MASK_ARRAY_SIZE    16
#define PMC_CORE_MASK_BIT_WIDTH     64
#define PMC_MAX_SUPPORTED_CORES     (PMC_CORE_MASK_ARRAY_SIZE * PMC_CORE_MASK_BIT_WIDTH)

// Max fd should account for the following:
// Max per core fd
// Max per l3 complex fd
// Max per data fabric fd
#define PMC_FD_ARRAY_SIZE       512

#define MAX_CORE_PMC_COUNTERS   8 // 6 public and 2 debug counters
#define MAX_L3_PMC_COUNTERS     6 // 6 public and 0 debug counters
#define MAX_DF_PMC_COUNTERS     16 // 16 counters (4 public and 4 debug counters on Zen3 and older models)
#define MAX_UMC_PMC_COUNTERS    4 // 4 counters per UMC

/*
 * TODO: Should we compile an internal version of
 * driver with these macros defined?
 * or have a flags to enable/disable with backend
 */

#define PMC_IRPERF_MSR          0xC00000E9
#define PMC_MPERF_MSR           0x000000E7
#define PMC_APERF_MSR           0x000000E8
#define PMC_TSC_MSR             0x00000010

#define PMC_CFG_ENABLE     (1ULL << 22)

#define CORE_PMC_COUNT          6
#define CORE_PMC_CFG_BASE_MSR   0xC0010200
#define CORE_PMC_COUNT_OFFSET   0x1
#define CORE_PMC_STRIDE         0x2

#define CORE_PMC_CFG_MSR(i)     CORE_PMC_CFG_BASE_MSR + i * CORE_PMC_STRIDE
#define CORE_PMC_COUNT_MSR(i)   CORE_PMC_CFG_MSR(i) + CORE_PMC_COUNT_OFFSET

#define CHL3_PMC_COUNT          6
#define CHL3_PMC_CFG_BASE_MSR   0xC0010230
#define CHL3_PMC_COUNT_OFFSET   0x1
#define CHL3_PMC_STRIDE         0x2

#define CHL3_PMC_CFG_MSR(i)     CHL3_PMC_CFG_BASE_MSR + i * CHL3_PMC_STRIDE
#define CHL3_PMC_COUNT_MSR(i)   CHL3_PMC_CFG_MSR(i) + CHL3_PMC_COUNT_OFFSET

#define DF_PMC_COUNT            4
#define DF_PMC_CFG_BASE_MSR     0xC0010240
#define DF_PMC_COUNT_OFFSET     0x1
#define DF_PMC_STRIDE           0x2

#define DF_PMC_CFG_MSR(i)       DF_PMC_CFG_BASE_MSR + i * DF_PMC_STRIDE
#define DF_PMC_COUNT_MSR(i)     DF_PMC_CFG_MSR(i) + DF_PMC_COUNT_OFFSET

// Note: UMC MSRs are only valid for Zen4 and later
#define UMC_PMC_COUNT           4
#define UMC_PMC_CFG_BASE_MSR    0xC0010800
#define UMC_PMC_COUNT_OFFSET    0x1
#define UMC_PMC_STRIDE          0x2

#define UMC_PMC_CFG_MSR(i)      UMC_PMC_CFG_BASE_MSR + i * UMC_PMC_STRIDE
#define UMC_PMC_COUNT_MSR(i)    UMC_PMC_CFG_MSR(i) + UMC_PMC_COUNT_OFFSET

#define CORE_PMC_DEBUG_COUNT            2
#define CORE_PMC_DEBUG_CFG_BASE_MSR     0xC0010188
#define CORE_PMC_DEBUG_COUNT_OFFSET     0x1
#define CORE_PMC_DEBUG_STRIDE           0x2

#define CORE_PMC_DEBUG_CFG_MSR(i)       CORE_PMC_DEBUG_CFG_BASE_MSR + i * CORE_PMC_DEBUG_STRIDE
#define CORE_PMC_DEBUG_COUNT_MSR(i)     CORE_PMC_DEBUG_CFG_MSR(i) + CORE_PMC_DEBUG_COUNT_OFFSET

#define DF_PMC_DEBUG_COUNT          4
#define DF_PMC_DEBUG_CFG_BASE_MSR   0xC0010190
#define DF_PMC_DEBUG_COUNT_OFFSET   0x1
#define DF_PMC_DEBUG_STRIDE         0x2

#define DF_PMC_DEBUG_CFG_MSR(i)         DF_PMC_DEBUG_CFG_BASE_MSR + i * DF_PMC_DEBUG_STRIDE
#define DF_PMC_DEBUG_COUNT_MSR(i)       DF_PMC_DEBUG_CFG_MSR(i) + DF_PMC_DEBUG_COUNT_OFFSET

#define CORE_PMC_MAX_COUNT          CORE_PMC_COUNT + CORE_PMC_DEUG_COUNT
#define DF_PMC_MAX_COUNT            CORE_PMC_COUNT + CORE_PMC_DEUG_COUNT

#define MUX_INTERVAL_DEFAULT        16   /* ms */
#define LOG_INTERVAL_DEFAULT        1000 /* ms */

typedef enum
{
    CLIENT_TYPE_INVALID,
    CLIENT_TYPE_PMC,
    CLIENT_TYPE_PWR_PROFILER,
    CLIENT_TYPE_MAX,
} ClientType;

typedef enum
{
    GROUP_TYPE_INVALID = 0,
    GROUP_TYPE_CORE_PMC,
    GROUP_TYPE_L3_PMC,
    GROUP_TYPE_DF_PMC,
    GROUP_TYPE_UMC_PMC,
    GROUP_TYPE_MAX,
} GroupType;

typedef enum
{
    GROUP_ATTR_INVALID      = 0,
    /* Collect TSC for group */
    GROUP_ATTR_TIMESTAMP    =  0x1,
    /* Collect IRPerf MSR value for group */
    GROUP_ATTR_IRPERF       =  0x2,
    /* Collect MPerf MSR value for group */
    GROUP_ATTR_MPERF        =  0x4,
    /* Collect APerf MSR value for group */
    GROUP_ATTR_APERF        =  0x8,
    /* Collect FCLK for group */
    GROUP_ATTR_FCLK         =  0x10,
    GROUPT_ATTR_MAX

} GroupAttributes;

#define PMC_GROUP_ATTR_WIDTH    16

typedef union
{
    struct
    {
        uint64_t m_groupType        :   8;
        uint64_t m_groupConfigCount :   8;
        uint64_t m_groupAttributes  :   16;
        uint64_t m_groupId          :   32;

    } m_header;

    uint64_t m_hdr;

} CountModeGroupHeader;

typedef struct
{
    CountModeGroupHeader m_configHeader;

    union
    {
        uint64_t m_corePmcConfigArray[MAX_CORE_PMC_COUNTERS];
        uint64_t m_l3PmcConfigArray[MAX_L3_PMC_COUNTERS];
        uint64_t m_dfPmcConfigArray[MAX_DF_PMC_COUNTERS];
        uint64_t m_umcPmcConfigArray[MAX_UMC_PMC_COUNTERS];
    } m_cfgArray;

} CountModeGroupConfig;

typedef struct
{
    uint32_t m_clientId;
    uint32_t m_status;
    uint64_t m_muxInterval;
    uint64_t m_logInterval;
    uint64_t m_corePmcCoreMaskArray[PMC_CORE_MASK_ARRAY_SIZE];
    uint64_t m_l3PmcCoreMaskArray[PMC_CORE_MASK_ARRAY_SIZE];
    uint64_t m_dfPmcCoreMaskArray[PMC_CORE_MASK_ARRAY_SIZE];
    uint64_t m_umcPmcCoreMaskArray[PMC_CORE_MASK_ARRAY_SIZE];
    uint32_t m_umcMask[PMC_MAX_SOCKET_COUNT];
    uint32_t m_pmcPerUmc;
    uint32_t m_dataBufferSize[PMC_PMU_MAX];
    uint32_t m_dataBufferThreshold[PMC_PMU_MAX];
    int      m_fdArray[PMC_FD_ARRAY_SIZE];
    uint64_t m_configArraySize;
    uint64_t m_pConfigArray;

} CountModeProfileConfig;
