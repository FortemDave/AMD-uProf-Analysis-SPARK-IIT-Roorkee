//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrCommonConfig.h
///
//==================================================================================
#pragma once
#include <PwrDriverInternal.h>
#include <PwrCommonDataTypes.h>

// FillSmuAccessData
bool FillSmuAccessData(SmuList* srcList, SmuList* destList);

// ConfigureSourceProfiling: Configuration for source code profiling
void ConfigureSourceProfiling(CoreData* pCoreData);

// CloseSourceProfiling: Close the configuration for source code profiling
void CloseSourceProfiling(CoreData* pCoreData);

// ConfigureSmu:
void ConfigureSmu(SmuList* pList, bool isOn);

// SetSmuAccessState: Se this flag is there is any failure while accesing smu
// it and any of the SMU configured for the profiling.
void SetSmuAccessState(bool state);

// GetSmuAccessState: If all configured SMU are accisible this will send true.
bool GetSmuAccessState(void);

// PwrGetIpcData: collect IPC load parameters
void PwrGetIpcData(PmcCounters* pSrc, uint64* pData);

