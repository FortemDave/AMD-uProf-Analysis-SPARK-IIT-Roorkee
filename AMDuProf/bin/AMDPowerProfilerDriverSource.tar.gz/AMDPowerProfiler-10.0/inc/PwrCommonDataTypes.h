//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrCommonDataTypes.h
///
//==================================================================================
#pragma once

#include "PwrDriverTypedefs.h"
#include "PwrSmu8Interface.h"
#include "PwrSmu7Interface.h"
#include "PwrVersion.h"

#define PWR_SMU9_TABLE_VERSION_AM4_0x00190001 0x00190001
#define PWR_SMU9_TABLE_VERSION_AM4_0x00190201 0x00190201
#define PWR_SMU9_TABLE_VERSION_AM4_0x002B0000 0x002B0000
#define PWR_SMU9_TABLE_VERSION_SP3 0x00190201
#define PWR_SMU9_TABLE_VERSION_SP4 0x00190101

//SMU Limit registers
#define SMU_INDEX_ADDR        0x800000B8
#define SMU_INDEX_DATA        0x800000BC

// Supported platform
#define PLATFORM_INVALID    0xFFFFFFUL
#define PLATFORM_KAVERI     0x15303FUL
#define PLATFORM_MULLINS    0x16303FUL
#define PLATFORM_CARRIZO    0x15606FUL
#define PLATFORM_STONEY     0x15707FUL

#define MAX_CORE_CNT                (1024)
#define PWR_CORE_MASK_SIZE          (MAX_CORE_CNT / 64)
#define PWR_CORE_MASK_BITS_COUNT    (64)
#define PWR_MAX_SOCKET_COUNT        (4)
#define COUNTERID_MAX_CNT           (200)

#define PWR_INTERNAL_COUNTER_BASE   (2 * sizeof(uint32) + PWR_MAX_MARKER_CNT * sizeof(MarkerTag))
#define PWR_MAX_DPM_STATES          (8)

//Maximum number of available APU P-States
#define AMDT_MAX_PSTATES 8

/// The enumeration used to retrieve data from the __cpuid intrinsic
typedef enum
{
    /// The offset of EAX data
    PWR_EAX_OFFSET,
    /// The offset of EBX data
    PWR_EBX_OFFSET,
    /// The offset of ECX data
    PWR_ECX_OFFSET,
    /// The offset of EDX data
    PWR_EDX_OFFSET,
    /// The number of values in the CPUID array
    PWR_NUM_CPUID_OFFSETS
} RegisterOffset;

// PwrZenType:
typedef enum PwrZenType
{
    PWR_ZEN1,
    PWR_ZEN2,
    PWR_ZEN3,
    PWR_ZEN4
} PwrZenType;

// PwrZPSocketType: Platform socket types
typedef enum PwrZPSocketType
{
    PWR_SOCKET_TYPE_ZP_FP5 = 0x00,
    PWR_SOCKET_TYPE_ZP_SP4 = 0x01,
    PWR_SOCKET_TYPE_ZP_AM4 = 0x02,
    PWR_SOCKET_TYPE_ZP_SP3 = 0x04,
    PWR_SOCKET_TYPE_ZP_SP3R2 = 0x07
} PwrZPSocketType;

// PwrCZSocketType: Platform socket types
typedef enum PwrCZSocketType
{
    PWR_SOCKET_TYPE_CZ_FP4 = 0x00,
} PwrCZSocketType;

// PwrKVSocketType: Platform socket types
typedef enum PwrKVSocketType
{
    PWR_SOCKET_TYPE_KV_FP3 = 0x00,
    PWR_SOCKET_TYPE_KV_FM2R2 = 0x01
} PwrKVSocketType;

// PwrMLSocketType: Platform socket types
typedef enum PwrMLSocketType
{
    PWR_SOCKET_TYPE_ML_FT3B = 0x00,
    PWR_SOCKET_TYPE_ML_FP4 = 0x02
} PwrMLSocketType;

typedef enum PwrBasicCounterIds
{
    COUNTERID_SAMPLE_ID,
    COUNTERID_RECORD_ID,
    COUNTERID_SAMPLE_TIME,
    COUNTERID_BASIC_CNT
} PwrBasicCounterIds;

typedef enum PwrNodeCounterIds
{
    COUNTERID_PID,
    COUNTERID_TID,
    COUNTERID_CEF,
    COUNTERID_CSTATE_RES,
    COUNTERID_PSTATE,
    COUNTERID_SOFTWARE_PSTATE,
    COUNTERID_PERCORE_END = COUNTERID_SOFTWARE_PSTATE,
    COUNTERID_CORE_POWER,
    COUNTERID_PKG_POWER,
    COUNTERID_PKG_TEMPERATURE,
    COUNTERID_NODE_MAX_CNT
} PwrNodeCounterIds;

#define PWR_PERCORE_COUNTER_MASK ~(~0ULL << (COUNTERID_PERCORE_END +1) )

typedef enum PwrSmu7CounterIds
{
    COUNTERID_SMU7_APU_PWR_CU,
    COUNTERID_SMU7_APU_TEMP_CU,
    COUNTERID_SMU7_APU_TEMP_MEAS_CU,
    COUNTERID_SMU7_APU_PWR_IGPU,
    COUNTERID_SMU7_APU_PWR_PCIE,
    COUNTERID_SMU7_APU_PWR_DDR,
    COUNTERID_SMU7_APU_PWR_DISPLAY,
    COUNTERID_SMU7_APU_PWR_PACKAGE,
    COUNTERID_SMU7_APU_TEMP_IGPU,
    COUNTERID_SMU7_APU_TEMP_MEAS_IGPU,
    COUNTERID_SMU7_APU_FREQ_IGPU,
    COUNTERID_SMU7_CNT
} PwrSmu7CounterIds;

typedef enum PwrSmu8CounterIds
{
    COUNTERID_SMU8_APU_PWR_CU,
    COUNTERID_SMU8_APU_TEMP_CU,
    COUNTERID_SMU8_APU_C0STATE_RES,
    COUNTERID_SMU8_APU_C1STATE_RES,
    COUNTERID_SMU8_APU_CC6_RES,
    COUNTERID_SMU8_APU_PWR_VDDGFX,
    COUNTERID_SMU8_APU_PWR_APU,
    COUNTERID_SMU8_APU_TEMP_VDDGFX,
    COUNTERID_SMU8_APU_FREQ_IGPU,
    COUNTERID_SMU8_APU_PWR_VDDIO,
    COUNTERID_SMU8_APU_PWR_VDDNB,
    COUNTERID_SMU8_APU_PWR_VDDP,
    COUNTERID_SMU8_APU_PWR_UVD,
    COUNTERID_SMU8_APU_PWR_VCE,
    COUNTERID_SMU8_APU_PWR_ACP,
    COUNTERID_SMU8_APU_PWR_UNB,
    COUNTERID_SMU8_APU_PWR_SMU,
    COUNTERID_SMU8_APU_PWR_ROC,
    COUNTERID_SMU8_APU_FREQ_ACLK,
    COUNTERID_SMU8_CNT
} PwrSmu8CounterIds;

#define SMU_IPVERSION_INVALID 255
#define SMU_IPVERSION_7_0     70
#define SMU_IPVERSION_7_1     71
#define SMU_IPVERSION_7_2     72
#define SMU_IPVERSION_7_5     75
#define SMU_IPVERSION_8_0     80
#define SMU_IPVERSION_8_1     81


typedef enum
{
    COUNTERID_PKG_PWR_DGPU,
    COUNTERID_TEMP_MEAS_DGPU,
    COUNTERID_FREQ_DGPU,
    COUNTERID_VOLT_VDDC_LOAD_DGPU,
    COUNTERID_CURR_VDDC_DGPU,
    COUNTERID_DGPU_MAX_CNT
} AMDTPwrProfileDgpuAttribute;

///The maximum number of clients that PwrProf supports
#define MAX_CLIENT_COUNT 1

//  PwrProf's error codes
typedef enum
{
    /// An error occurred
    PROF_ERROR = -1,
    /// No errors occurred
    PROF_SUCCESS = 0x00,
    /// An argument was invalid
    PROF_INVALID_ARG = 0x01,
    /// Unable to create a file with that name
    PROF_INVALID_FILENAME_FORMAT = 0x03,
    /// Unable to write to the file
    PROF_FILE_WRITE_ERROR = 0x05,
    /// The configuration is not available
    PROF_INVALID_OPERATION = 0x06,
    /// Memory is not available for buffer allocation
    PROF_BUFFER_NOT_ALLOCATED = 0x08,
    /// Smu configuration error
    PROF_ERROR_SMU_CONGIGURATION = 0x10,
    /// Smu access failure error
    PROF_ERROR_SMU_ACCESS_FAILED = 0x11,
    /// The client application crashed during a profile
    PROF_CRITICAL_ERROR = 0xDEAD
} PWRPROF_ERROR_CODES;


/// These enumerated masks cover the possible range of states the driver is in
typedef enum
{
    /// The current client is not configured for anything
    STATE_NOT_CONFIGURED = 0x0000,
    /// The output file has been set for the next profile
    STATE_OUTPUT_FILE_SET = 0x0001,
    /// The call-stack sampling has been set for the next profile
    STATE_CSS_SET = 0x0002,
    /// The process id filter has been set for the next profile
    STATE_PID_FILTER_SET = 0x0004,
    /// At least one event configuration has been added for the next
    /// profile
    STATE_TBP_SET = 0x0008,
    /// The profile was started and is in process
    STATE_PROFILING = 0x0010,
    /// The profile was started and is currently paused
    STATE_PAUSED = 0x0020,
    /// The profile is currently stopping
    STATE_STOPPING = 0x0040
} PWRPROF_STATE;


typedef enum PMCEvents
{
    PMC_EVENT_CPU_CYCLE_NOT_HALTED,
    PMC_EVENT_RETIRED_MICRO_OPS,
    PMC_EVENT_MAX_CNT
} PMCEvents;

/// \struct OUTPUT_FILE_DESCRIPTOR Holds the file names for the next profile
typedef struct
{
    uint32 m_clientId;
    uint32 m_pathSize;
    uint64 m_pathName;
    uint32 m_status;
} OUTPUT_FILE_DESCRIPTOR, *POUTPUT_FILE_DESCRIPTOR;

#define PROFILE_MASK_LEN (3)

// PROF_CONFIGS
typedef struct
{
    uint32 m_clientId;
    uint32 m_profileType;
    uint32 m_configCnt;
    uint64 m_config;
    uint32 m_status;
} PROF_CONFIGS, *PPROF_CONFIGS;

/// Profiling modes
typedef enum
{
    /// Offline profiling mode
    PROF_MODE_OFFLINE   = 0x0000,
    /// Online profiling mode
    PROF_MODE_ONLINE    = 0x0001,
} PROF_MODE;

/// \struct PROFILER_PROPERTIES Holds information about the current profile
typedef struct
{
    uint32 m_clientId;
    uint32 m_mode;
    uint64 m_abort;
    uint32 m_status;
} PROFILER_PROPERTIES, *PPROFILER_PROPERTIES;

#if defined(_WIN32)
    #define PWR_CURRENT_CORE (~0UL)
#else
    #define PWR_CURRENT_CORE (-1)
#endif

/// \struct ACCESS_PCI to access Pci device directly from user space
typedef struct
{
    bool     m_isReadAccess;
    uint32   m_address;
    uint32   m_data;
} ACCESS_PCI, *PACCESS_PCI;

/// \struct ACCESS_MSR to access MSR directly from user space
typedef struct
{
    bool     m_isReadAccess;
    uint32   m_core;
    uint32   m_regId;
    uint64   m_data;
} ACCESS_MSR, *PACCESS_MSR;

/// \struct ACCESS_MMIO to access Memory Mapped space
typedef struct
{
    bool     m_isReadAccess;
    uint64   m_addr;
    uint32   m_data;
    uint32   m_status;
} ACCESS_MMIO, *PACCESS_MMIO;

/// \struct FILE_HEADER
/// Mainly used for online profiling mode
typedef struct
{
    uint32 m_clientId;
    /// Buffer id, used to identify requested buffer in case header spans
    /// in more than 1 buffer, first buffer id is 0 and so on
    uint32 m_bufferId;
    /// Buffer will contain file header data, the size of buffer
    /// should be >= FILE_HEADER_BUFFER_SIZE
    uint64 m_buffer;
    uint32 m_bufferCnt;
    uint32 m_status;
} FILE_HEADER, *PFILE_HEADER;

typedef struct PwrApicInfo
{
    uint32 m_extdApic;
    uint32 m_physicalId;
    uint32 m_nodeId;
} PwrApicInfo;

typedef struct PwrExtPerfMonAndDbgInfo
{
    bool        m_isLbrExtV2;
    bool        m_isPerfMonV2;
    uint32_t    m_numOfUmcPmc;
    uint32_t    m_numOfDfPmc;
    uint32_t    m_lbrV2StackSize;
    uint32_t    m_numOfCorePmc;
    uint32_t    m_activeUmcMask;
    uint32_t    m_numOfL3Pmc;
} PwrExtPerfMonAndDbgInfo;

typedef struct MMIOBusMap
{
    uint32 m_threadId;
    uint32 m_bus;
} MMIOBusMap;

// PwrZenTargetInfo
typedef struct PwrZenTargetInfo
{
    uint32      m_totalPhysicalCores;
    uint32      m_totalThreads;
    uint32      m_physicalCoresPerSocket;
    uint32      m_threadsPerSocket;
    bool        m_isSmtEnabled;
    uint32      m_isRaplAvailable;
    uint32      m_energyUnit;
    MMIOBusMap  m_mmio[PWR_MAX_SOCKET_COUNT];
    uint32      m_firstCore[PWR_MAX_SOCKET_COUNT];
    PwrApicInfo m_apic[MAX_CORE_CNT];
    uint64      m_pstateReg;
    bool        m_isZen2;
    bool        m_isZen3;
    bool        m_isZen4AndAbove;
    uint32_t    m_coreShiftWidth;
    uint32_t    m_coreMaskWidth;
    uint32_t    m_ccdShiftWidth;
    uint32_t    m_ccdMaskWidth;
    uint32_t    m_ccxShiftWidth;
    uint32_t    m_ccxMaskWidth;
    uint32_t    m_socketShiftWidth;
    uint32_t    m_socketMaskWidth;
    PwrExtPerfMonAndDbgInfo m_perfMonInfo[PWR_MAX_SOCKET_COUNT];
} PwrZenTargetInfo;

// Pwr1516TargetInfo
typedef struct Pwr1516TargetInfo
{
    uint32     m_coreCount;
    uint32     m_cuCount;
    uint32     m_coresPerCu;
    bool       m_isIgpuAvailable;
    uint64     m_pstateTable[AMDT_MAX_PSTATES];
} Pwr1516TargetInfo;

// Pwr1516TargetInfo
typedef struct PwrNonAmdTargetInfo
{
    uint32 m_cores;
} PwrNonAmdTargetInfo;

/// \struct TARGET_SYSTEM_INFO
/// Target HW information
typedef struct
{
    uint32 m_isZen;
    uint32 m_isAmd;
    uint32 m_family;
    uint32 m_model;
    uint32 m_platformId;
    uint32 m_socketType;
    uint32 m_socketCount;
    bool   m_isCefAvailable;
    bool   m_isGuest;
    union
    {
        PwrZenTargetInfo  m_zen;
        Pwr1516TargetInfo m_1516;
        PwrNonAmdTargetInfo m_nonAmd;
    };
    uint32 m_status;
} TARGET_SYSTEM_INFO, *PTARGET_SYSTEM_INFO;

/// \struct DATA_BUFFERS
/// Mainly used for online profiling mode
typedef struct
{
    /// The registered client id
    uint32 ulClientId;
    /// Buffer id, used to identify requested buffer in case sample data spans
    /// in more than 1 buffer, latest buffer id is 0 then -1, -2...so on
    int32 lBufferId;
    /// Buffer will contain sample data, the size of buffer
    /// should be >= DATA_PAGE_BUFFER_SIZE
    uint64 uliBuffer;
    /// Start offset of the data collected after last call
    uint32 ulStartOffset;
    /// Byte to be consumed after the start offset
    uint32 ulByteToBeConsumed;
    /// Sample buffer collected since last call
    uint32 ulavailableBuffCnt;
    /// The return status
    uint32 ulStatus;
} DATA_BUFFER, *PDATA_BUFFER;

// Common function implementation between driver and backend
// These functions are inteded to have same logic across driver and backend
// to avoid different logic and maintainace purpose

// DecodeCURegisterStatus: Decode the number of compute units and number of active cores
// in that compute unit.
#define AMDT_CU_STATUS1 0x00010001
#define AMDT_CU_STATUS2 0x00030003
#define AMDT_CU_STATUS3 0x00010000
#define AMDT_CU_STATUS4 0x00030000

// PState frequency masks
#define AMDT_CPUFID_MASK        0x3FULL
#define AMDT_CPUDID_MASK        0x1C0ULL
#define AMDT_CPUDID_BITSHIFT    6

// PState
#define AMDT_PSTATE_BASE_REGISTER                   0xC0010064
#define AMDT_PSTATE_CORE_FREQ_DIVISOR_ID_MASK       0x3F00ULL
#define AMDT_PSTATE_CORE_FREQ_DIVISOR_ID_SHIFT      8
#define AMDT_PSTATE_CORE_FREQ_MULTIPLIER_ID_MASK    0xFFULL


// Page Buffer
// Buffer to hold the profile and header data
// Common structure between driver and backend
typedef struct PageBuffer
{
    uint64   m_recCnt;
    atomic   m_currentOffset;
    atomic   m_consumedOffset;
    union
    {
        uint8*   m_pBuffer;
        uint64   m_dummy;
    };
    atomic   m_maxValidOffset;
    uint32   m_fill;
} PageBuffer;


/*
1h 1h -1 compute unit is enabled; both cores of the compute unit are enabled.\
3h 3h -2 compute units are enabled; both cores of each compute unit are enabled.\
1h 0h -1 compute unit is enabled; core 0 of the compute unit is enabled; core 1 of the\
compute unit is disabled.\
3h 0h 2 compute units are enabled; core 0 of each compute unit is enabled; core 1 of\
each compute unit is disabled.\
*/
#define DecodeCURegisterStatus(reg, pCuCnt, pCorePerCu)\
    if(reg == (reg & AMDT_CU_STATUS1)){*pCuCnt = 1; *pCorePerCu = 2;}\
    else if (reg == (reg & AMDT_CU_STATUS2)){*pCuCnt = 2;*pCorePerCu = 2;}\
    else if (reg == (reg & AMDT_CU_STATUS3)) { *pCuCnt = 1;*pCorePerCu = 1;}\
    else if (reg == (reg & AMDT_CU_STATUS4)) {*pCuCnt = 2; *pCorePerCu = 1; }

// ExtendedPciAddrSpace: PCI config address encoder
typedef union ExtendedPciAddrSpace
{
    // \brief The elements that make up a PCI address in PCI config space
    struct
    {
        // base register address to access
        uint32 regNo : 8;
        // function number to access
        uint32 function : 3;
        // device number to access
        uint32 device : 5;
        // bus number to access
        uint32 busNo : 8;
        // extended register number to access
        uint32 extRegNo : 4;
        // reserved, must be 0
        uint32 reserved : 3;
        // Configuration space enable, 1 = IO read and write accesses to
        // IOCFC are translated into configuration cycles at the
        // configuration address
        uint32 configEn : 1;
    } element;
    // The equivalent IO-space configuration address made up of each \ref Element
    uint32 address;
} ExtendedPciAddrSpace;

// EncodeExtendedConfigSpaceAddress: Encode PCI address to extended PCI config speace.
#define GET_EXTENDED_PCICS_ADDRESS(b, d, f, r, out) {\
        ExtendedPciAddrSpace p;\
        p.address = 0U;\
        p.element.configEn = 1U;\
        p.element.extRegNo = (r >> 8) & 0xFU;\
        p.element.regNo = r & 0x00FCU;\
        p.element.busNo = b;\
        p.element.device = d;\
        p.element.function = f;\
        out = p.address;   }

typedef struct PwrCefInfo
{
    uint64 m_p0State;
    uint64 m_aperf;
    uint64 m_mperf;
    uint64 m_tsc;
} PwrCefInfo;

// Error code for power profile API access
typedef enum
{
    RAW_STATUS_ERROR = -1,
    RAW_STATUS_SUCCESS = 0,
    RAW_READ_ERROR = 1,
    RAW_WRITE_ERROR = 2,
    RAW_UNKNOWN_ERROR = 3,
} RAW_Status;

#define RAWFILE_MAGIC 0
#define MAJOR_VERSION 3
#define MINOR_VERSION 4
#define MICRO_VERSION 1
#define PROFILE_VERSION (MAJOR_VERSION << 24)|(MINOR_VERSION << 16)| MICRO_VERSION
#define RAW_FILE_VERSION 1
#define SECTION_HDR_CNT 1
#define MAX_SECTION_HDR_CNT 12
#define MAX_POWER_CFG 10
#define FILE_BUFFER_SIZE (4*1024)

#define MAX_SAMPLE_ATTRIBUTE 20 //will this be sufficient
#define MAX_RAW_DATA_SIZE (MAX_SAMPLE_ATTRIBUTE * sizeof(uint64))
#define CONTEXT_RECORD_LEN sizeof(RawRecordHdr) + sizeof(uint64) + sizeof(ContextData)
#define MARKER_RECORD_LEN (sizeof(RawRecordHdr) + sizeof(MarkerTag))

// SectionHrdTableInfo
//
// This structure holds the starting address and size of each section
// Currently there is only one section table.
// There could be more than one section header table in future.
typedef struct SectionHrdTableInfo
{
    uint32   m_sectionTabOff;  // offset of section header table in file;
    uint32   m_sectionTabSize; // size of the section header table in file;
} SectionHrdTableInfo;

// RawFileHeader
//
// We can also use MAJOR and MINOR VERSION NUMBER - 16 bits each and
// consturct a 32-bit VERSION from these MAJOR and MINOR version numbers
#define RAW_FILE_VERSION      1

#define MAX_SECTION_HDR_TABLE 2
typedef struct RawFileHeader
{
    uint64   m_magicNum;
    uint32   m_versionNum;
    uint32   m_rawFileVersion;
    uint16   m_sectionTabCnt;
    uint16   m_targetCoreCuCnt;
    uint32   m_rawDataOffset;
    uint32   m_family;
    uint32   m_model;
    uint64   m_rawRecordCount;
    uint64   m_sessionStart;
    uint64   m_sessionEnd;
    uint64   m_startPerfCounter;
    uint64   m_perfFreq;
    SectionHrdTableInfo m_tabInfo[1];
} RawFileHeader;

// SectionType
//
// Not all sections are mandatory...
// Following sections are optional
//    1.RAW_FILE_SECTION_RUN_INFO
//    2.RAW_FILE_SECTION_CPU_INFO
//    3.RAW_FILE_SECTION_CPU_TOPOLOGY
// For CPU profile following could be necessary
//      1.Sampling mode requires - EVENT_ATTRIBUTE, SAMPLE_ID & SAMPLE_DATA sections
//      2.Counting mode requires - EVENT_ATTRIBUTE & COUNTER_DATA sections
//      3.Sampling and Sampling mode requires -
//        EVENT_ATTRIBUTE, SAMPLE_ID, SAMPLE_DATA & COUNTER_DATA sections
//  For Power profile following could be necessary
//        RAW_FILE_SECTION_POWER_CONFIG, SAMPLE_ID, SAMPLE_DATA sections

#define RAW_FILE_SECTION_RUN_INFO (1 << 0)
#define RAW_FILE_SECTION_CPU_INFO (1 << 1)
#define RAW_FILE_SECTION_CPU_TOPOLOGY (1<<2)
#define RAW_FILE_SECTION_SAMPLE_CONFIG (1<<3)
#define RAW_FILE_SECTION_SAMPLE_REC_INFO (1<<4)
#define RAW_FILE_SECTION_TI_REC_INFO (1<<5)
#define RAW_FILE_SECTION_MAX ((uint32)1<<31)
//SectionHdrInfo
//SectionType could be one of SectionType
typedef struct SectionHdrInfo
{
    uint32   m_sectionType;
    uint32   m_misc;            // _UNUSED_ field
    uint64   m_sectionOffset;
    uint64   m_sectionSize;
} SectionHdrInfo;

// SectionRunInfo Section :Optional
//
//   contains details about the machine, processor, OS
//   name/path of the application launched
//   start and end time of the profile
//
//
//
#define MAX_NAME_SIZE    64
typedef struct SectionRunInfo
{
    uint64   m_startTime;
    uint64   m_endTime;
    // This can contain null terminated 64 byte length strings (65 chars)
    wchar_t   m_sysName[MAX_NAME_SIZE];    // OS implementation - Linux
    wchar_t   m_releases[MAX_NAME_SIZE];   // Release - 2.6.38-8-generic
    wchar_t   m_version[MAX_NAME_SIZE];    // version - Ubuntu
    wchar_t   m_nodeName[MAX_NAME_SIZE];   // machine name - capike01
    wchar_t   m_machine[MAX_NAME_SIZE];    // hw type - x86_64
    wchar_t   m_fileName[MAX_NAME_SIZE];   // launched application - should be the last field
} SectionRunInfo;

//SectionCpuInfo: This is an optional section to hold cpu details.
//
// TBD: Do we need vendor info ?
//
#define MAX_CPUID_VALUE    4

typedef struct SectionCpuInfo
{
    uint32     m_function;
    uint32     m_value[MAX_CPUID_VALUE]; // when CA_CPUID_VALUE_MAX gets modified, ensure
    uint32     m_filler[3];
} SectionCpuInfo;

//SectionCpuTopologyInfo: This is an optional section to hold cpu topology info.
typedef struct SectionCpuTopologyInfo
{
    uint32     m_coreId;
    uint32     m_processorId;
    uint32     m_numaNodId;
    uint32     m_filler;
} SectionCpuTopologyInfo;

//SectionSampleInfo: This structure define the first record chunck offset.
typedef struct SectionSampleInfo
{
    uint64   m_firstChunkOffset;
    uint64   m_recordCount;
    uint64   m_size;
} SectionSampleInfo;

//SectionTiInfo: This structure define the first TI chunck offset.
typedef struct SectionTiInfo
{
    uint64  m_firstChunkOffset;
    uint64  m_recordCount;
    uint64  m_size;
} SectionTiInfo;

//Chunk type: describe the types of records followed by chunk marker
typedef enum
{
    CHUNK_TYPE_SAMPLE,
    CHUNK_TYPE_TI
} ChunkType;

// ProfileRecordType
//
// Type of the profile
typedef enum
{
    REC_TYPE_INVALID = 0,
    REC_TYPE_SAMPLE_DATA,
    REC_TYPE_CHUNK_MARKER,
    REC_TYPE_CONTEXT_DATA,
    REC_TYPE_MARKER_DATA,
    REC_TYPE_MAX_CNT
} ProfileRecordType;

// RawRecordHrd
//
// RawRecordHrd holds the information about raw record followed
// by this header
typedef struct RawRecordHdr
{
    uint16  m_recordType;
    uint16  m_recordLen;
    uint32  m_coreId;
} RawRecordHdr;

typedef enum
{
    PROFILE_TYPE_TIMELINE,
    PROFILE_TYPE_APP_ANALYSIS,
} ProfileType;

// RawSamplingSpec
typedef struct SamplingSpec
{
    uint32 m_profileType;
    uint32 m_maskCnt;
    uint64 m_mask[PWR_CORE_MASK_SIZE];
    uint64 m_samplingPeriod;     // in milli seconds
} SamplingSpec;

typedef struct PwrSmu9NbSmnPair
{
    uint32 m_index;
    uint32 m_data;
} PwrSmu9NbSmnPair;

#define PLATFORM_SMU_CNT (5)
/// Function pointers to initialize SMU
typedef bool (*INIT_SMU_CB)(void* pSmu);

/// Function pointers to Close SMU
typedef bool (*CLOSE_SMU_CB)(void* pSmu);

/// Function pointers to read SMU values
typedef bool (*COLLECT_SMU_CB)(void* pSmu, uint8* pData, uint32* pLength);
/// Function pointers to read SMU values

// Smu9Interface: Access interface for Smu9
typedef struct Smu9Interface
{
    PwrSmu9NbSmnPair m_nbSmnAccess;
    uint32 m_testMsgId;
    uint32 m_testMsgArg;
    uint32 m_testMsgResp;
    uint32 m_testMsgPmLogStartId;
    uint32 m_testMsgPmLogReadId;
    uint32 m_testMsgAgmTableVersionId;
    uint32 m_testMsgDramHigh;
    uint32 m_testMsgDramLow;
    uint32 m_socketId;
} Smu9Interface;

// Smu9Vega10Interface: Access interface for Vega 10
typedef struct Smu9Vega10Interface
{
    uint64 m_testMsgId;
    uint64 m_testMsgArg;
    uint64 m_testMsgResp;
    uint64 m_fbBaseOffset;
    uint32 m_testMsgTransferTableSmu2Dram;
    uint32 m_testMsgAgmTableVersionId;
    uint32 m_testMsgDramHigh;
    uint32 m_testMsgDramLow;
    uint32 m_bar0Address;
    uint32 m_bar5Address;
} Smu9Vega10Interface;

// Smu10Interface: Access interface for Smu10
typedef struct Smu10Interface
{
    uint32 m_nbSmnIndex;
    uint32 m_nbSmnData;
    uint32 m_testMsgId;
    uint32 m_testMsgArg;
    uint32 m_testMsgResp;
    uint32 m_testMsgTransferTableSmu2Dram;
    uint32 m_testMsgAgmTableVersionId;
    uint32 m_testMsgDramHigh;
    uint32 m_testMsgDramLow;
} Smu10Interface;

typedef struct SmuAccessCb
{
    INIT_SMU_CB    fnSmuInit;
    CLOSE_SMU_CB   fnSmuClose;
    COLLECT_SMU_CB fnSmuReadCb;
} SmuAccessCb;

typedef struct SmuAccess
{
    union
    {
        Smu10Interface m_smu10;
        Smu9Vega10Interface m_smu9Vega10;
        Smu9Interface m_smu9;
        Smu8Interface m_smu8;
        Smu7Interface m_smu7;
    };
    uint64 m_accessCb;
} SmuAccess;

typedef struct SmuInfo
{
    uint32      m_isAccessible;
    uint32      m_isDgpu;
    uint32      m_packageId;
    uint32      m_smuIpVersion;
    uint64      m_gpuBaseAddress;
    uint64      m_counterMask;
    SmuAccess   m_access;
} SmuInfo;

typedef struct SmuList
{
    uint32  m_count;
    uint32  m_fill;
    SmuInfo m_info[PLATFORM_SMU_CNT];
} SmuList;

// RawPowerConfig
//
// A power session configured for any event type from RAW_PowerEventType.
// Again, for each event type, user can configure one or more than one attributes
// to collect data during the data acquisition.
// For e.g.  if user is interested in RAW_TYPE_HW_PWR and interested in only
// CPU, GPU, and Memory attributes, then following could be the possible mask
// m_eventAttributeMask =  RAW_SMU_POWER_CPU|RAW_SMU_POWER_GPU|RAW_SMU_POWER_MEM
// rawRecLen will calculate the length of the raw sample record for each configuration time
// This format will also support user defined user spac.
typedef struct ProfileConfig
{
    uint16            m_sampleId;
    uint16            m_attrCnt;
    uint32            m_fill;
    SamplingSpec      m_samplingSpec;
    uint64            m_apuCounterMask; // Only node counters
    SmuList           m_activeList;     // m_info[0] will have APU smu
} ProfileConfig;

// RawPowerConfigTable
//
// Table to describe more than one configuration for a profile session
// m_configCnt provides the number of configuration used for the profile session
typedef struct ProfileConfigList
{
    uint32            m_configCnt;
    ProfileConfig* m_profileConfig;
} ProfileConfigList;

//RawBufferInfo
//
//This structure holds the information regarding the buffer comming from driver
typedef struct RawBufferInfo
{
#ifndef _DBG_TOOL_
    ULARGE_INTEGER uliBuffer;
#else
    ULARGE_INT     uliBudder;
#endif
    uint32         ulvalidLength;
} RawBufferInfo;

// Context Data
// Os context data for every sample
typedef struct ContextData
{
    uint32     m_processId;
    uint32     m_threadId;
    uint64     m_timeStamp;
    uint64     m_ip;
    uint32     m_isKernel;
    uint32     m_fill;
    uint64     m_pmcData[PMC_EVENT_MAX_CNT];
} ContextData;

// PwrInternalAddr: Internal counters PCI address
typedef struct PwrInternalAddr
{
    uint32 m_cstateRes;
    uint32 m_sviTelemetry;
    uint32 m_sviNBTelemetry;
    uint32 m_timingControl4;
    uint32 m_timingControl6;
    uint32 m_coreEnergyMsr;
    uint32 m_packageEnergyMsr;
} PwrInternalAddr;


#define PWR_MAX_MARKER_CNT          10
#define PWR_MARKER_BUFFER_SIZE      32

// TODO: This should be ENUM
// Maker states
#define PWR_MARKER_DISABLE              0
#define PWR_MARKER_ENABLE               1
#define PWR_MARKER_ENABLE_INITIATED     2
#define PWR_MARKER_DISABLE_INITIATED    3

// MarkerTag Data
// Start and stop marker tag
typedef struct MarkerTag
{
    uint32     m_markerId;
    uint32     m_pid;
    uint32     m_state;
    uint32     m_fill;
    uint64     m_ts;
    uint8      m_name[PWR_MARKER_BUFFER_SIZE];
    uint8      m_userBuffer[PWR_MARKER_BUFFER_SIZE];
} MarkerTag;

typedef struct
{
    uint32 m_clientId;
    uint32 m_type;
    uint64 m_event;
} EventInfo;
