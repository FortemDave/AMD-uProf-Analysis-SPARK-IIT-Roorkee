//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrProfDebugHelper.h
///
//==================================================================================
#pragma once

#ifdef DEBUG

    void PrintPageBuffer(const PageBuffer* pPageBuffer);
    void PrintSmuInfo(const SmuInfo* pSmuInfo);
    void PrintSmuList(const SmuList* pSmuList);
    void PrintClientData(const ClientData* pClientData);
    void PrintCoreData(const CoreData* pCoreData);

#endif // DEBUG
