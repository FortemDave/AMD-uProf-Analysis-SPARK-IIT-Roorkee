//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcSample.h
///
//==================================================================================
#pragma once

#if (__KERNEL__)
    #include <linux/types.h>
#else
    #include <stdint.h>
#endif

#define PMC_MAX_SOCKET_COUNT    4

typedef enum
{
    PMC_PMU_INVALID = -1,
    PMC_PMU_CORE,
    PMC_PMU_L3,
    PMC_PMU_DF,
    PMC_PMU_UMC,
    PMC_PMU_MAX,
} PmcPmuType;

/* Data to include in Raw file header:
 * Magic Number
 * File Header version
 * System Date and Time
 * System Info:
 *   - CPU model/family
 *   - <other information>
 * Number of configuration groups
 * Configuration information:
 *  - Configuration Group Header
 *    - Control values for events in group
 *    - <other information>
 */
typedef struct
{
    // TODO: Add more parameters here.
    uint64_t m_magicNumber;
    uint64_t m_version;
    uint64_t m_size;
    uint32_t m_family;
    uint32_t m_model;
    uint64_t m_time;
    // PSTATE register value
    uint64_t m_pstateReg;
    // TSC Frequency (Windows specific)
    uint64_t m_tscFrequency;
    uint32_t m_pmcPerUmc;
    uint32_t m_umcMaskArraySize;
    uint32_t m_umcMaskArray[PMC_MAX_SOCKET_COUNT];

    // Configuration Information
    uint64_t m_numOfConfigGroups;

    // Making total header side 128 bytes for future expansion
    uint64_t m_fill[5];
    uint64_t m_configData[1];

} PmcHeader;

typedef union
{
    struct
    {
        // Sample size in bytes
        uint32_t m_sampleSize;
        uint32_t m_reserved;

    } m_header;

    uint64_t m_hdr;

} PmcSampleHeader;

// Group header in Pmc Sample data
#define PMC_SAMPLE_HDR_GROUP_ID_WIDTH   48
#define PMC_SAMPLE_HDR_GROUP_ID_MASK    0xffffffffffff

#define PMC_SAMPLE_HDR_ATTR_WIDTH   16
#define PMC_SAMPLE_HDR_ATTR_MASK    0xffff
#define PMC_SAMPLE_HDR_ATTR_SHIFT   48

typedef struct
{
    PmcSampleHeader m_sampleHeader;

    /* Timestamp when the sample was collected
     * For multiple config groups this is time when
     * the first configuration group was loaded??
     * Only required when multiplexing? */
    uint64_t m_time;
    /* Core Id on which the sample is collected
     * TODO: Can this be moved into sample header? */
    uint32_t m_coreId;
    /* Socket Id on which the sample is collected
     * Used for processing UMC type samples */
    uint32_t m_socketId;
    /* Delta time (Timestamp when current sample is logged)
     * - (Timestamp when last sample was logged)*/
    uint64_t m_deltaTimeEnabled;

    /* PMC sample data */
    uint64_t m_data[1];

} PmcSample;
