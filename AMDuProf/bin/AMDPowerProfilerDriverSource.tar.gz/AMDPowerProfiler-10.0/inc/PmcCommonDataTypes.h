//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcCommonDataTypes.h
///
//==================================================================================
#pragma once

#include <PmcTypes.h>
#include <PmcOsTypes.h>

#if defined(_WIN32)
    #include <PwrProfInternal.h>
#endif

typedef struct
{
    /* Control value for PMC CTL Msr */
    volatile uint64_t m_controlValue;
    /* Count value for pre loading PMC COUNT Msr
     * Saved count value when config is unloaded from counter*/
    volatile uint64_t m_counterValue;
} PmcConfig;

/* PMC config group attributes */
typedef enum
{
    PMC_CONFIG_GROUP_ATTR_TIMESTAMP = 0x1,
    PMC_CONFIG_GROUP_ATTR_IRPERF    = 0x2,
    PMC_CONFIG_GROUP_ATTR_MPERF     = 0x4,
    PMC_CONFIG_GROUP_ATTR_APERF     = 0x8,
    PMC_CONFIG_GROUP_ATTR_FCLK      = 0x10,
    PMC_CONFIG_GROUP_ATTR_MAX,
} PmcConfigGroupAttrs;

/* ToDo: Add group pmc type here? */
typedef struct PmcConfigGroup
{
    /* Pointer to next configuration group in circular linked list */
    struct PmcConfigGroup* m_pNext;
    /* Number of valid pmc configurations in the array */
    uint16_t        m_pmcConfigCnt;
    /* PMC configuration array
     * (Size of array is maximum available
     * counters for PMC type) */
    PmcConfig*      m_pPmcConfigArray;
    /* Timestamp when this configuration was loaded */
    uint64_t        m_loadTime;
    /* Duration (delta time) for which this configuration
     * last resided on the counters */
    uint64_t        m_deltaTime;
    /* Duration (delta time) for which this configuration
     * last resided on the counters per DF Clk */
    uint64_t        m_dfClkDelta;
    uint64_t        m_dfClk;
    /* Configuration group attributes (PmcConfigGroupAttrs) */
    uint64_t        m_pmcConfigGroupAttrs;
    /* Configuration group id - Unique id for for each pmc
     * configuration group */
    uint64_t        m_pmcConfigGroupId;
    /* IRPerf */
    uint64_t        m_irPerfDelta;
    uint64_t        m_irPerf;
    /* MPerf */
    uint64_t        m_mPerfDelta;
    uint64_t        m_mPerf;
    /* APerf */
    uint64_t        m_aPerfDelta;
    uint64_t        m_aPerf;
    /* UMC Counter values*/
    uint32_t        m_umcMsrCount;
    uint64_t*       m_pUmcMsrCountArray;
} PmcConfigGroup;

typedef struct
{
    /* Core id for this core context */
    uint16_t m_coreId;

    /* Socket id for this core context */
    uint16_t m_socketId;

    /* Circular linked list of all PMC configuration groups
     * for each PMC type */
    PmcConfigGroup* m_pPmcConfigGroupArray[PMC_PMU_MAX];

    /* Number of PMC configuration groups for each PMC type.
     * TODO: Duplicated here for ease of access. Check if we
     * can be rid of it. */
    uint16_t m_pmcConfigGroupCnt[PMC_PMU_MAX];

    /* Total PMC configs for all group */
    uint16_t m_totalPmcConfigGroupCnt;

    /* Timer configuration */
    PmcTimerConfig* m_pTimerConfig;
    /* Sampling counter is decremented every timer interrupt
     * and a sample collection is triggered when it is zero.
     * After, it is reset to m_samplingCount. */
    uint16_t m_currSamplingCounter[PMC_PMU_MAX];

    /* Data buffer context for each PMC type */
    PmcDataBufferContext* m_pDataBufferContext[PMC_PMU_MAX];

    /* Reset counter values after sampling */
    // TODO: Remove if unused.
    bool m_resetAfterSampling;

    /* Dropped sample count. */
    uint32_t m_droppedSampleCount[PMC_PMU_MAX];

    /* Delta time between logged samples. */
    uint64_t m_timeEnabled[PMC_PMU_MAX];
    uint64_t m_timeEnabledBegin[PMC_PMU_MAX];

    // Availability mask indicating if counter is available for configuration
    uint32_t m_availabilityMask[PMC_PMU_MAX];

    /* UMC sample record size */
    uint32_t m_umcSampleRecordSize;
    uint32_t m_umcCount;

#if defined (_WIN32)
    KEVENT m_event;
#endif

} CoreContext;

typedef struct
{
    uint32_t m_clientId;

    /* Core Mask array for each PMC type
     * Array of pointers to core mask array
     * of size CORE_MASK_ARRAY_SIZE */
    uint64_t* m_pPmcCoreMaskArray[PMC_PMU_MAX];

    /* UMC mask */
    uint32_t  m_umcMaskArraySize;
    uint32_t* m_pUmcMaskArray;
    uint32_t  m_firstCore[PMC_MAX_SOCKET_COUNT];

    /* Multiplexing interval in ms */
    uint64_t m_muxInterval;
    /* Log interval in ms */
    uint64_t m_logInterval;
    /* Timer interval - Interval used for timer interrupt in ms */
    uint64_t m_timerInterval;
    /* Data buffer size. Must be a multiple of 2^x * (page size) */
    uint32_t m_dataBufferSize[PMC_PMU_MAX];
    /* Data buffer threshold (Number of bytes after which to wake
     * up readers). Must be a multiple of page size. */
    uint32_t m_dataBufferThreshold[PMC_PMU_MAX];

    /* Sample record size for each PMC type.
     * Required to reserve space in buffer */
    uint32_t m_sampleRecordSize[PMC_PMU_MAX];
    /* Total number of valid PMC configurations
     * for each PMC type. Required for sample record
     * size calculation. */
    uint16_t m_totalPmcConfigCnt[PMC_PMU_MAX];
    uint16_t m_totalPmcAttrCnt[PMC_PMU_MAX];

    /* Number of PMC configuration groups for each PMC type. */
    uint16_t m_pmcConfigGroupCnt[PMC_PMU_MAX];

    /* Sampling count for each pmc type.
     * Number of timer interrupts required
     * to trigger sampling. */
    uint16_t m_samplingCount[PMC_PMU_MAX];

    /* Is multiplexing required for any of the pmc types? */
    bool m_multiplex;

    /* Windows specific field.
     * Buffer fill count: indicates the number of per core/ccx/socket
     * buffers with available chunks. */
    volatile long m_bufferFillCount[PMC_PMU_MAX];
    /* Buffer fill max count: Max value of m_bufferFillCount after
     * driver sets event. */
    long m_bufferMaxFillCount[PMC_PMU_MAX];

    CoreContext* m_pCoreContext;

#if defined(_WIN32)
    PPWRPROF_DEV_EXTENSION m_pDevExt;
#endif

} ClientContext;
