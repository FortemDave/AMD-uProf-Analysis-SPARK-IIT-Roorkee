//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcTimerConfig.h
///
//==================================================================================
#pragma once

#include <PmcCommonDataTypes.h>

/*
 * PmcSetupTimer - Allocate space for timer configuration
 * structure and intialize it for a specified core mask.
 */
int PmcSetupTimer(ClientContext* pClientCtx);

/*
 * PmcDestroyTimer - Free memory for timer configuration
 * strutcts and cancel timer.
 */
void PmcDestroyTimer(ClientContext* pClientCtx);

/*
 * PmcStartTimerOnCore - Start timer on a specifc core.
 * Should be invoked on the core.
 */
void PmcStartTimerOnCore(CoreContext* pCoreCtx);

/*
 * PmcStartTimer - Start timer on all cores for a specified
 * core mask.
 */
int PmcStartTimer(ClientContext* pClientCtx);

/*
 * PmcStopTimerOnCore - Stop timer on a specific core.
 * Should be invoked on the core.
 */
void PmcStopTimerOnCore(CoreContext* pCoreCtx);

/*
 * PmcStopTimer - Stop timer on all cores for a specified
 * core mask.
 */
int PmcStopTimer(ClientContext* pClientCtx);
