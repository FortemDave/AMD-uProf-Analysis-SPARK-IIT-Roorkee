//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcDataBufferOps.h
///
//==================================================================================
#pragma once

#include <PmcInterface.h>
#include <PmcCommonDataTypes.h>

void InitDataBufferWaitQueue(PmcDataBufferContext* pDataBufferCtx);
void NotifyPendingRead(PmcDataBufferContext* pDataBufferCtx);

int _CreatePmcFileDescriptors(ClientContext *pClientCtx,
                              PmcPmuType type,
                              uint64_t* pCoreMaskArray,
                              int* pFdArray,
                              uint32_t *pFdArrayIdx);

int CreatePmcFileDescriptors(CountModeProfileConfig* pConfig,
                             ClientContext* pClientContext);
