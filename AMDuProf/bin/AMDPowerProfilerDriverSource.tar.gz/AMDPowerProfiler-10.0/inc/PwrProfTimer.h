//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrProfTimer.h
///
//==================================================================================
#pragma once

#include <PwrDriverTypedefs.h>
#include <PwrCommonDataTypes.h>

// Configure Timer for sampling period specified, set the callback
// function to be invoked when sampling duration expires.
int ConfigureTimer(ProfileConfig* config, uint32 clientId);

// Unconfigure timer, delete it from timer list
int UnconfigureTimer(uint32 clientId);

// Invoked when profiling starts, add a timer for sampling time.
int StartTimer(uint32 clientId);

// Stop timer for the specified client id release the memory allocated for timer.
int StopTimer(uint32 clientId);

// Pause Timer for the specified client id
int PauseTimer(uint32 clientId);


//Resume Timer for the specified client id
int ResumeTimer(uint32 clientId);

// Get header buffer for the kernel space convert it into user space.
int GetHeaderBuffer(PFILE_HEADER fileHeader);

// Get data buffer for the counter
int GetDataBuffer(PDATA_BUFFER dataBuffer);

