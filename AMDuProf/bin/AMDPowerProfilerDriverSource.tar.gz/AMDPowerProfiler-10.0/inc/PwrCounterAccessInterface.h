//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrCounterAccessInterface.h
///
//==================================================================================
#pragma once
#include <PwrDriverTypedefs.h>
#include <PwrDriverInternal.h>

#define MPERF_MSR_ADDRESS      0x000000E7
#define APERF_MSR_ADDRESS      0x000000E8
#define P0STATE_MSR_ADDRESS    0xC0010064
#define MPERF_RO_MSR_ADDRESS   0xC00000E7
#define APERF_RO_MSR_ADDRESS   0xC00000E8
#define TSC_MSR_ADDRESS        0x00000010

// CollectBasicCounters: Read basic counters such as sample id, sample spec, timestamp
bool CollectBasicCounters(CoreData* pCoreCfg,
                          uint32* pLength);

// CollectPerCoreCounters: Read core specific counters values
bool CollectNodeCounters(CoreData* pCoreCfg, uint32* pLength);

// InitializeGenericCounterAccess:
void InitializeGenericCounterAccess(uint32 core);

// CloseGenericCounterAccess
void CloseGenericCounterAccess(void);

// GetBasicCounterSize
uint32 GetBasicCounterSize(void);

// GetNodeCounterSize
uint32 GetNodeCounterSize(uint32 counterId);

