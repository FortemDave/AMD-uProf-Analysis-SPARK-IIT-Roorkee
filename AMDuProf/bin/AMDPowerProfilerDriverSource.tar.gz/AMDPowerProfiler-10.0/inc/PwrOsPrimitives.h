//==================================================================================
// Copyright (c) 2019 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrOsPremitives.h
///
//==================================================================================
#pragma once
// LOCAL INCLUDES
#include <PwrDriverTypedefs.h>
#ifdef _WIN32
    #include <ntifs.h>

    #ifdef DEBUG
        #define DRVPRINT(fmt, ...)    DbgPrint( "PwrProf: %s, "fmt "\n",__FUNCTION__, __VA_ARGS__)
    #else
        #define DRVPRINT(fmt, ...) {}
    #endif

    #define WriteMemBarrier()
#endif
#if defined (__linux__)
    #ifdef DEBUG
        #define DRVPRINT(fmt, ...)   printk("%s:%d " fmt "\n", __FUNCTION__, __LINE__, ##__VA_ARGS__);
    #else
        #define DRVPRINT(fmt, ...) {}
    #endif

    #include <asm/barrier.h>
    #define WriteMemBarrier()   smp_wmb()
#endif

#define DATA_PAGE_BUFFER_SIZE 65536 // 16 X 4096
#define MCFG_BASE_ADDRESS  0xC0010058

// LOCAL DEFINES
typedef union _PciExtendedConfigurationSpaceAddress
{
    // \brief The elements that make up a PCI address in PCI config space
    struct
    {
        // base register address to access
        unsigned int m_reg : 8;
        // function number to access
        unsigned int m_function : 3;
        // device number to access
        unsigned int m_device : 5;
        // bus number to access
        unsigned int m_bus : 8;
        // extended register number to access
        unsigned int m_extReg : 4;
        // reserved, must be 0
        unsigned int m_reserved : 3;
        // Configuration space enable, 1 = IO read and write accesses to
        // IOCFC are translated into configuration cycles at the
        // configuration address
        unsigned int m_configEn : 1;
    } element;
    // The equivalent IO-space configuration address made up of each \ref Element
    uint32 m_address;
} PciExtendedConfigurationSpaceAddress;

//MemoryPool: create memory pool for internal use
typedef struct
{
    void* m_pBase;
    uint32 m_offset;
    uint32 m_size;
} MemoryPool;

#if defined (__linux__)
    #include <asm/io.h>
    extern MemoryPool g_sessionPool;
    #define SESSION_POOL_SIZE 1024

    // Create memory pool
    bool CreateMemoryPool(MemoryPool* pPool, uint32 size);

    // Get buffer from the pool
    uint8* GetMemoryPoolBuffer(MemoryPool* pPool, uint32 size);

    // Delete the memory pool
    bool ReleaseMemoryPool(MemoryPool* pPool);

    void PrepareAffinityMask(cpumask_t* pm_affinity, uint64 mask[]);

    int GetCoreId(void);

#else
    // CreateMemoryPool: Create memory pool
    bool CreateMemoryPool();

    // GetMemoryPoolBuffer: Get buffer from the pool
    void* GetMemoryPoolBuffer(uint32 size, bool resetMem);

    // ReleaseMemoryPoo: lDelete the memory pool
    bool ReleaseMemoryPool();

    // ResetPoolMemory: Set the memory to 0
    void ResetPoolMemory(void* pBuffer, uint32 size);
#endif

uint64 ReadMSR(uint32 reg);

void WriteMSR(uint32 reg, uint64 val);

uint32 ReadPCI(uint32 addr);

void WritePCI(uint32 addr, uint32 data);

bool MapMMIOSpace(uint64  address, size_t  size, uint64* pMapAddress, uint64* pMapSize);

bool UnmapMMIOSpace(uint64 mappedAddress, uint64 mappedSize);

void ReadCPUID(int32* pInfo, uint32 identifier);

void ReadCPUIDEx(int32* pInfo, uint32 indentifier, uint32 sub);

void GetTimeStamp(uint64* pTime);

uint32 GetOnlineCpus(void);

uint32 GetCurrentCoreId(void);

void GetPerformanceCounter(uint64* pPerfCounter, uint64* pFrequency);

bool AcquirePCMCountersLock(void);

bool ReleasePCMCountersLock(void);

bool DeferedCoreExecution(uint32 core, void* pRoutine, void* pContext);

int ExecuteOnCore(int coreId, void* pFunc, void* arg);

void* AllocateMemory(uint32_t size);

int GetCoreCount(void);

void FreeMemory(void* obj);

uint64_t GetTimestamp(void);