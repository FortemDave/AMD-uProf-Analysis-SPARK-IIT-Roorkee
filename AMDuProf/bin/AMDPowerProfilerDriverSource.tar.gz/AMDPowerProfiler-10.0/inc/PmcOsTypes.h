//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcOsTypes.h
///
//==================================================================================
#pragma once

#include <linux/types.h>
#include <linux/wait.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>

typedef struct
{
    struct hrtimer m_hrTimer;
    ktime_t m_time;
} PmcTimerConfig;

typedef struct
{
    /* Core id of this per core buffer */
    uint32_t m_coreId;
    /* Pointer to buffer */
    void *m_pBuffer;
    /* Size of buffer (bytes) */
    uint64_t m_bufferSize;
    /* Offset for writing into the buffer */
    uint16_t m_offset;
    /* Chunk Size (Multiple of Page Size) */
    uint16_t m_chunkSize;
    /* Flag to indicate pending read notifications */
    bool m_pendingRead;

    /* Linux specific
     * Wait queue for this buffer
     * Readers waiting to read from this buffer
     * add themselves to this queue using poll_wait()
     * and are woken up once data is available. */
    wait_queue_head_t m_bufferWaitQueue;
    /* Poll status returned by PmcPoll() */
    atomic_t m_pollStatus;
    /* Count of mmap() calls */
    atomic_t m_mmapCount;

} PmcDataBufferContext;
