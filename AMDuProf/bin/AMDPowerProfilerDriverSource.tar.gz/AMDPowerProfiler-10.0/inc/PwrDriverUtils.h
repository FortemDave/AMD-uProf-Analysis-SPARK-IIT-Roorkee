//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrDriverUtils.h
///
//==================================================================================
#pragma once
#include <PwrDriverInternal.h>
#include <PwrCommonDataTypes.h>

#define FAMILY_EXTENDED 0x0f
#define INVALID_UINT32_VALUE 0xFFFFFFFF
#define CPUID_FnAdvancePowerManagementInformation 0x80000007
#define CPUID_FnAdvancePowerManagementInformation_EDX_EffFreqRO (1 << 10)
#define CPUID_FnAmdExtendedFeatures_ECX_PerfCtrExtCore (1 << 23)
#define CPUID_FnFeatureId 1
#define CPUID_FnThermalAndPowerManagement 6
#define CPUID_NodeIdentifiers_EBX_ThreadsPerCore (0xFF << 8)
#define CPUID_FeatureId_EBX_LogicalProcessorCount 0xFF << 16
#define CPUID_FnThermalAndPowerManagement_ECX_EffFreq  (1 << 0)
#define CPUID_FnThreadPerSocketInformation 0x80000008
#define CPUID_FnThreadPerSocketInformation_ECX_ThreadCnt (0xFF)
#define CPUID_FnIdentifiers  0x8000001E
#define CPUID_FnBrandIdIdentifier 0x80000001
#define CPUID_FnSizeID  0x80000008
#define CPUID_FnExtdPerfmonAndDebug 0x80000022
#define CPUID_FnLargFuncExtNum 0x80000000

typedef union CpuInfo
{
    struct _info
    {
        /// Bits[3:0] The Cpu stepping
        uint32 stepping : 4;
        /// Bits[7:4] The Cpu base model (model bits [3:0])
        uint32 model : 4;
        /// Bits[11:8] The Cpu base family
        uint32 family : 4;
        /// Bits[15:12] Reserved
        uint32 unknown1 : 4;
        /// Bits[19:16] The Cpu extended model (model bits[7:4])
        uint32 extModel : 4;
        /// Bits[27:20] The Cpu extended family (family = family + extFamily)
        uint32 extFamily : 8;
        /// Bits[31:28] Reserverd
        uint32 unknown2 : 4;
    } info;
    /// The value of the EAX register
    uint32 eax;
} CpuInfo;


// GetTargetCoreCount
uint32 GetTargetCoreCount(void);

//GetComputeUnitCntPerNode - get compute unit count and core count for a node
uint32 GetComputeUnitCntPerNode(void);

//GetCpuModelFamily - get CPU family id and model id
void GetCpuModelFamily(uint32* family, uint32* model);

//Is profile stopping
bool IsStoping(void);

//AccessPciAddress: Read or Write PCI address
bool AccessPciAddress(PACCESS_PCI pData);

//AccessMSRAddress: Read or write generic MSR
bool AccessMSRAddress(PACCESS_MSR pData);

// PwrGetTargetPlatform: Return the current target platform id
uint32 PwrGetTargetPlatformId(void);

// GetBitsCount: Count number of bits set
void GetBitsCount(uint64 mask, uint32* pCount);

//Is profile stopping
bool IsStarted(void);

// IsCefSupported
bool IsCefSupported(void);

// IsROCefAvailable
bool IsROCefAvailable(void);

uint64 GmmxGetBaseAddress(uint32 gpuAddr);


// Raw data file functions
bool GetRequiredBufferLength(CoreData* cfg, uint32* pLength);

int32 WriteSampleData(CoreData* cfg);

int32 WriteRawBufferHeader(RawFileHeader* pHeader, uint16 sectionCnt);

int32 WriteSectionHeaders(SectionHdrInfo* secHeader, uint64 secHeaderMask);

int32 UpdateBufferHeader(ClientData* pClient, uint16 field);

int32 WriteSampleCfgInfo(ClientData* pData, ProfileConfig* pSrcCfg);

int32 WriteSampleInfo(ClientData* pClient);

int32 WriteSections(ClientData* pClient, ProfileConfig* pSrcCfg, uint64 secMask);

int32 WriteHeader(ClientData* pClient, ProfileConfig* pSrcCfg);

bool IsPMCCounterAvailable(void);

uint32 PwrGetLogicalProcessCount(void);

bool PwrIsSmtEnabled(void);

// PwrEnablePerf: Enable perf bit
void PwrEnablePerf(bool enable);


// PwrReadCpuId : Read the Cpuid instruction
uint32 PwrReadCpuId(RegisterOffset regId, uint32 functionId);

// Get ccx count
uint32_t GetCcxCount(void);

// Get socket count
uint32_t GetSocketCount(void);

// Get node Id
uint32_t GetNodeIdForCore(uint32_t coreId);

// Get socket Id
uint32_t GetSocketIdForCore(uint32_t coreId);

// Get zen version
uint32_t GetZenVersion(void);

// GetTargetSystemInfo: Get the target system info
void GetTargetSystemInfo(PTARGET_SYSTEM_INFO* pTargetInfo);

// PwrIsRAPLAvailable: Check is RAPL counters are available
// Available only on family17
bool PwrIsRAPLAvailable(void);

// PwrIsHyperVisor: check if hypervisor is enabled
bool PwrIsHyperVisor(void);

// PwrIsIGPUAvailable: Check if iGPU is available with B0D1F0x18 register
// refer to the BKDG for this register. Available only in family 15 & 16
bool PwrIsIGPUAvailable(void);

void PwrSetExtendedApicId(TARGET_SYSTEM_INFO* pTargetInfo);

void PwrSetExtPerfMonAndDbgInfo(TARGET_SYSTEM_INFO* pTargetInfo);

// PwrGetSetBitIndex: Get the index of nth set set
uint32 PwrGetSetBitIndex(uint32 setBitId, uint32 bitMask);

// Read SMN Interface
void SmnRead(uint32 bus, uint32 address, uint32* pData);

// Write SMN Interface
void SmnWrite(uint32 bus, uint32 address, uint32 data);
// Access MMIO word
bool AccessMMIO(ACCESS_MMIO* pMMIO);

uint32 GetFirstBitSet(uint64 num);

uint32 GetBitCount(uint64 val);

uint32 GetBitCountExt(uint64* pVal);

uint32 ReadPCIDev(uint32 bus, uint32 device, uint32 func, uint32 reg);

void WritePCIDev(uint32 bus, uint32 device, uint32 func, uint32 reg, uint32 data);

bool EnableIRPerf(PTARGET_SYSTEM_INFO pTargetInfo);
