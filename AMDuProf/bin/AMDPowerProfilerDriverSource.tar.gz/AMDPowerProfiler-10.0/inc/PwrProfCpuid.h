//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrProfCpuid.h
///
//==================================================================================
#pragma once

#define CPUID_FnVendorIdentification 0
#define CPUID_FnBasicFeatures 1
// LogicalProcessorCount: logical processor count
#define CPUID_FnBasicFeatures_EBX_LogicalProcessorCount_OFFSET 16
#define CPUID_FnBasicFeatures_EBX_LogicalProcessorCount (0xFF << CPUID_FnBasicFeatures_EBX_LogicalProcessorCount_OFFSET)
// LocalApicId: initial local APIC physical ID
#define CPUID_FnBasicFeatures_EBX_LocalApicId_OFFSET 24
#define CPUID_FnBasicFeatures_EBX_LocalApicId (0xFF << CPUID_FnBasicFeatures_EBX_LocalApicId_OFFSET)
// Hypervisor: used by hypervisor to indicate guest status
#define CPUID_FnBasicFeatures_ECX_Hypervisor (1 << 31)
// APIC: advanced programmable interrupt controller (APIC) exists and is enabled
#define CPUID_FnBasicFeatures_EDX_APIC (1 << 9)
#define CPUID_FnThermalAndPowerManagement 6
// ARAT: always running APIC timer
#define CPUID_FnThermalAndPowerManagement_EAX_ARAT (1 << 2)
// EffFreq: effective frequency interface
#define CPUID_FnThermalAndPowerManagement_ECX_EffFreq (1 << 0)
#define CPUID_FnExtendedVendorIdentification 0x80000000
#define CPUID_FnAmdExtendedFeatures 0x80000001
// IBS: Instruction Based Sampling
#define CPUID_FnAmdExtendedFeatures_ECX_IBS (1 << 10)
// PerfCtrExtCore: core performance counter extensions support
#define CPUID_FnAmdExtendedFeatures_ECX_PerfCtrExtCore (1 << 23)
// PerfCtrExtNB: NB performance counter extensions support
#define CPUID_FnAmdExtendedFeatures_ECX_PerfCtrExtNB (1 << 24)
// PerfCtrExtL2I: L2I performance counter extensions support
#define CPUID_FnAmdExtendedFeatures_ECX_PerfCtrExtL2I (1 << 28)
#define CPUID_FnSizeIdentifiers 0x80000008
// ApicIdCoreIdSize: APIC ID size
#define CPUID_FnSizeIdentifiers_ECX_ApicIdCoreIdSize_OFFSET 12
#define CPUID_FnSizeIdentifiers_ECX_ApicIdCoreIdSize (0xF << CPUID_FnSizeIdentifiers_ECX_ApicIdCoreIdSize_OFFSET)
#define CPUID_FnL1CacheIdentifiers 0x80000005
#define CPUID_FnL2L3CacheIdentifiers 0x80000006
#define CPUID_FnProcessorCapabilities 0x80000007
#define CPUID_FnTLB1GIdentifiers 0x80000019
#define CPUID_FnIbsIdentifiers 0x8000001B
// RdWrOpCnt: read write of op counter supported
#define CPUID_FnIbsIdentifiers_EAX_RdWrOpCnt (1 << 3)
// BrnTrgt: branch target address reporting supported
#define CPUID_FnIbsIdentifiers_EAX_BrnTrgt (1 << 5)
// OpCntExt: IbsOpCurCnt and IbsOpMaxCnt extend by 7 bits
#define CPUID_FnIbsIdentifiers_EAX_OpCntExt (1 << 6)
// RipInvalidChk: invalid RIP indication supported
#define CPUID_FnIbsIdentifiers_EAX_RipInvalidChk (1 << 7)
#define CPUID_FnIdentifiers 0x8000001E
#define CPUID_FnIdentifiers_ECX_NodeId 0xF


