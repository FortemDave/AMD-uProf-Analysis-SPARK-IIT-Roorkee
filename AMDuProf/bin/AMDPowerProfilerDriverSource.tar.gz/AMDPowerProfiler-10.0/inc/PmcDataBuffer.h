//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcDataBuffer.h
///
//==================================================================================
#pragma once

/* Linux specific header shared by Backend
 * and Driver for buffer management. */

/* Note: Number of pages should be a power of 2 */
/* TODO: Make buffer size configurable?
 * Get page size from OsPrimitive? */
#define DATA_BUFFER_PAGE_SIZE   4096
#define DATA_BUFFER_PAGES       2
#define DATA_BUFFER_SIZE        DATA_BUFFER_PAGES * DATA_BUFFER_PAGE_SIZE

/* TODO: This should not take more than 8 bytes
 * Force alignment? */
typedef struct
{
    uint64_t m_dirty : 1;
    /* Size (bytes) of data occupied in chunk
     * (excluding meta data) */
    uint64_t m_size : 20;
    uint64_t m_reserved : 43;
} PmcBufferMetaData;
