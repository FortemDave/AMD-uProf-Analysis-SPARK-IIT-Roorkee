//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrProfInternal.h
///
//==================================================================================
#pragma once

// SYSTEM INCLUDES
#include <linux/hrtimer.h>
#include <linux/timer.h>
#include <linux/ktime.h>
#include <linux/spinlock.h>

// LOCAL INCLUDES
#include <PwrProfAsm.h>
#include <PwrCommonDataTypes.h>

typedef enum
{
    // Family is an 8-bit value and is defined as:
    // Family[7:0] = ({0000b,BaseFamily[3:0]} + ExtFamily[7:0]).
    CpuBaseFamily_MASK = 0xFU << 8,
    CpuExtFamily_MASK = 0xFFU << 20,

    // Model is an 8-bit value and is defined as:
    // Model[7:0] = {ExtModel[3:0], BaseModel[3:0]}.
    CpuBaseModel_MASK = 0xFU << 4,
    CpuExtModel_MASK = 0xFU << 16,

    CpuStepping_MASK = 0xFU << 0,
} Mask;


typedef struct _CpuSignature
{
    uint  m_value;
    bool  m_isHypervisor;
} CpuSignature;

typedef struct
{
    cpumask_t           m_affinity;
    bool                m_paused;
    bool                m_stopped;
    pid_t               m_parentPid;
} OsClientCfg;

typedef struct
{
    struct hrtimer          m_hrTimer;
    ktime_t                 m_interval;
} OsCoreCfgData;

