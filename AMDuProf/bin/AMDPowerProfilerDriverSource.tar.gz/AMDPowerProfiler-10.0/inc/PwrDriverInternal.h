//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrDriverInternal.h
///
//==================================================================================
#pragma once
#include <PwrProfInternal.h>
#include <PwrCommonDataTypes.h>
#include <PwrAccessPmcData.h>

/// Header buffer size
#define HEADER_BUFFER_SIZE 4096

// Client Data
// This struct is created when a client registers with the
// driver. Only one client can be registered with driver due
// to the SMU limitaiton.
typedef struct ClientData
{
    uint32      m_clientId;
    uint32      m_validClient;
    uint32      m_isOffline;
    uint32      m_configCount;
    uint32      m_profileState;
    PageBuffer  m_header;
    OsClientCfg m_osClientCfg;
    uint32      m_clientType;
#if defined (_WIN32)
    uint32      m_profileType;
#endif
} ClientData;

// CoreData
//
// This structure holds the data for percore configurations.
// In windows this structure will be created for configured cores
// In case of Linux this structure will be created for all available
// cores in the platform
typedef struct CoreData
{
    uint32               m_clientId;
    uint32               m_sampleId;
    uint32               m_profileType;
    uint32               m_samplingInterval;
    uint32               m_recLen;
    uint32               m_coreId;
    uint32               m_bufferSize;
    uint32               m_skipFirst;
    ContextData          m_contextData;
    PageBuffer*          m_pCoreBuffer;
    PTARGET_SYSTEM_INFO  m_pSysInfo;
    uint64               m_counterMask;
    SmuList*             m_smuCfg;
    OsCoreCfgData*       m_pOsData;
    PmcCounters          m_pmc[PMC_EVENT_MAX_CNT];
    PwrInternalAddr      m_internalCounter;
} CoreData;



