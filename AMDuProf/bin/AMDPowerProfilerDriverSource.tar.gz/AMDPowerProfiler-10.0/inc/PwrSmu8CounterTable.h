//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrSmu8CounterTable.h
///
//==================================================================================
#pragma once

// This table contains all supported counters for power profile
// Need to modify incase we need to add/remove supported
// counters in the list.
typedef struct _Smu8CounterTable
{
    //T_calc
    uint32 T_calc_cu[2];
    uint32 T_calc_vddgfx;

    //P_calc
    uint32 P_calc_cu[2];
    uint32 P_calc_vddgfx;
    uint32 P_calc_vddnb;
    uint32 P_calc_vddio;
    uint32 P_calc_vddp;
    uint32 P_calc_roc;

    uint32 P_calc_apu;

    uint32 P_calc_uvd;
    uint32 P_calc_vce;
    uint32 P_calc_acp;
    uint32 P_calc_unb;
    uint32 P_calc_smu;

    //I_calc
    uint32 I_calc_vdd;
    uint32 I_calc_vddgfx;
    uint32 I_calc_vddnb;

    //V_calc
    uint32 V_calc_vdd;
    uint32 V_calc_vddgfx;
    uint32 V_calc_vddnb;

    //Effective Clock Frequencies
    uint32 Sclk_frequency;
    uint32 Aclk_frequency;

    //Cstate residencies
    uint32 C0_residency[2];
    uint32 C1_residency[2];
    uint32 CC6_residency[2];

    //TDP
    uint32 Tdp;
} Smu8CounterTable;

// CounterTableInfo: Counter table list
typedef struct _CounterTableInfo
{
    uint32             m_versionId;
    Smu8CounterTable   m_table;
} CounterTableInfo;

#define SMC_RESULT_OK                           ((uint8_t)(0x1))
#define COUNTER_TABLE_VERSION_MSG_ID            ((uint8_t)0x40)


