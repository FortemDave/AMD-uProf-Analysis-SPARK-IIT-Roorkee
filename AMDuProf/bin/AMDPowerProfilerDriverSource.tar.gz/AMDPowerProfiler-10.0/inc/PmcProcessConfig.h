//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcProcessConfig.h
///
//==================================================================================
#pragma once

#include <PmcInterface.h>
#include <PmcCommonDataTypes.h>

// TODO: Remove this now that we have a similar file for windows
#if defined(__linux__)
    #include <PmcDataBufferOps.h>
#endif

int AddPmcConfigGroup(CoreContext* pCoreCtx,
                      PmcPmuType type,
                      PmcConfigGroup* pPmcConfigGroup);

int AllocatePmcConfigGroup(PmcConfigGroup** ppPmcConfigGroup,
                           uint64_t pmcConfigArray[],
                           uint32_t pmcConfigCount,
                           uint16_t maxPmcCnt,
                           uint16_t groupAttrs,
                           uint64_t groupId,
                           uint32_t availabilityMask,
                           uint32_t umcMask,
                           PmcPmuType type);

void FreePmcConfigGroup(ClientContext* pClientCtx);

int AllocateCoreContext(ClientContext* pClientCtx);
void FreeCoreContext(ClientContext* pClientCtx);

int AllocateCoreMaskArray(ClientContext* pClientCtx);
void FreeCoreMaskArray(ClientContext* pClientCtx);

int AllocateDataBufferContext(ClientContext* pClientCtx);
void FreeDataBufferContext(ClientContext* pClientCtx);

int ProcessCountModeProfileConfig(ClientContext* pClientCtx,
                                  CountModeProfileConfig* pConfig);

int ReadPmcConfigGroup(PmcConfigGroup* pPmcConfigGroup, PmcPmuType type, uint32_t umcMask);
int PmcSampleDataCallBack(CoreContext* pCoreCtx,
                          PmcPmuType type,
                          uint32_t recordSize);

int MultiplexPmcConfigGroup(CoreContext* pCoreCtx, PmcPmuType type);
void ResetPmcCounters(CoreContext* pCoreCtx, PmcPmuType type);
void* PmcGetDataBuffer(PmcDataBufferContext* pCtx, uint64_t recordSize);
int PmcCallBack(ClientContext* pClientCtx, CoreContext* pCoreCtx);
void ResetPmcConfigGroup(CoreContext* pCoreCtx, PmcPmuType type);

int AllocateClientContext(uint32_t clientId);
void FreeClientContext(uint32_t clientId);

int AllocateUmcMaskArray(ClientContext* pClientCtx);
void FreeUmcMaskArray(ClientContext* pClientCtx);

int PmcStartProfiler(void);
int PmcStopProfiler(void);
void PmcClearProfiler(void);
int PmcPauseProfiler(void);
int PmcResumeProfiler(void);
