//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrProfSharedMemOps.h
///
//==================================================================================
#pragma once

int CreateAnonInodeFd(void);

struct pp_anon_inode_ctx
{
    unsigned int     count;
    struct mutex     mmap_mutex;
    atomic_t         mmap_count;
    unsigned int     order;
    size_t           mmap_size;
    uint64_t         mmaped_address;
    unsigned int     flags;
};
