//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrCollectSmuCounters.cpp
///
//==================================================================================
// LOCAL INCLUDES
#include <PwrDriverUtils.h>
#include <PwrSmu9Interface.h>
#include <PwrCommonConfig.h>
#include <PwrCommonDataTypes.h>

//////////////Smu9 defines and prototypes/////////////////////////

uint32 PwrGetSmu9Am4Table0x001900010Size(void);

uint32 PwrGetSmu9Am4Table0x002B0000Size(void);

uint32 PwrGetSmu9Sp3TableSize(void);

uint32 PwrGetSmu9Sp4TableSize(void);

uint32 PwrGetSmu9MaxCounterId(void);

// PwrGetSmu9CounterSize: Get size of each counter
uint32 PwrGetSmu9CounterSize(uint32 counterId);

// PwrSmu9SP3CollectRegisterValues: Get the Smu9 register values.
bool PwrSmu9SP3CollectRegisterValues(uint64 tableBaseAddr, void* pSmuInfo, uint8* pData, uint32* pLength);

// PwrSmu9SP4CollectRegisterValues: Get the Smu9 register values.
bool PwrSmu9SP4CollectRegisterValues(uint64 tableBaseAddr, void* pSmuInfo, uint8* pData, uint32* pLength);

// PwrSmu9AM4CollectRegisterValues0x00190001: Get the Smu9 register values.
bool PwrSmu9AM4CollectRegisterValues0x00190001(uint64 tableBaseAddr, void* pSmuInfo, uint8* pData, uint32* pLength);

// PwrSmu9AM4CollectRegisterValues0x002B0000: Get the Smu9 register values.
bool PwrSmu9AM4CollectRegisterValues0x002B0000(uint64 tableBaseAddr, void* pSmuInfo, uint8* pData, uint32* pLength);

//////////////Smu10 defines and prototypes/////////////////////////
#define PWR_SMU9_VEGA10_TABLE_VERSION 0x00000002
uint32 PwrGetSmu10TableSize(void);

uint32 PwrGetSmu10MaxCounterId(void);

// PwrSmu10CollectFP5RegisterValues: Get the Smu10 register values.
bool PwrSmu10CollectFP5RegisterValues(uint64 tableBaseAddr, void* pSmuInfo, uint8* pData, uint32* pLength);

// PwrSmu10GetCounterSize: Get size of each counter
uint32 PwrSmu10GetCounterSize(uint32 counterId);


//////////////Smu9 vega10 defines and prototypes/////////////////////////
#define PWR_SMU10_TABLE_VERSION_RV 0x001E0004
uint32 PwrGetSmu9Vega10TableSize(void);

uint32 PwrGetSmu9Vega10MaxCounterId(void);

bool PwrVega10CollectRegisterValues(uint64 tableBaseAddr, void* pSmuInfo, uint8* pData, uint32* pLength);

// PwrGetSmu9Vega10CounterSize: Get size of each counter
uint32 PwrGetSmu9Vega10CounterSize(uint32 counterId);


