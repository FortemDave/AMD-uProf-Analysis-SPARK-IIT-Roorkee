//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrSmu7Interface.h
///
//==================================================================================

#pragma once

#include "PwrDriverTypedefs.h"

// Smu7IndexData: Smu7 MMIO offset for data access
typedef struct
{
    uint32 m_index;
    uint32 m_data;
} Smu7IndexData;

// Smu7Logging: Smu7 message logging ids
typedef struct
{
    uint32 m_start;
    uint32 m_dump;
} Smu7Logging;

// Smu7MessageParam: Smu7 message exchange parameters
typedef struct
{
    uint32 m_msgId;
    uint32 m_resp;
    uint32 m_arg;
    uint32 m_fill;
} Smu7MessageParam;

//Smu7CounterTable: SMU7 counter table
typedef struct
{
    uint32 m_pwrCu0;
    uint32 m_pwrCu1;
    uint32 m_tempCalcCu0;
    uint32 m_tempCalcCu1;
    uint32 m_tempMeasCu0;
    uint32 m_tempMeasCu1;
    uint32 m_pwriGpu;
    uint32 m_pwrPcie;
    uint32 m_pwrDdr;
    uint32 m_pwrDisplay;
    uint32 m_pwrPackage;
    uint32 m_tempCalcGpu;
    uint32 m_tempMeasGpu;
    uint32 m_sclk;
    uint32 m_voltVddcLoad;
    uint32 m_currVddc;
} Smu7CounterTable;

// Smu7Interface: Smu7 interfacing structure
typedef struct
{
    uint64           m_gpuBaseAddress;
    uint64           m_mappedAddress;
    uint64           m_mappedSize;
    uint64           m_indexDataPair;
    uint64           m_indexDataPairSize;
    Smu7CounterTable m_counterTable;
    Smu7MessageParam m_messageParam;
    Smu7Logging      m_logging;
    Smu7IndexData    m_indexData;
} Smu7Interface;

// CollectSMU8RegisterValues: Collect all SMU counter values
// based on the mask set and fill in the pData
bool CollectSMU7RegisterValues(void* pSmu,
                               uint8* pData,
                               uint32* pLength);

// Smu7SessionInitialize:
bool Smu7SessionInitialize(void* pSmu);

// Smu7SessionClose
bool Smu7SessionClose(void* pSmu);

// GetSmu7CounterSize
uint32 GetSmu7CounterSize(uint32 counterId);

// GetSmu7DgpuCounterSize
uint32 GetSmu7DgpuCounterSize(uint32 counterId);

