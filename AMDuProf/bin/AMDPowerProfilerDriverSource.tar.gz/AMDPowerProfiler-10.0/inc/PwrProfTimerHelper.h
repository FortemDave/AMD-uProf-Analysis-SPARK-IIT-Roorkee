//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrProfTimerHelper.c
///
//==================================================================================
#pragma once

#include <PwrDriverInternal.h>

// AllocateAndInitClientData
//
// Allocate and Initialise Client Data
int AllocateAndInitClientData(ClientData** ppClientData,
                              uint32 clientId,
                              cpumask_t affinity,
                              pid_t parentPID,
                              const ProfileConfig* config);

// IntialiseCoreData
//
// Initialise and  per core data
int IntializeCoreData(CoreData* pCoreClientData,
                      int index,
                      bool* isFirstConfig,
                      uint32 clientId,
                      uint32 coreId,
                      ProfileConfig* config);

// FreeClientData
//
// Free Memmory set by client data
void FreeClientData(ClientData* pClientData);

// FreeCoreData
//
// Free Memory created for each core
void FreeCoreData(CoreData* pCoreClientData);

