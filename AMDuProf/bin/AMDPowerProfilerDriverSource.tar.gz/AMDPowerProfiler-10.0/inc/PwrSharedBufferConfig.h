//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrSharedBufferConfig.h
///
//==================================================================================
#pragma once

#define DEFAULT_PAGE_SIZE 4096

#define PWRPROF_MAX_MEM_ORDER  32
// 1K for all core buffer parameter other than buffers
#define PWRPROF_SHARED_METADATA_SIZE 4096

// 16 pages are allocated for the master core
#define PWRPROF_MASTER_CORE_BUFFER_SIZE (65536)

// 3 pages are allocated for remaining cores
// For Stones 3 pages X 384 core, memory allocation fails
// Since all SMU counters are removed, 2 pages per core should be sufficient
// #define PWRPROF_NONMASTER_CORE_BUFFER_SIZE (12288)
#define PWRPROF_NONMASTER_CORE_BUFFER_SIZE (8192)

inline static unsigned int PwrGetSharedBufferSize(unsigned int coreCnt)
{
    unsigned int order = 0;
    unsigned int size = PWRPROF_SHARED_METADATA_SIZE
                        + PWRPROF_MASTER_CORE_BUFFER_SIZE
                        + (PWRPROF_NONMASTER_CORE_BUFFER_SIZE * (coreCnt - 1));

    for (order = 0; order < PWRPROF_MAX_MEM_ORDER; order++)
    {
        unsigned int blockSize = (1UL << order) * DEFAULT_PAGE_SIZE;

        if (blockSize > size)
        {
            size = blockSize;
            break;
        }
    }

    return size;
}

/* Pmc per core buffer size calculation
 * Allocate enough space to accomadate 128 event sets for core pmc
 * Sample size for core events (using 4 attributes per group and max counters occupancy)
 *  Sample Header - 8 bytes
 *  Time stamp - 8 bytes
 *  Core Id - 8 bytes
 *  Group Attr size - 8 bytes * 4 Attrs * 128 event groups -> 4096 bytes
 *  Counter values - 8 bytes * 8 counters * 128 event groups -> 8192 bytes
 *  Group Header size - 8 bytes * 128 event groups -> 1024 bytes
 *  Total size per core - 13,336 bytes  (~4 pages)
 *
 * Assuming max 128 event sets for L3
 *  Total size per core - 13,336 bytes (~4 pages)
 *
 * Assuming max 2048 event sets for Df (max 16 counters)
 *  Total size - 344,088 bytes (~85 pages rounded to 128 pages)
 *
 * Max buffer size:
 * Assuming a maximum of 1024 cores
 *  Max size for core -> 4 * 1024 pages
 *
 * Assuming max 128 l3 complexs/ccxs
 * Max size for l3 -> 4 * 128 pages
 *
 * Assuming max 2 sockets
 *  Max size for df -> 128 * 2 pages
 *
 * Max buffer size -> 4864 pages
       Rounded to nearest power of 2 multiple of page size 8192 pages(2^13 pages ~ 32MB)
 */

// Allocate 4 required pages per core for core pmc
#define PMC_CORE_BUFFER_SIZE            (4 * DEFAULT_PAGE_SIZE)

// Allocate 4 required pages per core for l3 pmc
#define PMC_L3_BUFFER_SIZE              (4 * DEFAULT_PAGE_SIZE)

// Allocate 26 required pages per core for df pmc
#define PMC_DF_BUFFER_SIZE              (128 * DEFAULT_PAGE_SIZE)

#define PMC_UMC_BUFFER_SIZE             (64 * DEFAULT_PAGE_SIZE)
inline static unsigned int PmcGetSharedBufferSize(unsigned int coreCnt, unsigned int ccxCnt, unsigned int socketCnt)
{
    unsigned int order = 0;
    unsigned int size = (PMC_CORE_BUFFER_SIZE * coreCnt + PMC_L3_BUFFER_SIZE * ccxCnt + PMC_DF_BUFFER_SIZE * socketCnt + PMC_UMC_BUFFER_SIZE * socketCnt);

    for (order = 0; order < PWRPROF_MAX_MEM_ORDER; order++)
    {
        unsigned int blockSize = (1UL << order) * DEFAULT_PAGE_SIZE;

        if (blockSize > size)
        {
            size = blockSize;
            break;
        }
    }

    return size;
}