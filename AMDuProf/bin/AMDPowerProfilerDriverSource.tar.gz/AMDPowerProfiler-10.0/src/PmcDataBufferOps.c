//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcDataBufferOps.c
///
//==================================================================================

#include <linux/fs.h>
#include <linux/poll.h>
#include <linux/anon_inodes.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/wait.h>
#include <linux/version.h>
// Note: This is included to avoid
// compilation failure on older kernels
#include <linux/sched.h>

#include <PmcDataBufferOps.h>
#include <PwrOsPrimitives.h>

/* MmapOpen is usually called to initialize the vm area
 * and when a new reference to vma is made (during process fork) */
void PmcMmapOpen(struct vm_area_struct *vma)
{
    PmcDataBufferContext *pDataBufferCtx = NULL;

    if (vma != NULL && vma->vm_file != NULL && vma->vm_file->private_data != NULL)
    {
        pDataBufferCtx = (PmcDataBufferContext*)vma->vm_file->private_data;

        DRVPRINT("vma(%p) vm_file(%p) private_data(%p) pDataBufferCtx(%p)",
            vma, vma->vm_file, vma->vm_file->private_data, pDataBufferCtx);

        // Increment ref count
        atomic_inc(&pDataBufferCtx->m_mmapCount);
    }
}

void PmcMmapClose(struct vm_area_struct *vma)
{
    PmcDataBufferContext *pDataBufferCtx = NULL;
    void *pDataBuffer = NULL;
    //int i = 0;
    //int j = 0;

    if (vma != NULL && vma->vm_file != NULL)
    {
        pDataBufferCtx = (PmcDataBufferContext*)vma->vm_file->private_data;
        if (pDataBufferCtx != NULL)
        {
            DRVPRINT("vma(%p) pDataBufferCtx(%p) pBuffer(%p)",
                vma, pDataBufferCtx, pDataBufferCtx->m_pBuffer);

            atomic_dec(&pDataBufferCtx->m_mmapCount);

            pDataBuffer = pDataBufferCtx->m_pBuffer;
            if (pDataBuffer != NULL)
            {
                /* Debugging: Dump the contents of data buffer */
                /*for (i = 0; i < pDataBufferCtx->m_bufferSize; i++, j++)
                {
                    printk(KERN_CONT "%02hhx", *((unsigned char*)pDataBuffer + i));

                    if (j == 15)
                    {
                        printk(KERN_CONT "\n");
                        j = 0;
                    }
                }*/

                if (0 == atomic_read(&pDataBufferCtx->m_mmapCount))
                {
                    kfree(pDataBuffer);
                    pDataBuffer = NULL;
                }
            }
            else
            {
                DRVPRINT("Invalid Data Buffer. pDataBuffer(%p)", pDataBuffer);
            }
        }
        else
        {
            DRVPRINT("Invalid Data Buffer Context. pDataBufferContext(%p)",
                pDataBufferCtx);
        }

        DRVPRINT("pDataBufferCtx(%p) pBuffer(%p)",
            pDataBufferCtx, pDataBufferCtx->m_pBuffer);
    }
}

// TODO: Function signature varies for linux versions
// using the latest version for now
// This function gets called when the mapped region is accessed
// the first time.
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 17, 0)
    vm_fault_t PmcMmapFault(struct vm_fault *vmf)
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
    int PmcMmapFault(struct vm_fault* vmf)
#else
    int PmcMmapFault(struct vm_area_struct* vma, struct vm_fault* vmf)
#endif
{

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
    struct vm_area_struct* vma = vmf->vma;
#endif

// TODO: What kernel version was vm_fault_t introduced?
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 17, 0)
    // TODO: What should this be initialized to?
    // For now initialize to 0
    // Or should be initialized to VM_FAULT_SIGBUS?
    vm_fault_t retVal = 0;
#else
    int retVal = 0;
#endif

    PmcDataBufferContext *pDataBufferCtx = NULL;
    void *pDataBuffer = NULL;

    if (vmf == NULL || vma == NULL || vma->vm_file == NULL)
    {
        //TODO: Figure out the correct return value
        retVal = VM_FAULT_SIGBUS;
    }

    if (!retVal)
    {
        pDataBufferCtx = (PmcDataBufferContext*)vma->vm_file->private_data;
        if (pDataBufferCtx == NULL)
        {
            retVal = VM_FAULT_NOPAGE;
        }
    }

    if (!retVal)
    {
        DRVPRINT("vmf(%p) pgoff(%lu) pDataBufferCtx(%p) pBuffer(%p)",
            vmf, vmf->pgoff, pDataBufferCtx, pDataBufferCtx->m_pBuffer);

        pDataBuffer = pDataBufferCtx->m_pBuffer;
        if (pDataBuffer == NULL)
        {
            retVal = VM_FAULT_NOPAGE;
        }

        if (!retVal)
        {
            // TODO: What happens in fault handler?
            // Fault handlers need to return vmf->page
            // What does virt_to_page do?
            // TODO: Add pgoff before virt_to_page for data buffer
            vmf->page = virt_to_page((char*)pDataBuffer + (vmf->pgoff * 4096));

            // Increment ref count for the page
            get_page(vmf->page);

            // TODO: What do these represent
            //vmf->page->mapping;
            //vmf->page->index;
        }
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

struct vm_operations_struct PmcMmapVmOps =
{
    .open = PmcMmapOpen,
    .close = PmcMmapClose,
    .fault = PmcMmapFault,
};

int PmcMmap(struct file *pFile, struct vm_area_struct *vma)
{
    int retVal = 0;
    //struct page *pPage = NULL;
    //unsigned int order = 0;
    uint32_t node = 0;
    void *pDataBuffer = NULL;
    size_t bufferSize = 0;
    PmcDataBufferContext *pDataBufferCtx = NULL;

    if (pFile == NULL || vma == NULL || pFile->private_data == NULL)
    {
        retVal = EINVAL;
    }

    if (retVal == 0)
    {
        pDataBufferCtx = (PmcDataBufferContext*)pFile->private_data;

        DRVPRINT("pFile(%p) vma(%p) pDataBufferCtx(%p)", pFile, vma, pDataBufferCtx);

        // TODO: Can also check for mlock_limit here
        // TODO: What vm flags do we need to check/set?
        vma->vm_ops = &PmcMmapVmOps;
        vma->vm_file->private_data = pFile->private_data;

        node = cpu_to_node(pDataBufferCtx->m_coreId);

        /*
        order = pDataBufferContext->m_order;

        // TODO: Will need to save the page struct references to free them
        // later
        pPage = alloc_pages_node(node, GFP_KERNEL | __GFP_ZERO, order);
        if (pPage != NULL)
        {
            pDataBufferContext->m_pDataBuffer = page_to_address(pPage);
        }
        */

        bufferSize = pDataBufferCtx->m_bufferSize;

        /* kzalloc_node is a variant of kmalloc and the documentation says
         * not to use kmalloc for > page size allocations.*/
        // TODO: Change this to vmalloc or other
        pDataBuffer = kzalloc_node(bufferSize, GFP_KERNEL, node);
        if (pDataBuffer != NULL)
        {
            pDataBufferCtx->m_pBuffer = pDataBuffer;
        }

        // Mmap Open() is not called during the userspace mmap()
        // call and hence invoked here
        PmcMmapOpen(vma);

        DRVPRINT("coreId(%u) pDataBuffer(%p) bufferSize(%lubytes)",
                 pDataBufferCtx->m_coreId, pDataBuffer, bufferSize);
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

int PmcOpen(struct inode *pInode, struct file *pFile )
{
    int retVal = 0;

    return retVal;
}

unsigned int PmcPoll(struct file *pFile, poll_table *wait)
{
    unsigned int pollStatus = 0;
    PmcDataBufferContext* pDataBufferCtx = pFile->private_data;

    /* Add thread to buffer waitqueue */
    poll_wait(pFile, &pDataBufferCtx->m_bufferWaitQueue, wait);

    // TODO: Return POLLHUP if profiler has stopped
    pollStatus = atomic_xchg(&pDataBufferCtx->m_pollStatus, 0);

    return pollStatus;
}

/* TODO: Remove operations we will not be implementing */
struct file_operations pmcFops =
{
    //.llseek     = PmcLlseek,
    //.read       = PmcRead,
    //.write      = PmcWrite,
    .poll       = PmcPoll,
    .mmap       = PmcMmap,
    //.open       = PmcOpen,
    //.fasync     = PmcFasync,
};

void InitDataBufferWaitQueue(PmcDataBufferContext* pDataBufferCtx)
{
    init_waitqueue_head(&pDataBufferCtx->m_bufferWaitQueue);
}

void NotifyPendingRead(PmcDataBufferContext* pDataBufferCtx)
{
    atomic_set(&pDataBufferCtx->m_pollStatus, POLL_IN);

    /* TODO: Add a timeout here? */
    wake_up_interruptible(&pDataBufferCtx->m_bufferWaitQueue);
}

int _CreatePmcFileDescriptors(ClientContext *pClientCtx,
                              PmcPmuType type,
                              uint64_t* pCoreMaskArray,
                              int* pFdArray,
                              uint32_t *pFdArrayIdx)
{
    int retVal = 0;
    int i = 0;
    int j = 0;
    int coreId = 0;
    void* privateData = NULL;
    CoreContext *pCoreCtx = NULL;
    uint64_t coreMask = 0;
    int fd = -1;

    DRVPRINT("pClientCtx(%p) type(%d) pCoreMaskArray(%p) pFdArray(%p) pFdArrayIdx(%p)",
            pClientCtx, type, pCoreMaskArray, pFdArray, pFdArrayIdx);

    if (pClientCtx == NULL || pCoreMaskArray == NULL || pFdArray ==  NULL || pFdArrayIdx == NULL)
    {
        retVal = EINVAL;
    }

    for (i = 0, coreId = 0; i < PMC_CORE_MASK_ARRAY_SIZE && !retVal; i++)
    {
        coreMask = pCoreMaskArray[i];

        for (j = 0; j < PMC_CORE_MASK_BIT_WIDTH && !retVal; j++, coreId++)
        {
            if (coreMask & (1ULL << j))
            {
                pCoreCtx = &pClientCtx->m_pCoreContext[coreId];
                if (pCoreCtx == NULL)
                {
                    retVal = EINVAL;
                    break;
                }

                privateData = (void*)pCoreCtx->m_pDataBufferContext[type];
                if (privateData == NULL)
                {
                    retVal = EINVAL;
                    break;
                }

                fd = anon_inode_getfd("Pmc Driver",
                                      &pmcFops,
                                      privateData,
                                      O_RDWR | O_CLOEXEC);

                /*TODO: Is fd == 0 a valid scenario? */
                if (fd < 0)
                {
                    retVal = fd;
                }

                if (!retVal)
                {
                    pFdArray[*pFdArrayIdx] = fd;
                    (*pFdArrayIdx)++;
                }

                DRVPRINT("fd[%d](%d)", *pFdArrayIdx, fd);
            }
        }
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

int CreatePmcFileDescriptors(CountModeProfileConfig* pConfig,
                             ClientContext* pClientCtx)
{
    PmcPmuType type = PMC_PMU_INVALID;
    int retVal = 0;
    uint32_t fdArrayIdx = 0;

    DRVPRINT("pConfig(%p) pClientCtx(%p)", pConfig, pClientCtx);

    if (pClientCtx == NULL || pConfig == NULL)
    {
        retVal = EINVAL;
    }

    for (type = PMC_PMU_CORE; type < PMC_PMU_MAX && !retVal; type++)
    {
        /* Skip if there are no valid configurations for pmc type */
        if (pClientCtx->m_pmcConfigGroupCnt[type] == 0)
        {
            continue;
        }

        retVal = _CreatePmcFileDescriptors(pClientCtx,
                                           type,
                                           pClientCtx->m_pPmcCoreMaskArray[type],
                                           pConfig->m_fdArray,
                                           &fdArrayIdx);
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

// TODO: Do i need to close() fds allocated with anon_inode_getfd?
