//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrProfEntry.c
///
//==================================================================================
// PROJECT INCLUDES
#include <linux/uaccess.h>
#include <linux/slab.h>

#include <PwrDriverTypedefs.h>
#include <PwrDriverIoctls.h>

// LOCAL INCLUDES
#include <PwrOsPrimitives.h>
#include <PwrDriverUtils.h>
#include <PwrCommonDataTypes.h>
#include <PwrVersion.h>
#include <PwrProfSharedMemOps.h>
#include <PwrProfTimer.h>
#include <PmcInterface.h>
#include <PmcProcessConfig.h>

// LOCAL VARIABLES
//

// EXTERN FUNCTIONS
long CheckHwSupport(void);
extern int moduleState;

// STATIC VARIABLES
// Minor build version for pcore
static unsigned int pcore_build_number = 001;

// Client id and state
static unsigned long g_clientId = 0L;
static bool g_isClientActiv = false;
static bool g_isClientStateDirty  = false;

// ToDo: Initialize to INVALID_CLIENT_ID for all clients
static int32_t g_pmcClientId = INVALID_CLIENT_ID;

ClientContext* g_pPmcClientContext = NULL;

// LOCAL FUNCTIONS

// delete the client from the client list
// ToDo: This function should take clientId as parameter or
// delete all clients
void DeleteClient(void)
{
    g_isClientActiv = false;
    g_clientId = 0;
    UnconfigureTimer(g_clientId);

    // Release memory pool
    ReleaseMemoryPool(&g_sessionPool);
}

// Mark the client for cleanup.
// ToDo: Does this function clean up instead of marking for clean up?
void MarkClientForCleanup(unsigned long id)
{
    if (id == g_clientId)
    {
        // Stop the timer
        StopTimer(g_clientId);

        g_isClientActiv         = false;
        g_isClientStateDirty    = true;
        moduleState             = 0;
    }
    else
    {
        printk("Power Profiler: Incorrect Client id. \n");
    }
}

int RegisterClient(ClientType type, uint32_t* pClientId)
{
    int retVal = 0;

    DRVPRINT("type(%d) clientId(%p)", type, pClientId);

    if (pClientId == NULL)
    {
        retVal = EINVAL;
    }

    if (!retVal)
    {
        if (type == CLIENT_TYPE_PMC)
        {
            if (g_pmcClientId != INVALID_CLIENT_ID)
            {
                DRVPRINT(KERN_INFO "Max one client permitted. ");
                retVal = -EACCES;
            }
            else
            {
                /* Note: Since we support a single client
                 * for Pmc, hardcoding the id for now */
                g_pmcClientId = PMC_CLIENT_ID;
                *pClientId = g_pmcClientId;

                retVal = AllocateClientContext(*pClientId);
            }
        }
        else if (type == CLIENT_TYPE_PWR_PROFILER)
        {
            if (g_isClientActiv)
            {
                DRVPRINT(KERN_INFO "Power Profiler: Max one instance of Power Profiler client run permitted. ");
                retVal = -EACCES;
            }

            g_isClientActiv = true;
            *pClientId = g_clientId;
        }
        else
        {
            DRVPRINT(KERN_INFO "Invalid client type. ");
            retVal = -EINVAL;
        }
    }

    DRVPRINT("clientId(%lu) retVal(%d)", (unsigned long int)*pClientId, retVal);

    return retVal;
}

int UnregisterClient(uint32_t clientId)
{
    int retVal = 0;

    DRVPRINT("clientId(%lu)", (unsigned long int)clientId);

    if (clientId == PMC_CLIENT_ID)
    {
        if (g_pmcClientId != INVALID_CLIENT_ID)
        {
            FreeClientContext(clientId);
            g_pmcClientId = INVALID_CLIENT_ID;
        }
        else
        {
            DRVPRINT(KERN_INFO "Client already unregistered.");
        }
    }
    else if (clientId == 0)
    {
        g_isClientActiv = false;
        g_clientId = 0;

        DeleteClient();
    }
    else
    {
        DRVPRINT(KERN_INFO "Invalid client id. ");
        retVal = -EINVAL;
    }

    DRVPRINT("clientId(%x) retVal(%d)", clientId, retVal);

    return retVal;
}

int StartProfiler(uint32_t clientId)
{
    int retVal = 0;

    if (clientId == PMC_CLIENT_ID)
    {
        PmcStartProfiler();
    }
    else if (clientId == 0)
    {
        retVal = StartTimer(clientId);
    }
    else
    {
        /* Invalid client Id */
    }

    return retVal;
}

int StopProfiler(uint32_t clientId)
{
    int retVal = 0;

    if (clientId == PMC_CLIENT_ID)
    {
        PmcStopProfiler();
    }
    else if (clientId == 0)
    {
        retVal = StopTimer(clientId);
    }
    else
    {
        /* Invalid client Id */
    }

    return retVal;
}

int ClearProfiler(uint32_t clientId)
{
    int retVal = 0;

    if (clientId == PMC_CLIENT_ID)
    {
        PmcClearProfiler();
    }
    else if (clientId == 0)
    {
        // Not used by power profiler
    }
    else
    {
        /* Invalid client Id */
    }

    return retVal;
}

// IOCTL implementation for driver.
// mapping File opertaions for the pcore driver module.
long PwrProfDrvIoctlImpl(struct file* file, unsigned int ioctl_num, unsigned long ioctl_param)
{
    int retval                  = 0;
    uint32 clientId             = 0;
    unsigned int tmp1           = 0;
    uint64_t version            = 0;
    uint64_t stop_client_id     = 0;
    int anon_inode_fd           = -1;
    unsigned long tmp_client_id = 0;
    ClientType clientType = CLIENT_TYPE_INVALID;

    PROFILER_PROPERTIES profProps;
    PROF_CONFIGS profConfigs;
    ProfileConfig* pProfConfig;

    FILE_HEADER file_header;
    DATA_BUFFER data_buffer;

    PACCESS_PCI pPci;
    ACCESS_MMIO mmio;

    CountModeProfileConfig* pConfig = NULL;
    CountModeGroupConfig* pGroupConfig = NULL;
    DRVPRINT("device_ioctl: ioctl_num(%x) ioctl_param(%p)", ioctl_num, (void*)ioctl_param);

    switch (ioctl_num)
    {
        case IOCTL_GET_VERSION:
            DRVPRINT(" In get version Ioctl");
            version  = (unsigned long)LINUX_PWR_DRV_MAJOR << 32 | (unsigned int)LINUX_PWR_DRV_MINOR;
            DRVPRINT(" Power Profiler version is %llx ", version);

            retval = copy_to_user((unsigned long*) ioctl_param, &version, sizeof(unsigned long));
            return retval;

        case IOCTL_REGISTER_CLIENT:
            DRVPRINT("In register Client Ioctl");

            retval = copy_from_user(&clientType, (ClientType*)ioctl_param,
                                    sizeof(ClientType));

            //DRVPRINT("clientType(%d) retval(%d)", clientType, retval);

            if (retval)
            {
                DRVPRINT(KERN_WARNING "Failed to get client type. %d", retval);
            }

            if (!retval)
            {
                retval = RegisterClient(clientType, &clientId);

                if (retval < 0)
                {
                    DRVPRINT(KERN_WARNING "Failed to register client. %d", retval);
                }
            }

            if (!retval)
            {
                retval = copy_to_user((uint32_t*)ioctl_param,
                                      &clientId, sizeof(uint32_t));

                if (retval < 0)
                {
                    // if in previous run we have not clean the configuration
                    //  delete the old client config
                    if ((clientId == 0) && (true == g_isClientStateDirty))
                    {
                        // TODO: Assuming only one client id can exist
                        // Clean the old configuration
                        DeleteClient();
                        g_isClientStateDirty = false;
                    }

                    DRVPRINT(KERN_WARNING "Failed to set client Id. %d", retval);
                }
            }

            return retval;

        case IOCTL_UNREGISTER_CLIENT:
            retval = 0;
            DRVPRINT("In un register Client Ioctl");

            if (copy_from_user(&tmp1, (uint32_t*)ioctl_param, sizeof(uint32_t)) == 0)
            {
                DRVPRINT("UnRegistering client %u", tmp1);
            }
            else
            {
                DRVPRINT(KERN_WARNING "Invalid parameter to Unregister Client");
                return -1;
            }

            retval = UnregisterClient(tmp1);

            return retval;

        case IOCTL_ADD_PROF_CONFIGS:
            retval = 0;
            /* Extract the configuration information */
            DRVPRINT("In Add Profile Configs Ioctl");

            pProfConfig = (ProfileConfig*)kzalloc(sizeof(ProfileConfig), GFP_KERNEL);

            if (pProfConfig == NULL)
            {
                retval = -ENOMEM;
            }

            if (!retval && copy_from_user(&profConfigs, (PROF_CONFIGS*)ioctl_param, sizeof(PROF_CONFIGS)) == 0)
            {
                DRVPRINT("Adding profile for client %u", profConfigs.m_clientId);
            }
            else
            {
                DRVPRINT(KERN_WARNING "Invalid parameter to Add profile Config");
                retval = -1;
            }

            if (!retval)
            {
                /* Get the profiler config */
                clientId = profConfigs.m_clientId;

                if (copy_from_user(pProfConfig,
                                   (ProfileConfig*)(profConfigs.m_config),
                                   sizeof(ProfileConfig)) == 0)
                {
                    retval = ConfigureTimer(pProfConfig, clientId);
                }
                else
                {
                    DRVPRINT(KERN_WARNING "Failed copying parameter to Add profile Config");
                    retval = -1;
                }
            }

            if (pProfConfig != NULL)
            {
                kfree(pProfConfig);
            }

            return retval;

        case IOCTL_RESUME_PROFILER :
            retval = 0;
            DRVPRINT("In Resume Profiler Ioctl");

            if (copy_from_user(&profProps, (PROFILER_PROPERTIES*)ioctl_param, sizeof(PROFILER_PROPERTIES)) == 0)
            {
                DRVPRINT("Resuming Profile for client %u", profProps.m_clientId);
            }
            else
            {
                DRVPRINT(KERN_WARNING "Power Profiler: Invalid parameter to Resume Profiler");
                return -1;
            }

            retval = ResumeTimer(profProps.m_clientId);
            return retval;

        case IOCTL_START_PROFILER:
            retval = 0;
            DRVPRINT("In Start Profiler Ioctl");

            if (copy_from_user(&profProps, (PROFILER_PROPERTIES*)ioctl_param, sizeof(PROFILER_PROPERTIES)) == 0)
            {
                DRVPRINT("Starting Profile for client %x", profProps.m_clientId);
            }
            else
            {
                DRVPRINT(KERN_WARNING "Power Profiler: Invalid parameter to Start Profiler");
                retval = -1;
            }

            if (!retval)
            {
                retval = StartProfiler(profProps.m_clientId);
            }

            return retval;

        case IOCTL_PAUSE_PROFILER:
            retval = 0;
            DRVPRINT("In Pause profiler ioctl");

            if (copy_from_user(&stop_client_id, (uint32_t*)ioctl_param, sizeof(uint32_t)) == 0)
            {
                DRVPRINT("Pausing Profile for client %llu", stop_client_id);
                tmp_client_id = (unsigned long)stop_client_id;
            }
            else
            {
                DRVPRINT(KERN_WARNING "Power Profiler: Invalid parameter to Pause Profiler");
                return -1;
            }

            retval = PauseTimer(tmp_client_id);
            return retval;

        case IOCTL_STOP_PROFILER:
            DRVPRINT("In stop profiler ioctl");
            retval = 0;

            if (copy_from_user(&stop_client_id, (uint32_t*)ioctl_param, sizeof(uint32_t)) == 0)
            {
                DRVPRINT("Stopping Profile for client %llu", stop_client_id);
                tmp_client_id = (unsigned long)stop_client_id;
            }
            else
            {
                DRVPRINT(KERN_WARNING "Power Profiler: Invalid parameter to Stop Profiler");
                return -1;
            }

            retval = StopProfiler(tmp_client_id);
            return retval;

        case IOCTL_GET_FILE_HEADER_BUFFER:
            DRVPRINT("In get file header ioctl");

            if (copy_from_user(&file_header, (FILE_HEADER*)ioctl_param, sizeof(FILE_HEADER)) == 0)
            {
                DRVPRINT("Get File header for client %u ", file_header.m_clientId);
            }

            retval = GetHeaderBuffer(&file_header);
            DRVPRINT("get header buffer ret %d", retval);

            return retval;

        case IOCTL_GET_DATA_BUFFER:
            DRVPRINT("In get data buffer ioctl");

            if (copy_from_user(&data_buffer, (DATA_BUFFER*)ioctl_param, sizeof(DATA_BUFFER)) == 0)
            {
                DRVPRINT("Get  %u data buffers client %u ", data_buffer.ulavailableBuffCnt, data_buffer.ulClientId);
            }

            retval = GetDataBuffer(&data_buffer);
            DRVPRINT(" Avaliable Buffer Count %u", data_buffer.ulavailableBuffCnt);

            if (copy_to_user((DATA_BUFFER*)ioctl_param, &data_buffer, sizeof(DATA_BUFFER)))
            {
                DRVPRINT(KERN_WARNING "Power Profiler: Error in get data buffer");
                retval = -EACCES;
            }

            return retval;

        case IOCTL_ACCESS_PCI_DEVICE:
            retval = 0;
            DRVPRINT("In Access PCI ioctl");

            pPci = (PACCESS_PCI)kzalloc(sizeof(ACCESS_PCI), GFP_KERNEL);

            if (pPci == NULL)
            {
                retval = -ENOMEM;
            }

            if (!retval && !copy_from_user(pPci, (ACCESS_PCI*)ioctl_param, sizeof(ACCESS_PCI)) == 0)
            {
                DRVPRINT(KERN_WARNING "Power Profiler: Unknown Error in ACCESS_PCI");
                retval = -EACCES;
            }

            if (!retval)
            {
                AccessPciAddress(pPci);
            }

            if (!retval && copy_to_user((ACCESS_PCI*)ioctl_param, pPci, sizeof(ACCESS_PCI)) != 0)
            {
                DRVPRINT(KERN_WARNING "Power Profiler: unknown error");
                retval = -EACCES;
            }

            if (pPci != NULL)
            {
                kfree(pPci);
            }

            return retval;

        case IOCTL_ACCESS_MMIO:
            retval = 0;
            DRVPRINT("In Access MMIO ioctl");

            if (copy_from_user(&mmio, (ACCESS_MMIO*)ioctl_param, sizeof(ACCESS_MMIO)) == 0)
            {
                DRVPRINT(" ACCESS_MMIO  add 0x%llX, data 0x%x ", mmio.m_addr, mmio.m_data);
            }
            else
            {
                DRVPRINT("WARNING: Unknown Error in ACCESS_MMIO ");
                retval = -EACCES;
                return retval;
            }

            if (false == AccessMMIO(&mmio))
            {
                DRVPRINT("ERROR: Error in ACCESS_MMIO ");
                retval = -EACCES;
                return retval;
            }

            if (copy_to_user((ACCESS_MMIO*)ioctl_param, &mmio, sizeof(ACCESS_MMIO)) != 0)
            {
                DRVPRINT(KERN_WARNING "Power Profiler: unknown error");
                retval = -EACCES;
            }

            return retval;

        case IOCTL_SET_AND_GET_FD:
            retval = 0;
            DRVPRINT("In IOCTL_SET_AND_GET_FD ioctl");
            anon_inode_fd = CreateAnonInodeFd();

            if (copy_to_user((int*)ioctl_param, &anon_inode_fd, sizeof(int)))
            {
                DRVPRINT(KERN_WARNING "Copy to User Failed for IOCTL_SET_AND_GET_FD ");
                retval = -EACCES;
            }

            return retval;

        case IOCTL_GET_TARGET_SYSTEM_INFO_BUFFER:
        {
            PTARGET_SYSTEM_INFO pInfo = NULL;
            retval = 0;
            GetTargetSystemInfo(&pInfo);

            if (NULL != pInfo)
            {
                if (copy_to_user((PTARGET_SYSTEM_INFO)ioctl_param, pInfo, sizeof(TARGET_SYSTEM_INFO)))
                {
                    DRVPRINT(KERN_WARNING "Copy to User Failed for IOCTL_GET_TARGET_SYSTEM_INFO_BUFFER");
                    retval = -EACCES;
                }
            }
            else
            {
                printk("Target System Info is NULL\n");
            }

            return retval;
        }

        case IOCTL_COUNT_MODE_PROFILE_CONFIG:
        {
            /* Allocate memory for profile config */
            pConfig = (CountModeProfileConfig*)kzalloc(sizeof(CountModeProfileConfig), GFP_KERNEL);

            if (pConfig == NULL)
            {
                retval = -ENOMEM;
            }

            /* Copy profile config */
            if (!retval && copy_from_user(pConfig,
                                          (CountModeProfileConfig*)ioctl_param,
                                          sizeof(CountModeProfileConfig)))
            {
                retval = -EACCES;
            }

            /* Allocate memory for config groups */
            if (!retval)
            {
                pGroupConfig = (CountModeGroupConfig*)kzalloc(pConfig->m_configArraySize, GFP_KERNEL);

                if (pGroupConfig == NULL)
                {
                    retval = -ENOMEM;
                }
            }

            /* Copy all config groups */
            if (!retval && copy_from_user((void*)pGroupConfig,
                                          (void*)pConfig->m_pConfigArray,
                                          pConfig->m_configArraySize))
            {
                retval = -EACCES;
            }

            if (!retval)
            {
                /* Save config groups */
                pConfig->m_pConfigArray = (uint64_t)pGroupConfig;

                retval = ProcessCountModeProfileConfig(g_pPmcClientContext, pConfig);
            }

            if (!retval)
            {
                // Copy file descriptors to user
                if (copy_to_user(((CountModeProfileConfig*)ioctl_param)->m_fdArray,
                                 pConfig->m_fdArray,
                                 sizeof(pConfig->m_fdArray)))
                {
                    retval = -EACCES;
                }
            }

            if (pGroupConfig != NULL)
            {
                kfree(pGroupConfig);
            }

            if (pConfig != NULL)
            {
                kfree(pConfig);
            }

            return retval;
        }

        case IOCTL_CLEAR_PROFILER:
            retval = 0;
            DRVPRINT("In Clear Profiler Ioctl");

            if (copy_from_user(&profProps, (PROFILER_PROPERTIES*)ioctl_param, sizeof(PROFILER_PROPERTIES)) == 0)
            {
                DRVPRINT("Starting Profile for client %x", profProps.m_clientId);
            }
            else
            {
                DRVPRINT(KERN_WARNING "Power Profiler: Invalid parameter to Start Profiler");
                retval = -1;
            }

            if (!retval)
            {
                retval = ClearProfiler(profProps.m_clientId);
            }

            return retval;

        default:
            DRVPRINT(KERN_WARNING "Power Profiler: Unknown IOCTL ");
            retval = -1;
            return retval;
    }
}

// Module specific cleanup
void PwrProfDrvCleanup(void)
{
    g_isClientActiv = false;
    g_clientId = 0;

    UnconfigureTimer(g_clientId);
    // Release memory pool
    ReleaseMemoryPool(&g_sessionPool);
}

// check if hardware supported.
long CheckPwrProfHwSupport(void)
{
    return CheckHwSupport();
}

// get the driver version.
void GetVersions(unsigned int* major, unsigned int* minor, unsigned int* build)
{
    *major = LINUX_PWR_DRV_MAJOR;
    *minor = LINUX_PWR_DRV_MINOR;
    *build = pcore_build_number;
}
