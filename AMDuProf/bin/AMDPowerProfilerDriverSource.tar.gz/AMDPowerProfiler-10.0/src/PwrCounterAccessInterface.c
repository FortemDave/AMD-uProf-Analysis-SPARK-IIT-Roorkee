//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrCounterAccessInterface.c
///
//==================================================================================
#include <PwrOsPrimitives.h>
#include <PwrDriverUtils.h>
#include <PwrCounterAccessInterface.h>
#include <PwrCommonConfig.h>

static uint32 g_boostedPstateCnt = INVALID_UINT32_VALUE;
static bool g_cefSupported = false;
static bool g_cefROSupported = false;

// PreviousData: Holds previous counter data
uint32 prevCoreEnergy[MAX_CORE_CNT];
uint32 prevPkgEnergy[PWR_MAX_SOCKET_COUNT];
static PwrCefInfo g_prevROCefData[MAX_CORE_CNT];

#define CORE_ENERGY_STAT_ADDR 0xC001029A
#define PKG_ENERGY_STAT_ADDR 0xC001029B
#define AMDUPROF_THM_TCTL_REGISTER      0x00059800

// ReadBoostedPstate:
static uint32 ReadBoostedPstate(void)
{
    uint32 boostedPstate = 0;
    PTARGET_SYSTEM_INFO pTargetInfo = NULL;
    GetTargetSystemInfo(&pTargetInfo);

    if ((NULL != pTargetInfo) && (1 != pTargetInfo->m_isZen))
    {
        // Get the number of boosted P-States from D18F4x15C Core Performance Boost Control
        uint32 data = ReadPCIDev(0, 0x18, 0x4, 0x15C);

        // bits 4:2 are NumBoostStates
        boostedPstate = ((data & 0x1C) >> 2);
    }

    return boostedPstate;
}

// ResetCoreEffectiveFreqCounters:
static void ResetCoreEffectiveFreqCounters(void)
{
    if ((true != g_cefROSupported) && (true == g_cefSupported))
    {
        WriteMSR(MPERF_MSR_ADDRESS, 0);
        WriteMSR(APERF_MSR_ADDRESS, 0);
    }
}

// ReadCoreEffectiveFreqCounters:
static void ReadCoreEffectiveFreqCounters(PwrCefInfo* pCef)
{
    if (true == g_cefSupported)
    {
        pCef->m_mperf = ReadMSR(MPERF_MSR_ADDRESS);
        pCef->m_aperf = ReadMSR(APERF_MSR_ADDRESS);
        pCef->m_p0State = ReadMSR(P0STATE_MSR_ADDRESS + g_boostedPstateCnt);
        pCef->m_tsc = ReadMSR(TSC_MSR_ADDRESS);

        // Reset the counter value adter reading the registers
        ResetCoreEffectiveFreqCounters();
    }
    else
    {
        memset(pCef, 0, sizeof(PwrCefInfo));
    }
}

// InitailizePrevROCefData: Init DS to store prev data for CEF
void PwrInitailizePrevROCefData(int core)
{
    g_prevROCefData[core].m_mperf = ReadMSR(MPERF_RO_MSR_ADDRESS);
    g_prevROCefData[core].m_aperf = ReadMSR(APERF_RO_MSR_ADDRESS);
    g_prevROCefData[core].m_tsc = ReadMSR(TSC_MSR_ADDRESS);
}

// ReadCefROCounters : Read CEF data
void PwrReadCefROCounters(uint32 core, PwrCefInfo* pCef, bool isCefROSupported, uint32 boostedPstateCnt)
{
    uint64 mperf = 0;
    uint64 aperf = 0;
    uint64 tsc = 0;

    if (isCefROSupported)
    {
        mperf = ReadMSR(MPERF_RO_MSR_ADDRESS);
        aperf = ReadMSR(APERF_RO_MSR_ADDRESS);
        tsc = ReadMSR(TSC_MSR_ADDRESS);

        if (g_prevROCefData[core].m_mperf < mperf)
        {
            pCef->m_mperf = mperf - g_prevROCefData[core].m_mperf;
        }
        else
        {
            pCef->m_mperf = mperf + ~g_prevROCefData[core].m_mperf;
        }


        if (g_prevROCefData[core].m_aperf < aperf)
        {
            pCef->m_aperf = aperf - g_prevROCefData[core].m_aperf;
        }
        else
        {
            pCef->m_aperf = aperf + ~g_prevROCefData[core].m_aperf;
        }

        if (g_prevROCefData[core].m_tsc < tsc)
        {
            pCef->m_tsc = tsc - g_prevROCefData[core].m_tsc;
        }
        else
        {
            pCef->m_tsc = tsc + ~g_prevROCefData[core].m_tsc;
        }

        // Store the data
        g_prevROCefData[core].m_mperf = mperf;
        g_prevROCefData[core].m_aperf = aperf;
        g_prevROCefData[core].m_tsc = tsc;

        // Read P-State-0 Frequency
        pCef->m_p0State = ReadMSR(P0STATE_MSR_ADDRESS + boostedPstateCnt);
    }
    else
    {
        memset(pCef, 0, sizeof(PwrCefInfo));
    }
}

// CollectPerCoreCounters:
bool CollectNodeCounters(CoreData* pCoreCfg, uint32* pLength)
{
    bool result = true;
    uint32 idx = 0;
    uint32 offset = 0;
    uint32* value = NULL;
    uint64* value64 = NULL;
    uint8* pData = NULL;

    if ((NULL == pCoreCfg)
        || (NULL == pCoreCfg->m_pCoreBuffer)
        || (NULL == pCoreCfg->m_pCoreBuffer->m_pBuffer))
    {
        DRVPRINT("InvalidpCoreCfg or pCoreCfg->m_pCoreBuffer->m_pBuffer");
        result = false;
    }

    if (true == result)
    {
        pData = pCoreCfg->m_pCoreBuffer->m_pBuffer;
        offset = *pLength;

        for (idx = COUNTERID_PID; idx <= COUNTERID_NODE_MAX_CNT; idx++)
        {
            if (false == ((pCoreCfg->m_counterMask >> idx) & 0x01))
            {
                continue;
            }

            switch (idx)
            {
                case COUNTERID_PID:
                {
                    //Get PID
                    value64 = (uint64*)&pData[offset];
                    *value64 = (uint64)pCoreCfg->m_contextData.m_processId;
                    offset += sizeof(uint64);
                    break;
                }

                case COUNTERID_TID:
                {
                    //Get TID
                    value64 = (uint64*)&pData[offset];
                    *value64 = (uint64)pCoreCfg->m_contextData.m_threadId;
                    offset += sizeof(uint64);
                    break;
                }

                case COUNTERID_CEF:
                {
                    PwrCefInfo* pCef = (PwrCefInfo*)&pData[offset];

                    if (g_cefROSupported)
                    {
                        PwrReadCefROCounters(pCoreCfg->m_coreId,
                                             pCef,
                                             g_cefROSupported,
                                             g_boostedPstateCnt);
                    }
                    else
                    {
                        ReadCoreEffectiveFreqCounters(pCef);
                    }

                    offset += sizeof(PwrCefInfo);
                    break;

                }

                case COUNTERID_CSTATE_RES:
                {
                    uint32 core = GetCurrentCoreId();
                    uint32 address = pCoreCfg->m_internalCounter.m_cstateRes + ((core) * sizeof(uint32));
                    value = (uint32*)&pData[offset];
                    *value = ReadPCI(address);
                    offset += sizeof(uint32);
                    break;
                }

                case COUNTERID_SOFTWARE_PSTATE:
                {
#define SOFTWARE_PSTATE_MSR_ADDR 0xC0010063
                    value = (uint32*)&pData[offset];
                    *value = (uint32)ReadMSR(SOFTWARE_PSTATE_MSR_ADDR);
                    offset += sizeof(uint32);
                    break;
                }


                case COUNTERID_PSTATE:
                {
#define PSTATE_MSR_ADDR 0xC0010071
                    uint64 data = 0;
                    data = ReadMSR(PSTATE_MSR_ADDR);
                    value = (uint32*)&pData[offset];
                    *value = (data >> 16) & 0x03;
                    offset += sizeof(uint32);
                    break;
                }

                case COUNTERID_CORE_POWER:
                {
                    uint32 data = 0;
                    data = (uint32)ReadMSR(CORE_ENERGY_STAT_ADDR);
                    value = (uint32*)&pData[offset];
                    *value = data - prevCoreEnergy[pCoreCfg->m_coreId];
                    prevCoreEnergy[pCoreCfg->m_coreId] = data;
                    offset += sizeof(uint32);
                    break;
                }

                case COUNTERID_PKG_POWER:
                {
                    uint32 data = 0;
                    uint32 socketId = 0;

                    PTARGET_SYSTEM_INFO pTargetInfo = NULL;
                    GetTargetSystemInfo(&pTargetInfo);

                    if ((NULL != pTargetInfo)
                        && (pTargetInfo->m_socketCount > 1))
                    {
                        if (pCoreCfg->m_coreId > 0)
                        {
                            socketId = 1;
                        }
                    }

                    value = (uint32*)&pData[offset];
                    data = (uint32)ReadMSR(PKG_ENERGY_STAT_ADDR);
                    *value = data - prevPkgEnergy[socketId];
                    prevPkgEnergy[socketId] = data;
                    offset += sizeof(uint32);
                    break;
                }

                case COUNTERID_PKG_TEMPERATURE:
                {
                    uint32 addr = AMDUPROF_THM_TCTL_REGISTER;
                    uint32 data = 0;
                    uint32 busId = 0;
                    uint32 coreId = GetCurrentCoreId();
                    PTARGET_SYSTEM_INFO pTargetInfo = NULL;
                    GetTargetSystemInfo(&pTargetInfo);

                    if (NULL != pTargetInfo)
                    {
                        uint32 cnt = 0;

                        for (cnt = 0; cnt < PWR_MAX_SOCKET_COUNT; cnt++)
                        {
                            if (pTargetInfo->m_zen.m_mmio[cnt].m_threadId == coreId)
                            {
                                busId = pTargetInfo->m_zen.m_mmio[cnt].m_bus;
                                break;
                            }
                        }
                    }

                    SmnRead(busId, addr, &data);
                    // DRVPRINT("COUNTERID_PKG_TEMPERATURE coreId %d busId %d\n", coreId, busId);

                    value = (uint32*)&pData[offset];
                    *value = data;
                    offset += sizeof(uint32);

                    break;
                }

                default:
                    break;
            }
        }
    }

    *pLength = offset;

    return result;
}

// CollectBasicCounters:
bool CollectBasicCounters(CoreData* pCoreCfg, uint32* pLength)
{
    bool result = true;
    uint32 idx = 0;
    uint32 offset = 0;
    uint64* value64 = NULL;
    uint16* value16 = NULL;
    uint8* pData = NULL;

    if ((NULL == pCoreCfg)
        || (NULL == pCoreCfg->m_pCoreBuffer)
        || (NULL == pCoreCfg->m_pCoreBuffer->m_pBuffer))
    {
        DRVPRINT("InvalidpCoreCfg or pCoreCfg->m_pCoreBuffer->m_pBuffer");
        result = false;
    }

    if (true == result)
    {
        pData = pCoreCfg->m_pCoreBuffer->m_pBuffer;
        offset = *pLength;

        for (idx = 0; idx <= COUNTERID_BASIC_CNT ; idx++)
        {
            switch (idx)
            {
                case COUNTERID_SAMPLE_ID:
                {
                    value16 = (uint16*) &pData[offset];
                    *value16 = (uint16)pCoreCfg->m_sampleId;
                    offset += sizeof(uint16);
                    break;
                }

                case COUNTERID_RECORD_ID:
                {
                    value64 = (uint64*) &pData[offset];
                    *value64 = pCoreCfg->m_pCoreBuffer->m_recCnt;
                    offset += sizeof(uint64);
                    break;
                }

                case COUNTERID_SAMPLE_TIME:
                {
                    value64 = (uint64*) &pData[offset];
                    *value64 = pCoreCfg->m_contextData.m_timeStamp;
                    offset += sizeof(uint64);
                    break;
                }

                default:
                    break;
            }
        }

        *pLength = offset;
    }

    return result;
}
void PwrReadInitialValues(uint32 threadId)
{
    PTARGET_SYSTEM_INFO pTargetInfo = NULL;
    GetTargetSystemInfo(&pTargetInfo);

    if ((NULL != pTargetInfo) && pTargetInfo->m_isZen)
    {
        bool isSocket1 = false;
        bool initialValue = false;

        if (NULL != pTargetInfo)
        {
            if (threadId == pTargetInfo->m_zen.m_apic[threadId].m_physicalId)
            {
                initialValue = true;
            }

            if (1 == pTargetInfo->m_zen.m_isRaplAvailable)
            {
                if (initialValue)
                {
                    prevCoreEnergy[threadId] = (uint32)ReadMSR(CORE_ENERGY_STAT_ADDR);
                }


                if ((pTargetInfo->m_socketCount > 1) && (threadId == pTargetInfo->m_zen.m_firstCore[1]))
                {
                    isSocket1 = true;
                }

                // Preserve initial value of package energy
                if ((0 == threadId) || isSocket1)
                {
                    uint32 data = (uint32)ReadMSR(PKG_ENERGY_STAT_ADDR);

                    if (isSocket1)
                    {
                        prevPkgEnergy[1] = data;
                    }

                    if (0 == threadId)
                    {
                        prevPkgEnergy[0] = data;
                    }
                }
            }
        }
    }
}

// PwrInitializeBoostedPstate: Read and store boosted pstate
void PwrInitializeBoostedPstate(void)
{
    // Read boosted p-state
    if (INVALID_UINT32_VALUE == g_boostedPstateCnt)
    {
        g_boostedPstateCnt = ReadBoostedPstate();
    }
}

// PwrInitializeEffectiveFrequency: Initialize effective frequency data
void PwrInitializeEffectiveFrequency(uint32 core)
{
    g_cefSupported = IsCefSupported();
    g_cefROSupported = IsROCefAvailable();

    if (g_cefROSupported)
    {
        PwrInitailizePrevROCefData(core);
    }
    else if (g_cefSupported)
    {
        ResetCoreEffectiveFreqCounters();
    }
}
// InitializeGenericCounterAccess:
void InitializeGenericCounterAccess(uint32 core)
{
    DRVPRINT("DPC thread id %d", core);
    PwrInitializeBoostedPstate();
    PwrInitializeEffectiveFrequency(core);
    PwrReadInitialValues(core);
    PwrEnablePerf(true);
}

// CloseGenericCounterAccess:
void CloseGenericCounterAccess(void)
{
    g_boostedPstateCnt = INVALID_UINT32_VALUE;
    ResetCoreEffectiveFreqCounters();
    memset(prevPkgEnergy, 0, sizeof(uint32) * PWR_MAX_SOCKET_COUNT);
    memset(prevCoreEnergy, 0, sizeof(uint32) * MAX_CORE_CNT);
    PwrEnablePerf(false);
}

// GetBasicCounterSize
uint32 GetBasicCounterSize(void)
{
    uint32 bufferLen = 0;
    //COUNTERID_SAMPLE_ID:
    bufferLen += sizeof(uint16);
    //COUNTERID_RECORD_ID:
    bufferLen += sizeof(uint64);
    //COUNTERID_SAMPLE_TIME:
    bufferLen += sizeof(uint64);
    return bufferLen;
}

// GetNodeCounterSize
uint32 GetNodeCounterSize(uint32 counterId)
{
    uint32 bufferLen = 0;

    switch (counterId)
    {
        // 8 byte counters
        case COUNTERID_PID:
        case COUNTERID_TID:
        {
            bufferLen += sizeof(uint64);
            break;
        }

        // 4 byte counters
        case COUNTERID_CSTATE_RES:
        case COUNTERID_PSTATE:
        case COUNTERID_SOFTWARE_PSTATE:
        case COUNTERID_PKG_POWER:
        case COUNTERID_PKG_TEMPERATURE:
        case COUNTERID_CORE_POWER:
        {
            bufferLen += sizeof(uint32);
            break;
        }

        // 24 bytes counter
        case COUNTERID_CEF:
        {
            bufferLen += sizeof(PwrCefInfo);
            break;
        }

        default:
            break;
    }

    return bufferLen;
}

