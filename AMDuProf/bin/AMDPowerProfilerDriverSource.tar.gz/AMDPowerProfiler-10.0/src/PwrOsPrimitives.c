//==================================================================================
// Copyright (c) 2020 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrOsPrimitives.c
///
//==================================================================================
// SYSTEM INCLUDES
#include <asm/io.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include <linux/list.h>
#include <linux/smp.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/types.h>
#include <linux/version.h>
#include <linux/ktime.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 17, 0)
    #include <linux/timekeeping.h>
#endif

// PROJECT INCLUDES
#include <PwrOsPrimitives.h>
#include <PwrDriverTypedefs.h>
#include <PwrDriverUtils.h>
#include <PwrProfAsm.h>
#include <PwrProfCpuid.h>

// LOCAL DEFINES
#define PCI_ADDR_PORT       0xCF8
#define PCI_DATA_PORT       0xCFC
MemoryPool g_sessionPool;

typedef struct CoreContextInfo
{
    void*  m_pContext;
    void*  m_pCallback;
    uint32 m_core;
} CoreContextInfo;

// Memory pull functions is not done common as the way memory is allocated in
// Windows and linux are different
// Create memory pool
bool CreateMemoryPool(MemoryPool* pPool, uint32 size)
{
    bool ret = false;

    if (NULL != pPool)
    {
        pPool->m_pBase = (uint8*)kmalloc(size, GFP_KERNEL);

        if (NULL != pPool->m_pBase)
        {
            pPool->m_offset = 0;
            pPool->m_size = size;
            ret = true;
        }
    }

    return ret;
}

// Get buffer from the memory pool
uint8* GetMemoryPoolBuffer(MemoryPool* pPool, uint32 size)
{
    uint8* pBuffer = NULL;

    if ((NULL == pPool) || ((pPool->m_offset + size) > pPool->m_size))
    {
        pBuffer = NULL;
    }
    else
    {
        pBuffer = pPool->m_pBase + pPool->m_offset;
        pPool->m_offset += size;
    }

    return pBuffer;
}

// Delete the memory pool
bool ReleaseMemoryPool(MemoryPool* pPool)
{
    bool ret = false;

    if (NULL != pPool)
    {
        if (NULL != pPool->m_pBase)
        {
            kfree(pPool->m_pBase);
            pPool->m_pBase = NULL;
            ret = true;
        }
    }

    return ret;
}

void* AllocateMemory(uint32_t size)
{
    // ToDo: Add flags to arguemnt?
    return kmalloc((size_t)size, GFP_KERNEL);
}

void FreeMemory(void* obj)
{
    kfree(obj);
}

// Read CPU id.
void readCPUID(uint32 index, uint32 index2, uint32* peax, uint32* pebx, uint32* pecx, uint32* pedx)
{
    uint32 a = 0;
    uint32 b = 0;
    uint32 c = 0;
    uint32 d = 0;
    asm(
        "cpuid\n\t"
        :"=b"(b),
        "=d"(d),
        "=c"(c),
        "=a"(a)
        :"a"(index), "c"(index2)
    );
    /*asm
      ("cpuid" : "=a" (a), "=b" (b), "=c" (c), "=d" (d)
       : "a" (index), "c" (index2));*/
    DRVPRINT("cpuid a=%u, b=%u, c=%u,d =%u \n", a, b, c, d);

    if ((NULL != peax) || (NULL != pebx) || (NULL != pecx) || (NULL != pedx))
    {
        *peax = a;
        *pebx = b;
        *pecx = c;
        *pedx = d;
    }
    else
    {
        DRVPRINT("NULL POINTER");
    }
}

// Read CPU id.
void ReadCPUID(int32* pInfo, uint32 indentifier)
{
    if (NULL != pInfo)
    {
        readCPUID(indentifier, 0, &pInfo[PWR_EAX_OFFSET], &pInfo[PWR_EBX_OFFSET], &pInfo[PWR_ECX_OFFSET], &pInfo[PWR_EDX_OFFSET]);
    }
}

// Read extended CPU id.
void ReadCPUIDEx(int32* pInfo, uint32 indentifier, uint32 sub)
{
    if (NULL != pInfo)
    {
        readCPUID(indentifier, sub, &pInfo[PWR_EAX_OFFSET], &pInfo[PWR_EBX_OFFSET], &pInfo[PWR_ECX_OFFSET], &pInfo[PWR_EDX_OFFSET]);
    }
}

// Map MMIO space
bool MapMMIOSpace(
    uint64  address,         // IN
    size_t  size,            // IN
    uint64* mappedAddress,   // OUT
    uint64* mappedSize)      // OUT
{
    bool result = true;
    *mappedAddress = (uint64)ioremap(address, size);
    *mappedSize = size;
    return result;
}

// Unmapping MMIO space
bool UnmapMMIOSpace(uint64 mappedAddress, uint64 mappedSize)
{
    bool result = true;
    iounmap((void*)mappedAddress);
    return result;
}
// Read from MSR
uint64 ReadMSR(uint32 index)
{
    uint64 result = 0;
    uint64_t password = 0;
    uint32 value[2];
    uint32* pPwHalfs = (uint32*)(&password);
    rdmsrpw(index, value[0], value[1], pPwHalfs[0], pPwHalfs[1]);
    result = value[1];
    result = (result << 32) | value[0];
    DRVPRINT("Thread %d addr 0x%x , value %llx \n", GetCurrentCoreId(), index, result);
    return result;
}

// Write to MSR
void WriteMSR(uint32 index, uint64 value)
{
    uint64_t password = 0;
    uint32* pHalfs = (uint32*)(&value);
    uint32* pPwHalfs = (uint32*)(&password);
    DRVPRINT("Thread %d addr 0x%x , value %llu \n", GetCurrentCoreId(), index, value);
    wrmsrpw(index, pHalfs[0], pHalfs[1], pPwHalfs[0], pPwHalfs[1]);
}

// Read data from the specified MMIO address
uint32 ReadMMIO(uint32 addr, uint64_t* val, bool map)
{
    uint32 byteCount ;
    void __iomem* virtualAddress;
    uint32* p;
    byteCount = 4;
    DRVPRINT(" READMMIO addr 0x%x \n ", addr);

    if (map)
    {
        if ((virtualAddress = ioremap(addr, byteCount)) == NULL)
        {
            DRVPRINT(" ioremap failed \n");
            return STATUS_INVALID_PARAMETER;
        }
    }
    else
    {
        p = &addr;
        virtualAddress = (void*)p;
    }

    DRVPRINT(" READMMIO virtual address %p \n", virtualAddress);

    if (virtualAddress)
    {
        *(uint32*)val = read_dword(virtualAddress);

        if (map)
        {
            iounmap(virtualAddress);
        }

        return STATUS_SUCCESS;
    }

    printk(" WARNING , Invalid MMOIO Address \n");
    return STATUS_INVALID_PARAMETER;
}

// Write data to the specified MMIO address
uint32 WriteMMIO(uint32 addr, uint32 data, bool map)
{
    uint32 byteCount;
    void* virtualAddress ;
    uint32* p;
    DRVPRINT(" WRITEMMIO addr %x, data %u \n ", addr, data);
    byteCount = 4;

    if (map)
    {
        virtualAddress = ioremap(addr, byteCount);
    }
    else
    {
        p = &addr;
        virtualAddress = (void*)p;
    }

    DRVPRINT(" WRITEMMIO virtual address %p \n ", virtualAddress);

    if (virtualAddress != NULL)
    {
        //write_dword( virtualAddress, *(uint32 *)pData );
        iowrite32(data, virtualAddress);

        if (map)
        {
            iounmap(virtualAddress);
        }

        return STATUS_SUCCESS;
    }

    return STATUS_INVALID_PARAMETER;
}

void AccessPciExt(uint32 addr, uint32* pData, bool isRead)
{
    bool testRes = true;
    unsigned long value = 0;
    unsigned long iosize = 4;
    unsigned long baseAddr = 0;
    void __iomem* virtualAddress = NULL;
    baseAddr = ReadMSR(MCFG_BASE_ADDRESS);
    baseAddr = baseAddr & 0xFFFF0000;
    baseAddr = baseAddr + ((addr & 0xFF) | ((addr & 0xF000000) >> 16) | ((addr & 0x700) << 4) | ((addr & 0xF800) << 4));

    DRVPRINT("Info: mapping I/O space 0x%lx\n", baseAddr);
    virtualAddress = ioremap(baseAddr, iosize);

    if (isRead)
    {
        if (!(void*)(virtualAddress))
        {
            DRVPRINT("Error: failed to map MMIO range\n");
            testRes = false;
        }

        if (testRes == true)
        {
            DRVPRINT("Info: map_ioaddr: 0x%lx\n", (unsigned long) virtualAddress);
            value = read_dword(virtualAddress);
            DRVPRINT("Info: data readb=%lx\n", value);
            *pData = value;
        }
        else
        {
            testRes = false;
            DRVPRINT("Error: request_mem_region failed 0x%lx", value);
        }
    }
    else
    {
        DRVPRINT("Error: Extended PCIe read not implemented");
    }
}

// Read data from the specified PCI configuration address
uint32 ReadPCI(uint32 addr)
{
    uint32 val = 0;
    uint32 regAddr = (addr & 0xFF) | ((addr & 0xF000000) >> 16);
    // DRVPRINT("Info: ReadPCI addr 0x%x regAddr 0x%x\n", addr, regAddr);

    if (regAddr <= 0xFF)
    {
        outl(addr, PCI_ADDR_PORT);
        val = inl(PCI_DATA_PORT);
    }
    else
    {
        AccessPciExt(addr, &val, true);
    }

    return val;
}

// Write data to the specified PCI configuration address
void WritePCI(uint32 addr, uint32 data)
{
    uint32 regAddr = (addr & 0xFF) | ((addr & 0xF000000) >> 16);

    if (regAddr <= 0xFF)
    {
        outl(addr, PCI_ADDR_PORT);
        outl(data, PCI_DATA_PORT);
    }
    else
    {
        DRVPRINT("PCI MMIO write is not used");
        //uint32 writeData = (uint32)data;
        //AccessPciExt(addr, &writeData, true);
    }
}

// Write data to PCI32  address space.
void WritePCI32(uint32 address, uint32 data, uint32 mask)
{
    uint32 old_address;
    uint32 current_data;
    // Save previous address
    old_address = inl(PCI_ADDR_PORT);
    // Set new address
    outl(PCI_ADDR_PORT, address);
    // Read current data
    current_data = inl(PCI_DATA_PORT);
    // Clear bits we're going to change
    current_data &= (mask);
    // Add new data bits
    current_data |= (data);
    // Write data back
    outl(PCI_DATA_PORT, current_data);
    // Restore previous address
    outl(PCI_ADDR_PORT, old_address);
}

uint32 GetOnlineCpus(void)
{
    return  num_online_cpus();
}

/* Note: For use in interrupt context only or when
 * it is certain that preemption is disabled */
int GetCoreId()
{
    return smp_processor_id();
}

/* Note: Maximum number of cpus supported ?? */
int GetCoreCount()
{
    return nr_cpu_ids;
}

void PrepareAffinityMask(cpumask_t* pm_affinity, uint64 mask[])
{
    uint32 idx = 0;
    unsigned long int coreMask = 0;
    uint32 core = 0;

    for (idx = 0; idx < PWR_CORE_MASK_SIZE; ++idx)
    {
        coreMask = mask[idx];

        for_each_set_bit(core, &coreMask, PWR_CORE_MASK_BITS_COUNT)
        {
            cpumask_set_cpu((idx * PWR_CORE_MASK_BITS_COUNT) + core, pm_affinity);
        }
    }
}

static void DeferredCoreCb(void* pContext)
{
    if (NULL != pContext)
    {
        CoreContextInfo* pInfo = (CoreContextInfo*) pContext;
        DRVPRINT("Thread %d actual %d", pInfo->m_core, GetCurrentCoreId());

        if ((NULL != pInfo) && (NULL != pInfo->m_pCallback) && (NULL != pInfo->m_pContext))
        {
            ((void(*)(void*))pInfo->m_pCallback)((void*)pInfo->m_pContext);
        }
    }
}

// DeferedCoreExecution: Execute DPC. This funcion can be used if a particular access
// needs to be done from a specific core context. In case of Linux it may not be a good idea
// if we want to use this function to get all core context. Instead we can set the mask
// and use smp_call_function_many.
bool DeferedCoreExecution(uint32 core, void* pRoutine, void* pContext)
{
    cpumask_t* pMask = NULL;
    uint32 cpu = 0;
    uint64 mask[PWR_CORE_MASK_SIZE];
    CoreContextInfo coreContext;
    coreContext.m_pCallback = pRoutine;
    coreContext.m_pContext = pContext;
    coreContext.m_core = core;
    pMask = kmalloc(sizeof(cpumask_t), GFP_KERNEL);

    memset(mask, 0, sizeof(uint64) * PWR_CORE_MASK_SIZE);
    mask[core / PWR_CORE_MASK_BITS_COUNT] = (1 << (core % PWR_CORE_MASK_BITS_COUNT));

    // Prepare cpu m_affinity mask structure for the configured core mask
    cpumask_clear(pMask);
    PrepareAffinityMask(pMask, mask);

    cpu = get_cpu();
    put_cpu();

    // Check if the requested core is the current core
    if ((core == cpu) && cpumask_test_cpu(cpu, pMask))
    {
        DeferredCoreCb(&coreContext);
    }
    else
    {
        preempt_disable();
        smp_call_function_many(pMask, (void*)DeferredCoreCb, (void*)&coreContext, true);
        preempt_enable();
    }

    return true;
}

int ExecuteOnCore(int coreId, void* pFunc, void* arg)
{
    return smp_call_function_single(coreId, (smp_call_func_t)pFunc, arg, true);
}

void GetPerformanceCounter(uint64* perfCounter, uint64* freq)
{
    *perfCounter = ktime_to_ns(ktime_get());
    *freq = 1;
}

// Get current time from thr kernel
void GetTimeStamp(uint64* ts)
{
#if LINUX_VERSION_CODE <= KERNEL_VERSION(4, 19, 29)
    struct timespec now = current_kernel_time();
#else
    struct timespec64 now;
    ktime_get_coarse_real_ts64(&now);
#endif

    // return value in mill-seconds
    *ts = (now.tv_sec * 1000 + now.tv_nsec / 1000000);
}

// Currently this API is UNUSED and needed only for Power APP Analysis on Windows
// AcquirePCMCountersLock: Check if PMC counters are available
bool AcquirePCMCountersLock()
{
    return false;
}

// Currently this API is UNUSED and needed only for Power APP Analysis on Windows
// ReleasePCMCountersLock: Release if PMC counters are acquired
bool ReleasePCMCountersLock()
{
    return false;
}

/* Get timestamp in nanoseconds */
uint64_t GetTimestamp()
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 17, 0)
    return ktime_to_ns(ktime_get());
#else
    return ktime_get_ns();
#endif
}
