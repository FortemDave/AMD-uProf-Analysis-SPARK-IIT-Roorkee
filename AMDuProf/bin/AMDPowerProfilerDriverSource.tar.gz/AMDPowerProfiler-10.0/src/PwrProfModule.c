//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrProfModule.c
///
//==================================================================================
// SYSTEM INCLUDES
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/kdev_t.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/version.h>

// PROJECT INCLUDES
#include <PwrProfSharedMemOps.h>

// MODULE DEFINES
#define PROC_DIR_SIZE                   3
#define PWR_PROF_DRV_FIRST_MINOR        0
#define PWR_PROF_DRV_MINOR_CNT          1
#define PWR_PROF_DRV_PROCFS_MAX_SIZE    1024
#define PWR_PROF_DRV_DEVICE_NAME        "AMDPowerProfiler"

// PCORE MODULE FUNCTIONS
void GetVersions(unsigned int*, unsigned int*, unsigned int*);
long PwrProfDrvIoctlImpl(struct file*, unsigned int, unsigned long);
long CheckPwrProfHwSupport(void);
void PwrProfDrvCleanup(void);

// STATIC VARIABLE
static dev_t dev;
struct cdev* kernel_cdev;
static struct proc_dir_entry* base;

// GLOBAL VARIABLE
// module state, tell if module is in use
// 0: Not in use, 1: In use
int moduleState = 0;

#define _DGPU_ENABLED_

// Invoke IOCTL implementation for AMDPowerProfiler driver.
long PwrProfDrvDeviceIoctl(struct file* file, unsigned int ioctl_num, unsigned long ioctl_param)
{
    return PwrProfDrvIoctlImpl(file, ioctl_num, ioctl_param);
}

// File operations for AMDPowerProfiler driver.
struct file_operations Fops =
{
    .unlocked_ioctl = PwrProfDrvDeviceIoctl,
};

// File operations to show AMDPowerProfiler-device version.
static int AMDPowerProfiler_proc_show_device(struct seq_file* m, void* v)
{
    seq_printf(m, "%d\n", MAJOR(dev));
    return 0;
}

static int AMDPowerProfiler_proc_show_version(struct seq_file* m, void* v)
{
    unsigned int major_ver, minor_ver, build_num;
    GetVersions(&major_ver, &minor_ver, &build_num);
    seq_printf(m, "%u.%u-%u\n", major_ver, minor_ver, build_num);
    return 0;
}

// File operation to open AMDPowerProfiler-device file.
static int AMDPowerProfiler_proc_open_device(struct inode* inode, struct  file* file)
{
    return single_open(file, AMDPowerProfiler_proc_show_device, NULL);
}

static int AMDPowerProfiler_proc_open_version(struct inode* inode, struct  file* file)
{
    return single_open(file, AMDPowerProfiler_proc_show_version, NULL);
}

static int
AMDPowerProfiler_proc_fops_mod_show(struct seq_file* m, void* v)
{
    seq_printf(m, "%d\n", moduleState);
    return 0;
}

static int
AMDPowerProfiler_proc_fops_mod_open(struct inode* inode, struct file* file)
{
    return single_open(file, AMDPowerProfiler_proc_fops_mod_show, NULL);
}

// File operation's for AMDPowerProfiler-device
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 5, 19)
static const struct proc_ops AMDPowerProfiler_proc_fops_device =
{
    .proc_open = AMDPowerProfiler_proc_open_device,
    .proc_read = seq_read,
    .proc_lseek = seq_lseek,
    .proc_release = single_release,
};

static const struct proc_ops AMDPowerProfiler_proc_fops_version =
{
    .proc_open = AMDPowerProfiler_proc_open_version,
    .proc_read = seq_read,
    .proc_lseek = seq_lseek,
    .proc_release = single_release,
};

static const struct
    proc_ops AMDPowerProfiler_proc_fops_mod_state =
{
    .proc_open  = AMDPowerProfiler_proc_fops_mod_open,
    .proc_read  = seq_read,
    .proc_lseek = seq_lseek,
    .proc_release = single_release,
};

#else
static const struct file_operations AMDPowerProfiler_proc_fops_device =
{
    .open = AMDPowerProfiler_proc_open_device,
    .read = seq_read,
    .llseek = seq_lseek,
    .release = single_release,
};

static const struct file_operations AMDPowerProfiler_proc_fops_version =
{
    .open = AMDPowerProfiler_proc_open_version,
    .read = seq_read,
    .llseek = seq_lseek,
    .release = single_release,
};

static const struct
    file_operations AMDPowerProfiler_proc_fops_mod_state =
{
    .owner      = THIS_MODULE,
    .open       = AMDPowerProfiler_proc_fops_mod_open,
    .read       = seq_read,
    .llseek     = seq_lseek,
    .release    = single_release,
};
#endif




static struct
{
    const char* name;
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 5, 19)
    const struct proc_ops* proc_fops;
#else
    const struct file_operations* proc_fops;
#endif
} Entries[] =
{
    {"device", &AMDPowerProfiler_proc_fops_device},
    {"version", &AMDPowerProfiler_proc_fops_version},
    {"state", &AMDPowerProfiler_proc_fops_mod_state},
};


// Initialize the module - Register the character device
static int __init PwrProfInitModule(void)
{
    int ret;
    int i;
    unsigned int major_ver, minor_ver, build_num;
    struct proc_dir_entry* entry;
    unsigned int entry_created = 0;

    // Check for KERNEL VERSION SUPPORT.
    // We dont support versions earlier to 2.6.32
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32)
    printk("AMDPowerProfiler: Error, Unsupported kernel version. AMDPowerProfiler only supports version >= 2.6.32 \n");
    return -EPERM;
#endif

    // Check for x86_64 support
#ifndef CONFIG_X86_64
    printk("AMDPowerProfiler: Error, Unsupported kernel version. AMDPowerProfiler only supports 64 bit kernels \n");
    return -EPERM;
#endif
#ifndef _DGPU_ENABLED_

    // TODO: Add a function here to get supported uncore counters?
    ret = CheckPwrProfHwSupport();

    if ((ret < 0))
    {
        return ret;
    }

#endif
    ret = alloc_chrdev_region(&dev, PWR_PROF_DRV_FIRST_MINOR, PWR_PROF_DRV_MINOR_CNT, PWR_PROF_DRV_DEVICE_NAME);

    if (ret < 0)
    {
        printk(KERN_WARNING "AMDPowerProfiler: Char device allocation failed\n");
        return ret;
    }

    kernel_cdev = cdev_alloc();

    if (!kernel_cdev)
    {
        printk(KERN_WARNING "AMDPowerProfiler: Unable to allocate cdev\n");
        unregister_chrdev_region(dev, PWR_PROF_DRV_MINOR_CNT);
        return -EIO;
    }

    kernel_cdev->ops = &Fops;
    kernel_cdev->owner = THIS_MODULE;

    ret = cdev_add(kernel_cdev, dev, 1);

    if (ret < 0)
    {
        printk(KERN_WARNING "AMDPowerProfiler: Unable to add cdev");
        cdev_del(kernel_cdev);
        unregister_chrdev_region(dev, PWR_PROF_DRV_MINOR_CNT);
        return ret;
    }

    if (!(base = proc_mkdir(PWR_PROF_DRV_DEVICE_NAME, NULL)))
    {
        printk(KERN_WARNING "AMDPowerProfiler: Unable to create AMD Power Profiler  dir\n");
        return -EIO;
    }

    // TODO: Do not create these proc entries by default, only when a client
    // intends to configure power profiling
    for (entry_created = 0; entry_created < PROC_DIR_SIZE ; ++entry_created)
    {
        entry = proc_create(Entries[entry_created].name, 0, base,
                            Entries[entry_created].proc_fops);

        if (NULL == entry)
        {
            ret = -ENOMEM;
            break;
        }
    }

    // TODO: Will need to create similar proc entries for count
    // mode profiling

    if (ret < 0)
    {
        printk(KERN_WARNING " AMDPowerProfiler: Internal error");

        if (base)
        {
            for (i = 0; i < entry_created; ++i)
            {
                remove_proc_entry(Entries[i].name, base);
            }

            // delete directory
            remove_proc_entry(PWR_PROF_DRV_DEVICE_NAME, NULL);
        }

        cdev_del(kernel_cdev);
        unregister_chrdev_region(dev, PWR_PROF_DRV_MINOR_CNT);
        return ret;
    }

    GetVersions(&major_ver, &minor_ver, &build_num);

    printk(KERN_INFO "AMDPowerProfiler: Registration was successful.\n");
    printk(KERN_INFO "AMDPowerProfiler: Version is %u.%u-%u\n", major_ver, minor_ver, build_num);
    printk(KERN_INFO "AMDPowerProfiler: Device name: %s, Major device number: %d.\n", PWR_PROF_DRV_DEVICE_NAME, MAJOR(dev));

    return 0;
}

// Cleanup - unregister the appropriate file from /proc
static void __exit PwrProfDrvCleanupModule(void)
{
    int i;
    // Module Specific Cleanup
    PwrProfDrvCleanup();

    if (base)
    {
        for (i = 0; i < PROC_DIR_SIZE ; ++i)
        {
            remove_proc_entry(Entries[i].name, base);
        }

        remove_proc_entry(PWR_PROF_DRV_DEVICE_NAME, NULL);
    }

    cdev_del(kernel_cdev);
    unregister_chrdev_region(dev, PWR_PROF_DRV_MINOR_CNT);
    printk(KERN_INFO "AMDPowerProfiler: Unregistreing AMDPowerProfiler ");
}

module_init(PwrProfInitModule);
module_exit(PwrProfDrvCleanupModule);
MODULE_LICENSE("Dual MIT/GPL");
