//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcTimerConfig.c
///
//==================================================================================

#include <PmcOsTypes.h>
#include <PmcTimerConfig.h>
#include <PwrOsPrimitives.h>
#include <PmcInterface.h>
#include <PmcProcessConfig.h>

#include <linux/smp.h>
#include <linux/slab.h>

extern ClientContext* g_pPmcClientContext;

enum hrtimer_restart PmcTimerCallback(struct hrtimer* pHrTimer)
{
    enum hrtimer_restart ret = HRTIMER_NORESTART;
    int err = 0;
    int coreId = 0;
    CoreContext* pCoreCtx = NULL;
    PmcTimerConfig* pTimerConfig = NULL;

    DRVPRINT("pHrTimer(%p) g_pPmcClientContext(%p)", pHrTimer, g_pPmcClientContext);

    /* Note: For multiple clients we can iterate through list of clients here */
    if (g_pPmcClientContext == NULL)
    {
        err = EINVAL;
    }

    if (!err)
    {
        /* Note: We can also use multiple container_ofs
         * to get clientContext reference and avoid using a
         * global reference here. */
        coreId = GetCoreId();
        pCoreCtx = &g_pPmcClientContext->m_pCoreContext[coreId];

        if (pCoreCtx == NULL)
        {
            err = EINVAL;
        }

        DRVPRINT("coreId(%d)", coreId);
    }

    if (!err)
    {
        err = PmcCallBack(g_pPmcClientContext, pCoreCtx);
    }

    if (!err)
    {
        pTimerConfig = pCoreCtx->m_pTimerConfig;

        hrtimer_forward_now(pHrTimer, pTimerConfig->m_time);
        ret = HRTIMER_RESTART;
    }

    DRVPRINT("ret(%d) err(%d)", ret, err);

    return ret;
}

static void PmcInitTimer(void* pInfo)
{
    PmcTimerConfig* pTimerConfig = (PmcTimerConfig*)pInfo;

    DRVPRINT("pTimerConfig(%p)", pTimerConfig);

    hrtimer_init(&pTimerConfig->m_hrTimer, CLOCK_MONOTONIC, HRTIMER_MODE_REL_PINNED);
}

int PmcSetupTimer(ClientContext* pClientCtx)
{
    int retVal = 0;
    int i = 0;
    int j = 0;
    int coreId = 0;
    uint64_t corePmcCoreMask = 0;
    uint64_t l3PmcCoreMask = 0;
    uint64_t dfPmcCoreMask = 0;
    PmcTimerConfig* pTimerConfig = NULL;
    uint64_t interval = pClientCtx->m_timerInterval;

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    if (pClientCtx == NULL)
    {
        retVal = EINVAL;
    }

    /* ToDo: Add a check here to limit the mux interval */
    /* ToDo: Instead of checking core masks for all types
     * check if there is a valid config? */
    for (i = 0; i < PMC_CORE_MASK_ARRAY_SIZE && !retVal; i++)
    {
        uint32_t umcPmcUmsMask = 0;
        corePmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_CORE][i];
        l3PmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_L3][i];
        dfPmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_DF][i];

        for (j = 0; j < PMC_CORE_MASK_BIT_WIDTH && !retVal; j++, coreId++)
        {
            // m_pUmcMaskArray is per socket
            if (NULL != pClientCtx->m_pUmcMaskArray)
            {
                uint32_t socketIdx = 0;

                for (socketIdx = 0; socketIdx < pClientCtx->m_umcMaskArraySize; socketIdx++)
                {
                    if (coreId == pClientCtx->m_firstCore[socketIdx])
                    {
                        umcPmcUmsMask = pClientCtx->m_pUmcMaskArray[socketIdx];
                        DRVPRINT(" UMC config core (%d) umcPmcUmsMask(0x%x)", coreId, umcPmcUmsMask);
                        break;
                    }
                }
            }

            if ((corePmcCoreMask & 1ULL << j)
                || (l3PmcCoreMask & 1ULL << j)
                || (dfPmcCoreMask & 1ULL << j)
                || (umcPmcUmsMask & 1ULL << j))
            {
                pTimerConfig = (PmcTimerConfig*)kzalloc(sizeof(PmcTimerConfig), GFP_KERNEL);

                if (pTimerConfig == NULL)
                {
                    retVal = -ENOMEM;
                }

                pClientCtx->m_pCoreContext[coreId].m_pTimerConfig = pTimerConfig;

                retVal = smp_call_function_single(coreId, PmcInitTimer,
                                                  pTimerConfig, true);

                if (!retVal)
                {
                    /* Interval in ms */
                    pTimerConfig->m_time = ktime_set(interval / 1000, interval * 1000000);
                    pTimerConfig->m_hrTimer.function = PmcTimerCallback;

                    DRVPRINT("retVal(%d) m_time(%lld)", retVal, pTimerConfig->m_time);
                }

                DRVPRINT("coreId(%d) pTimerConfig(%p)", coreId, pTimerConfig);
            }
        }
    }

    if (retVal)
    {
        PmcDestroyTimer(pClientCtx);
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

void PmcDestroyTimer(ClientContext* pClientCtx)
{
    int i = 0;
    CoreContext* pCoreCtx = NULL;
    int numOfCores = GetCoreCount();

    for (i = 0; i < numOfCores; i++)
    {
        pCoreCtx = &pClientCtx->m_pCoreContext[i];

        if (pCoreCtx != NULL)
        {
            if (pCoreCtx->m_pTimerConfig != NULL)
            {
                kfree(pCoreCtx->m_pTimerConfig);
            }
        }
    }
}

void PmcStartTimerOnCore(CoreContext* pCoreCtx)
{
    if (pCoreCtx != NULL)
    {
        PmcTimerConfig* pTimerConfig = pCoreCtx->m_pTimerConfig;

        DRVPRINT("pTimerConfig(%p)", pTimerConfig);

        if (pTimerConfig != NULL)
        {
            hrtimer_start(&pTimerConfig->m_hrTimer,
                          pTimerConfig->m_time,
                          HRTIMER_MODE_REL_PINNED);
        }
    }
}

static void _PmcStartTimer(void* pInfo)
{
    if (pInfo != NULL)
    {
        CoreContext* pCoreCtx = (CoreContext*)pInfo;

        PmcTimerConfig* pTimerConfig = pCoreCtx->m_pTimerConfig;

        if (pTimerConfig != NULL)
        {
            hrtimer_start(&pTimerConfig->m_hrTimer,
                          pTimerConfig->m_time,
                          HRTIMER_MODE_REL_PINNED);
        }
    }
}


/* ToDo: Remove this if not being used anywhere */
int PmcStartTimer(ClientContext* pClientCtx)
{
    int retVal = 0;
    int i = 0;
    int j = 0;
    uint64_t corePmcCoreMask = 0;
    uint64_t l3PmcCoreMask = 0;
    uint64_t dfPmcCoreMask = 0;
    uint32_t coreId = 0;
    CoreContext* pCoreCtx = NULL;

    for (i = 0; i < PMC_CORE_MASK_ARRAY_SIZE; i++)
    {
        corePmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_CORE][i];
        l3PmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_L3][i];
        dfPmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_DF][i];

        for (j = 0; j < PMC_CORE_MASK_BIT_WIDTH; j++, coreId++)
        {
            pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

            if ((corePmcCoreMask & 1 << j) ||
                (l3PmcCoreMask & 1 << j)   ||
                (dfPmcCoreMask & 1 << j))
            {
                retVal = smp_call_function_single(coreId,
                                                  (smp_call_func_t)_PmcStartTimer,
                                                  (void*)pCoreCtx, true);
            }
        }
    }

    if (retVal != HRTIMER_RESTART)
    {
        // ToDo: Return appropriate error code and message
        // Failed to start timer
    }

    return retVal;
}

void PmcStopTimerOnCore(CoreContext* pCoreCtx)
{
    int retVal = 0;

    if (pCoreCtx != NULL)
    {
        PmcTimerConfig* pTimerConfig = pCoreCtx->m_pTimerConfig;

        if (pTimerConfig != NULL)
        {
            retVal = hrtimer_cancel(&pTimerConfig->m_hrTimer);

            if (!retVal)
            {
                /* ToDo: Timer was already cancelled */
            }
        }
    }
}

static void _PmcStopTimer(void* pInfo)
{
    int retVal = 0;

    if (pInfo != NULL)
    {
        CoreContext* pCoreCtx = (CoreContext*)pInfo;

        PmcTimerConfig* pTimerConfig = pCoreCtx->m_pTimerConfig;

        if (pTimerConfig != NULL)
        {
            retVal = hrtimer_cancel(&pTimerConfig->m_hrTimer);

            if (!retVal)
            {
                /* ToDo: Timer was already cancelled */
            }
        }
    }
}

/* ToDo: Remove if unused */
int PmcStopTimer(ClientContext* pClientCtx)
{
    int retVal = 0;
    int i = 0;
    int j = 0;
    uint64_t corePmcCoreMask = 0;
    uint64_t l3PmcCoreMask = 0;
    uint64_t dfPmcCoreMask = 0;
    uint32_t coreId = 0;
    CoreContext* pCoreCtx = NULL;

    if (pClientCtx == NULL)
    {
        retVal = EINVAL;
    }

    for (i = 0; i < PMC_CORE_MASK_ARRAY_SIZE && !retVal; i++)
    {
        corePmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_CORE][i];
        l3PmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_L3][i];
        dfPmcCoreMask = pClientCtx->m_pPmcCoreMaskArray[PMC_PMU_DF][i];

        for (j = 0; j < PMC_CORE_MASK_BIT_WIDTH; j++, coreId++)
        {
            pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

            if ((corePmcCoreMask & 1 << j) ||
                (l3PmcCoreMask & 1 << j)   ||
                (dfPmcCoreMask & 1 << j))
            {
                retVal = smp_call_function_single(coreId,
                                                  (smp_call_func_t)_PmcStopTimer,
                                                  (void*)pCoreCtx, true);
            }
        }
    }

    return retVal;
}
