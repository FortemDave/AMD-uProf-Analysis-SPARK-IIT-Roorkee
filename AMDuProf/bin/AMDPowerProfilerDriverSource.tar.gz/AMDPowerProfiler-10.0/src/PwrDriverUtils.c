//==================================================================================
// Copyright (c) 2020 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrDriverUtils.cpp
///
//==================================================================================
// LOCAL INCLUDES

#include <PwrOsPrimitives.h>
#include <PwrCounterAccessInterface.h>
#include <PwrDriverUtils.h>
#if defined (_WIN32)
    #include <PwrDriverInternal.h>
#endif

#if defined (__linux__)
    #include <linux/slab.h>
    #include <PwrProfInternal.h>
    #include <PwrProfCpuid.h>
    #include <PwrDriverIoctls.h>
    #include <PmcInterface.h>
#endif

#define PCI_ADDR_PORT       0xCF8
#define PCI_DATA_PORT       0xCFC

#define HWCF    0xC0010015

// Bit 30: IRPerfEn: enable instructions retired counter
#define HwCfgIRPerfEn   1ULL << 30

static uint32 g_computeUnitCnt = INVALID_UINT32_VALUE;

// GetTargetCoreCount: Get the total number of core in the cpu
uint32 GetTargetCoreCount(void)
{
    return GetOnlineCpus();
}

//GetComputeUnitCntPerNode
uint32 GetComputeUnitCntPerNode()
{
    if (0xFFFFFFFF == g_computeUnitCnt)
    {
        // D18F5x80 gives the CU count
        uint32 bus = 0U;
        uint32 device = 0x18U;
        uint32 function = 0x5U;
        uint32 reg = 0x80U;
        uint32 cuStatus = 0U;
        uint32 corePerCu = 0;

        cuStatus = ReadPCIDev(bus, device, function, reg);

        if (PLATFORM_MULLINS == PwrGetTargetPlatformId())
        {
            g_computeUnitCnt = 1;
        }
        else
        {
            DecodeCURegisterStatus(cuStatus, &g_computeUnitCnt, &corePerCu);
        }
    }

    return g_computeUnitCnt;
}

// GetCpuModelFamily: Get family and model number of the cpu
void GetCpuModelFamily(uint32* family, uint32* model)
{
    CpuInfo info;
    int aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };
    ReadCPUID(aCPUInfo, CPUID_FnFeatureId);

    info.eax = aCPUInfo[0];
    *family = info.info.family;
    *model = info.info.model;

    if (FAMILY_EXTENDED == *family)
    {
        *family += info.info.extFamily;
    }

    *model += (info.info.extModel << 4);
}

// IsCefSupported: Check if core effective frequency feature is available
bool IsCefSupported()
{
    bool result = false;
    int aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };

    ReadCPUID(aCPUInfo, CPUID_FnThermalAndPowerManagement);

    // Effective Frequency is supported
    result = (aCPUInfo[PWR_ECX_OFFSET] & CPUID_FnThermalAndPowerManagement_ECX_EffFreq) != 0;
    return result;
}

// IsROCefAvailable
bool IsROCefAvailable()
{
    bool result = false;
    int aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };

    ReadCPUID(aCPUInfo, CPUID_FnAdvancePowerManagementInformation);

    // Effective Frequency is supported
    result = (aCPUInfo[PWR_EDX_OFFSET] & CPUID_FnAdvancePowerManagementInformation_EDX_EffFreqRO) != 0;
    return result;
}

// IsPMCCounterAvailable
bool IsPMCCounterAvailable(void)
{
    bool result = false;
    int aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };

    ReadCPUID(aCPUInfo, CPUID_FnBrandIdIdentifier);

    // Effective Frequency is supported
    result = (aCPUInfo[PWR_ECX_OFFSET] & CPUID_FnAmdExtendedFeatures_ECX_PerfCtrExtCore) != 0;
    return result;
}

// Get Address for extended configuration address space.
static uint32 GetExtendedConfigurationSpaceAddress(unsigned int bus, unsigned int device, unsigned  func, unsigned int reg)
{
    PciExtendedConfigurationSpaceAddress pciAddr;
    pciAddr.m_address = 0U;
    pciAddr.element.m_configEn = 1U;
    pciAddr.element.m_extReg = (reg >> 8) & 0xFU;
    pciAddr.element.m_reg = reg & 0x00FCU;
    pciAddr.element.m_bus = bus;
    pciAddr.element.m_device = device;
    pciAddr.element.m_function = func;
    return pciAddr.m_address;
}

// Read data from specified PCI32 configuration address.
uint32 ReadPCIDev(uint32 bus, uint32 device, uint32 func, uint32 reg)
{
    uint32 data = 0;
    uint32 address = GetExtendedConfigurationSpaceAddress(bus, device, func, reg);
    data = ReadPCI(address);
    DRVPRINT("bus %u , device %u , func %u , reg %u , address %u, data %u\n", bus, device, func, reg, address, data);
    return data;
}

void WritePCIDev(uint32 bus, uint32 device, uint32 func, uint32 reg, uint32 data)
{
    uint32 address = GetExtendedConfigurationSpaceAddress(bus, device, func, reg);
    WritePCI(address, data);
    DRVPRINT("bus %u , device %u , func %u , reg %u , address %u, data %u\n", bus, device, func, reg, address, data);
}

// Access PCIe Address space for read/write
void AccessPci(PACCESS_PCI pData)
{
    if (NULL != pData)
    {
        if (1 == pData->m_isReadAccess)
        {
            pData->m_data = (uint32)ReadPCI(pData->m_address);
        }
        else if (0 == pData->m_isReadAccess)
        {
            WritePCI(pData->m_address, pData->m_data);
        }
    }
}

// Access MSR Address space fore read/write
void AccessMSR(PACCESS_MSR pData)
{
    if (NULL != pData)
    {
        if (1 == pData->m_isReadAccess)
        {
            pData->m_data = ReadMSR(pData->m_regId);
        }
        else if (0 == pData->m_isReadAccess)
        {
            WriteMSR(pData->m_regId, pData->m_data);
        }
    }
}

// AccessMMIO: Read/Write to the MMIO address space.
// This method is used to called from user space
bool AccessMMIO(ACCESS_MMIO* pMMIO)
{
    bool ret = false;
    uint64 res = 0;
    uint64 map = 0;

    DRVPRINT("R/W: %d, addr:0x%llx data:0x%x\n", pMMIO->m_isReadAccess, pMMIO->m_addr, pMMIO->m_data);

    // Memory map for the address.
    ret = MapMMIOSpace(pMMIO->m_addr,
                       sizeof(uint32),
                       &map,
                       &res);

    if (true == ret)
    {
        if (1 == pMMIO->m_isReadAccess)
        {
            pMMIO->m_data = READ_DWORD(map);
        }
        else if (0 == pMMIO->m_isReadAccess)
        {
             WRITE_DWORD(map, pMMIO->m_data);
        }

        UnmapMMIOSpace(map, sizeof(uint32));
    }

    return ret;
}

void SmnRead(uint32 bus, uint32 address, uint32* pData)
{
    WritePCIDev(bus, 0, 0, 0xE0, address);
    *pData = ReadPCIDev(bus, 0, 0, 0xE4);
}

void SmnWrite(uint32 bus, uint32 address, uint32 data)
{
    WritePCIDev(bus, 0, 0, 0xE0, address);
    WritePCIDev(bus, 0, 0, 0xE4, data);
}

// Return the number of bits set.
void GetBitsCount(uint64 mask, uint32* pCount)
{
    uint32 count = 0;
    uint32 loop = 8 * sizeof(uint64);

    while (loop--)
    {
        if (mask & (1ULL << loop))
        {
            count++;
        }
    }

    *pCount = count;
}

// Get GPU base address
uint64 GmmxGetBaseAddress(uint32 gpuAddr)
{
    uint32 baseGPUAddressLow = ReadPCI(gpuAddr);;

    // set bits 0:3 to 0
    baseGPUAddressLow = baseGPUAddressLow & 0xFFFFFFF0;
    return baseGPUAddressLow;
}

// PwrGetLogicalProcessCount:  Get the number of logical cores
uint32 PwrGetLogicalProcessCount(void)
{
    uint32 numOfThreads = 0;
    int aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };
    ReadCPUID(aCPUInfo, CPUID_FnFeatureId);

    numOfThreads = (aCPUInfo[PWR_EBX_OFFSET] & CPUID_FeatureId_EBX_LogicalProcessorCount) >> 16;
    return numOfThreads;
}

// PwrIsSmtEnabled: Check if thread per core is more than 1
bool PwrIsSmtEnabled()
{
    uint32 numOfThreads = 0;

    bool result = false;
    int aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };
    ReadCPUID(aCPUInfo, CPUID_FnIdentifiers);

    numOfThreads = (aCPUInfo[PWR_EBX_OFFSET] & CPUID_NodeIdentifiers_EBX_ThreadsPerCore) + 1;

    result = (numOfThreads > 1) ? true : false;
    return result;
}

// PwrReadCpuId: Get the CPUID instruction
uint32 PwrReadCpuId(RegisterOffset regId, uint32 functionId)
{
    int aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };

    ReadCPUID(aCPUInfo, functionId);
    return aCPUInfo[regId];
}

static void PwrCoreDpc(void* pContext)
{
    PwrApicInfo* pApic = (PwrApicInfo*) pContext;
    uint32 osCoreId = GetCurrentCoreId();

    if (NULL != pApic)
    {
        DRVPRINT("Executed DPC %d", osCoreId);
        pApic[osCoreId].m_extdApic = PwrReadCpuId(PWR_EAX_OFFSET, CPUID_FnIdentifiers);
        pApic[osCoreId].m_nodeId = 0xFF & PwrReadCpuId(PWR_ECX_OFFSET, CPUID_FnIdentifiers);
        DRVPRINT("thread %d extended apic 0x%x node %d", osCoreId, pApic[osCoreId].m_extdApic, pApic[osCoreId].m_nodeId);
    }
}

static void PwrExtPerfMonAndDbgInfoDpc(void* pContext)
{
    PwrExtPerfMonAndDbgInfo* pInfo = (PwrExtPerfMonAndDbgInfo*)pContext;
    int aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };
    uint32_t largestExtdFuncNum = 0;

    if (NULL != pInfo)
    {
        largestExtdFuncNum = PwrReadCpuId(PWR_EAX_OFFSET, CPUID_FnLargFuncExtNum);

        if (largestExtdFuncNum >= CPUID_FnExtdPerfmonAndDebug)
        {
            ReadCPUID(aCPUInfo, CPUID_FnExtdPerfmonAndDebug);
            pInfo->m_isPerfMonV2 = aCPUInfo[PWR_EAX_OFFSET] & 0x1;
            pInfo->m_isLbrExtV2 = (aCPUInfo[PWR_EAX_OFFSET] >> 1) & 0x1;
            pInfo->m_numOfUmcPmc = (aCPUInfo[PWR_EBX_OFFSET] >> 16) & 0x3F;
            pInfo->m_numOfDfPmc = (aCPUInfo[PWR_EBX_OFFSET] >> 10) & 0x3F;
            pInfo->m_lbrV2StackSize = (aCPUInfo[PWR_EBX_OFFSET] >> 4) & 0x3F;
            pInfo->m_numOfCorePmc = (aCPUInfo[PWR_EBX_OFFSET] & 0xF);
            pInfo->m_activeUmcMask = (aCPUInfo[PWR_ECX_OFFSET] & 0xFFFFFFFF);
        }

        // Note: On some family/models CPUID_FnExtdPerfmonAndDebug
        // will return 0, in which case use default values
        pInfo->m_numOfCorePmc = (pInfo->m_numOfCorePmc == 0) ? CORE_PMC_COUNT : pInfo->m_numOfCorePmc;
        pInfo->m_numOfDfPmc = (pInfo->m_numOfDfPmc == 0) ? DF_PMC_COUNT : pInfo->m_numOfDfPmc;
        pInfo->m_numOfL3Pmc = CHL3_PMC_COUNT;

        DRVPRINT("isPerfMonV2(%d) isLbrExtV2(%d) numOfUmcPmc(%u) numOfDfPmc(%u) lbrV2StackSize(%u) numOfCorePmc(%u) activeUmcMask(%u)",
                 pInfo->m_isPerfMonV2, pInfo->m_isLbrExtV2,
                 pInfo->m_numOfUmcPmc, pInfo->m_numOfDfPmc,
                 pInfo->m_lbrV2StackSize, pInfo->m_numOfCorePmc,
                 pInfo->m_activeUmcMask);
    }
}

uint32 GetFirstBitSet(uint64 num)
{
    uint32 cnt = 0;

    while ((num & 1) == 0)
    {
        cnt++;
        num >>= 1;
    }

    return cnt;
}


uint32 GetBitCount(uint64 val)
{
    uint32 cnt;

    for (cnt = 0; val; cnt++)
    {
        val &= val - 1;
    }

    return cnt;
}

uint32 GetBitCountExt(uint64* pVal)
{
    uint32 idx = 0;
    uint32 bitCount = 0;

    for (idx = 0; idx < PWR_CORE_MASK_SIZE; idx++)
    {
        if (0 == pVal[idx])
        {
            continue;
        }

        bitCount += GetBitCount(pVal[idx]);
    }

    return bitCount;
}

// AccessPciAddress: Read/Write PCI address space
bool AccessPciAddress(PACCESS_PCI pData)
{
    bool ret = false;

    if (NULL != pData)
    {
        AccessPci(pData);
        ret = true;
    }

    return ret;
}

static void MsrDpc(void* pContext)
{
    PACCESS_MSR pData = (PACCESS_MSR) pContext;

    if (NULL != pData)
    {
        AccessMSR(pData);
    }
}

// AccessMSRAddress: Read/Write MSR in a core context
bool AccessMSRAddress(PACCESS_MSR pData)
{
    bool ret = false;

    if (NULL != pData)
    {
        if ((PWR_CURRENT_CORE == pData->m_core) || (GetCurrentCoreId() == pData->m_core))
        {
            AccessMSR(pData);
        }
        else
        {
            DeferedCoreExecution(pData->m_core, MsrDpc, pData);
        }

        ret = true;
    }

    return ret;
}

static void PrepareApicList(PTARGET_SYSTEM_INFO pTargetInfo)
{
    uint32 count = 0;

    if (NULL != pTargetInfo)
    {
        for (count = 0; count < pTargetInfo->m_zen.m_totalThreads; count++)
        {
            if (pTargetInfo->m_zen.m_isSmtEnabled)
            {
                uint32 idx = 0;
                uint32 apicId = pTargetInfo->m_zen.m_apic[count].m_extdApic;
                apicId = apicId & (~0UL << 1);

                for (idx = 0; idx < pTargetInfo->m_zen.m_totalThreads; idx++)
                {
                    if (pTargetInfo->m_zen.m_apic[idx].m_extdApic == apicId)
                    {
                        pTargetInfo->m_zen.m_apic[count].m_physicalId = idx;
                        DRVPRINT("thread %d phy %d", count, idx);
                        break;
                    }
                }
            }
            else
            {
                pTargetInfo->m_zen.m_apic[count].m_physicalId = count;
            }
        }
    }
}

#if defined(_WIN32)
void PwrSetExtendedApicId(TARGET_SYSTEM_INFO* pTargetInfo)
{
    DRVPRINT(" PwrSetExtendedApicId");

    if ((nullptr != pTargetInfo)
        && (1 == pTargetInfo->m_isZen))
    {
        uint32 count = 0;

        for (count = 0; count < pTargetInfo->m_zen.m_totalThreads; count++)
        {
            DeferedCoreExecution(static_cast<uint32>(count), PwrCoreDpc, pTargetInfo->m_zen.m_apic);
        }

        PrepareApicList(pTargetInfo);
    }
}

#endif

// Linux functions
#if defined (__linux__)
static bool IsCpuSigRead = false;

// struct for cpu signature
static CpuSignature cpu_sig =
{
    .m_value = 0,
    .m_isHypervisor = false,
};

// LOCAL FUNCTIONS
//
// Read CPU Signature.
void ReadCpuSignature(CpuSignature* cpu)
{
    int32 data[PWR_NUM_CPUID_OFFSETS] = {0,};
    char vendorId[13];

    memset(data, 0, sizeof(uint32)*PWR_NUM_CPUID_OFFSETS);
    ReadCPUID(data, 0);

    DRVPRINT("cpuid1 eax=%u, ebx=%u, ecx=%u, edx=%u \n", data[PWR_EAX_OFFSET], data[PWR_EBX_OFFSET], data[PWR_ECX_OFFSET], data[PWR_EDX_OFFSET]);
    memcpy(vendorId, &data[PWR_EBX_OFFSET], 4);
    memcpy(vendorId + 4, &data[PWR_EDX_OFFSET], 4);
    memcpy(vendorId + 8, &data[PWR_ECX_OFFSET], 4);
    vendorId[12] = '\0';

    if (0 != strcmp(vendorId, "AuthenticAMD"))
    {
        printk(KERN_WARNING "pcore: NON AMD CPU found \n");
        cpu->m_value = 0;
        return;
    }

    memset(data, 0, sizeof(uint32)*PWR_NUM_CPUID_OFFSETS);
    ReadCPUID(data, CPUID_FnBasicFeatures);
    cpu->m_value = data[PWR_EAX_OFFSET];
    cpu->m_isHypervisor = false;

    if ((data[PWR_ECX_OFFSET] & CPUID_FnBasicFeatures_ECX_Hypervisor) != 0)
    {
        cpu->m_isHypervisor = true;
        printk(KERN_WARNING "pcore: Hypervisor Detected\n");
    }
}

// Get CPU signature.
CpuSignature* GetCpuSignature(void)
{

    if (!IsCpuSigRead)
    {
        ReadCpuSignature(&cpu_sig);
        IsCpuSigRead = true;
    }

    return &cpu_sig;
}

// Check for Amd platform
bool IsAmd(CpuSignature* cpu)
{
    return cpu->m_value != 0U;
}

// Get Cpu family
uint GetFamilyValue(CpuSignature* cpu)
{
    return ((cpu->m_value & CpuBaseFamily_MASK) >> 8) + ((cpu->m_value & CpuExtFamily_MASK) >> 20);
}

// Get Cpu model
uint GetModelValue(CpuSignature* cpu)
{
    return ((cpu->m_value & CpuBaseModel_MASK) >> 4) | ((cpu->m_value & CpuExtModel_MASK) >> (16 - 4));
}

// Check if hardware is supported.
long CheckHwSupport(void)
{
    uint family;
    uint model;

    CpuSignature* sig = GetCpuSignature();

    /* Following are not supported:
    1. Non AMD Platforms
    2. Hypervisors
    */
    if (!IsAmd(sig))
    {
        DRVPRINT(KERN_WARNING "pcore:Non AMD Platform detected. pcore only supports AMD platforms\n");
        return -EACCES;
    }

    if (sig->m_isHypervisor)
    {
        DRVPRINT(KERN_WARNING "pcore:Hypervisor detected. pcore does not support Hypervisor platforms\n");
        return -EACCES;
    }

    /*Supported AMD platforms
        Kaveri  :  0x15 30 to 3F
        Carrizo :  0x15 60 to 6F
        Mullins :  0x16 30 to 3F
    */
    family = GetFamilyValue(sig);
    model  = GetModelValue(sig);
    DRVPRINT(" family %x , model %x \n", family, model);

    if ((family < 0x15) || (family > 0x16))
    {
        printk(KERN_WARNING "pcore: Unsupported family 0x%x \n", family);
        return -EACCES;
    }

    if (0x15 == family)
    {
        if (!((model >= 0x30 && model <= 0x3F)
              || (model >= 0x60 && model <= 0x6F)))
        {
            printk(KERN_WARNING "pcore: Unsupported model 0x%x for family 0x%x \n", model, family);
            return -EACCES;
        }
    }

    if (0x16 == family)
    {
        if (!(model >= 0x30 && model <= 0x3F))
        {
            printk(KERN_WARNING "pcore: Unsupported model 0x%x for family 0x%x \n", model, family);
            return -EACCES;
        }
    }

    /*
    4. TODO: AMD dGPU on a non AMD platforms SHOULD be supported.
    5. If SMU is not avaliabe support only Core Counters/ MSR's.
    6. If BAPM is disabled - Enable/ Disable through BIOS messages.
    7. If iGPU is disabled same as #5.
    */

    return 0;
}

// Get the current core id
uint32 GetCurrentCoreId(void)
{
    int cpu = get_cpu();
    put_cpu();
    return (uint32)cpu;
}

// Get number of control unit present in a node.
uint32 GetCuCountPerNode(void)
{
    // D18F5x80 gives the CU count
    uint bus = 0U;
    uint device = 0x18U;
    uint function = 0x5U;
    uint reg = 0x80U;

    uint cuStatus = 0U;

    cuStatus = ReadPCIDev(bus, device, function, reg);

    return (cuStatus & 0x1U) + ((cuStatus >> 1) & 0x1U);
}

void PwrSetExtendedApicId(TARGET_SYSTEM_INFO* pTargetInfo)
{
    cpumask_t* pMask = NULL;

    pMask = kmalloc(sizeof(cpumask_t), GFP_KERNEL);

    if ((NULL != pMask) && (1 == pTargetInfo->m_isZen))
    {
        uint32 cores = 0;
        uint32 cpu = 0;
        uint64 mask[PWR_CORE_MASK_SIZE];

        memset(mask, 0, sizeof(uint64) * PWR_CORE_MASK_SIZE);
        cores = GetTargetCoreCount();

        if (cores < PWR_CORE_MASK_BITS_COUNT)
        {
            mask[0] = ~0ULL ^ (~0ULL << cores);
        }
        else if (cores <= (PWR_CORE_MASK_BITS_COUNT * 2))
        {
            uint64 resetBits = (2 * PWR_CORE_MASK_BITS_COUNT) - cores;
            mask[0] = ~0ULL;
            mask[1] = ~0ULL >> resetBits;
        }
        else if (cores <= (PWR_CORE_MASK_BITS_COUNT * 3))
        {
            uint64 resetBits = (3 * PWR_CORE_MASK_BITS_COUNT) - cores;
            mask[0] = ~0ULL;
            mask[1] = ~0ULL;
            mask[2] = ~0ULL >> resetBits;
        }
        else if (cores <= (PWR_CORE_MASK_BITS_COUNT * 4))
        {
            uint64 resetBits = (4 * PWR_CORE_MASK_BITS_COUNT) - cores;
            mask[0] = ~0ULL;
            mask[1] = ~0ULL;
            mask[2] = ~0ULL;
            mask[3] = ~0ULL >> resetBits;
        }
        else if (cores <= (PWR_CORE_MASK_BITS_COUNT * 5))
        {
            uint64 resetBits = (5 * PWR_CORE_MASK_BITS_COUNT) - cores;
            mask[0] = ~0ULL;
            mask[1] = ~0ULL;
            mask[2] = ~0ULL;
            mask[3] = ~0ULL;
            mask[4] = ~0ULL >> resetBits;
        }
        else if (cores <= (PWR_CORE_MASK_BITS_COUNT * 6))
        {
            uint64 resetBits = (6 * PWR_CORE_MASK_BITS_COUNT) - cores;
            mask[0] = ~0ULL;
            mask[1] = ~0ULL;
            mask[2] = ~0ULL;
            mask[3] = ~0ULL;
            mask[4] = ~0ULL;
            mask[5] = ~0ULL >> resetBits;
        }
        else if (cores <= (PWR_CORE_MASK_BITS_COUNT * 7))
        {
            uint64 resetBits = (7 * PWR_CORE_MASK_BITS_COUNT) - cores;
            mask[0] = ~0ULL;
            mask[1] = ~0ULL;
            mask[2] = ~0ULL;
            mask[3] = ~0ULL;
            mask[4] = ~0ULL;
            mask[5] = ~0ULL;
            mask[6] = ~0ULL >> resetBits;
        }

        // Prepare cpu m_affinity mask structure for the configured core mask
        cpumask_clear(pMask);
        PrepareAffinityMask(pMask, mask);

        cpu = get_cpu();
        put_cpu();

        if (cpumask_test_cpu(cpu, pMask))
        {
            PwrCoreDpc(pTargetInfo->m_zen.m_apic);
        }

        preempt_disable();
        smp_call_function_many(pMask,
                               (void*)PwrCoreDpc,
                               (void*)pTargetInfo->m_zen.m_apic,
                               true); // blocking call
        preempt_enable();
        PrepareApicList(pTargetInfo);
    }
}
#endif

void IRPerfDpc(void* info)
{
    uint32 msr = HWCF;
    uint64 value = 0;
    bool irPerfEn = false;

    value = ReadMSR(msr);

    irPerfEn = (0ULL != (value & HwCfgIRPerfEn)) ? true : false;

    if (!irPerfEn)
    {
        value |= HwCfgIRPerfEn;
        WriteMSR(msr, value);
    }
}

bool EnableIRPerf(PTARGET_SYSTEM_INFO pTargetInfo)
{
    bool ret = false;
    bool isIRPerfAvailable = false;
    uint32 ebxOffset = PwrReadCpuId(PWR_ECX_OFFSET, CPUID_FnSizeID);
    uint32 coreId = 0;

    isIRPerfAvailable = (0 != ((ebxOffset >> 1) & 0x1));

    if ((NULL != pTargetInfo) && isIRPerfAvailable)
    {
        for (coreId = 0; coreId < pTargetInfo->m_zen.m_totalThreads; coreId++)
        {
#if defined(_WIN32)
            DeferedCoreExecution(coreId, (void*)IRPerfDpc, NULL);
#endif

#if defined (__linux__)
            smp_call_function_single((int)coreId,
                                     (smp_call_func_t)IRPerfDpc, NULL, true); // blocking call
#endif
        }

        ret = true;
    }

    return ret;
}

// Note: Call this function once APIC IDs have been populated
void PwrSetExtPerfMonAndDbgInfo(TARGET_SYSTEM_INFO* pTargetInfo)
{
    DRVPRINT("PwrSetExtPerfMonAndDbgInfo");

    if ((NULL != pTargetInfo)
        && (1 == pTargetInfo->m_isZen))
    {
        uint32 coreId = 0;
        uint32 socketId = 0;
        int32_t socketCoreArray[PWR_MAX_SOCKET_COUNT];

        memset(socketCoreArray, -1, PWR_MAX_SOCKET_COUNT * sizeof(int32_t));

        for (coreId = 0; coreId < pTargetInfo->m_zen.m_totalThreads; coreId++)
        {
            socketId = pTargetInfo->m_zen.m_apic[coreId].m_nodeId;

            if ((socketId < PWR_MAX_SOCKET_COUNT) && (socketCoreArray[socketId] < 0))
            {
                socketCoreArray[socketId] = (int32_t)coreId;
            }
        }

        for (socketId = 0; socketId < PWR_MAX_SOCKET_COUNT; socketId++)
        {
            if (socketCoreArray[socketId] >= 0)
            {
#if defined(_WIN32)
                DeferedCoreExecution(static_cast<uint32>(socketCoreArray[socketId]),
                                     PwrExtPerfMonAndDbgInfoDpc, &(pTargetInfo->m_zen.m_perfMonInfo[socketId]));
#endif
#if defined (__linux__)
                smp_call_function_single(socketCoreArray[socketId], (smp_call_func_t)PwrExtPerfMonAndDbgInfoDpc,
                                         (void*) & (pTargetInfo->m_zen.m_perfMonInfo[socketId]), true);
#endif
            }
        }
    }
}

