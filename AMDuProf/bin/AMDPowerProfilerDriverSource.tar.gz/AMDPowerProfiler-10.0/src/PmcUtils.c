//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcUtils.c
///
//==================================================================================

#if !(__KERNEL__)
    #include <stddef.h>
#endif

#include <PmcUtils.h>

const char* GetPmcTypeString(PmcPmuType type)
{
    switch (type)
    {
        case PMC_PMU_CORE:
            return "core";

        case PMC_PMU_L3:
            return "l3";

        case PMC_PMU_DF:
            return "df";

        case PMC_PMU_UMC:
            return "umc";

        default:
            return NULL;
    }
}

uint64_t* GetCoreMaskArray(CountModeProfileConfig* pConfig, PmcPmuType type)
{
    switch (type)
    {
        case PMC_PMU_CORE:
            return pConfig->m_corePmcCoreMaskArray;

        case PMC_PMU_L3:
            return pConfig->m_l3PmcCoreMaskArray;

        case PMC_PMU_DF:
            return pConfig->m_dfPmcCoreMaskArray;

        case PMC_PMU_UMC:
            return pConfig->m_umcPmcCoreMaskArray;

        default:
            return NULL;
    }
}

uint64_t* GetPmcConfigArray(CountModeGroupConfig* pConfig)
{
    switch (pConfig->m_configHeader.m_header.m_groupType)
    {
        case GROUP_TYPE_CORE_PMC:
            return  pConfig->m_cfgArray.m_corePmcConfigArray;

        case GROUP_TYPE_L3_PMC:
            return pConfig->m_cfgArray.m_l3PmcConfigArray;

        case GROUP_TYPE_DF_PMC:
            return  pConfig->m_cfgArray.m_dfPmcConfigArray;

        case GROUP_TYPE_UMC_PMC:
            return  pConfig->m_cfgArray.m_umcPmcConfigArray;

        default:
            return NULL;
    }
}

PmcPmuType GetPmcType(GroupType groupType)
{
    switch (groupType)
    {
        case GROUP_TYPE_CORE_PMC:
            return PMC_PMU_CORE;

        case GROUP_TYPE_L3_PMC:
            return PMC_PMU_L3;

        case GROUP_TYPE_DF_PMC:
            return PMC_PMU_DF;

        case GROUP_TYPE_UMC_PMC:
            return PMC_PMU_UMC;

        default:
            return PMC_PMU_INVALID;
    }
}
