//==================================================================================
// Copyright (c) 2021 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PmcProcessConfig.c
///
//==================================================================================

// Project Includes:
#include <PmcProcessConfig.h>
#include <PmcUtils.h>
#include <PmcTimerConfig.h>
#include <PwrOsPrimitives.h>
#include <PmcDataBuffer.h>
#include <PmcDataBufferOps.h>
#include <PwrCommonDataTypes.h>
#include <PwrDriverUtils.h>

#if defined(_WIN32)
    #include <errno.h>
#endif

#if defined(__linux__)
    #include <linux/cpumask.h>
#endif

#define PMC_IRPERF_MAX_VALUE    0xFFFFFFFFFFFFULL
#define PMC_MPERF_MAX_VALUE     0xFFFFFFFFFFFFULL
#define PMC_APERF_MAX_VALUE     0xFFFFFFFFFFFFULL

#if defined (_WIN32)
    #include <intrin.h>
    #define POPCNT(x)   __popcnt(x)
#elif defined (__linux__)
    #define POPCNT(x)   __builtin_popcount(x)
#endif

/*
 * Note: There can only be one registered client at a time
 * with current implementation. In future, this can be a
 * changed to a list of clients
 */
extern ClientContext* g_pPmcClientContext;

/* Number of PMCs can vary for sockets. This function
 * returns the maximum of all sockets */
uint32_t GetMaxPmcCount(PmcPmuType type, uint16_t* pDebugPmcCnt)
{
    PTARGET_SYSTEM_INFO pTargetSystemInfo = NULL;
    uint32_t pmcCount = 0;
    uint32_t umcCount = 0;
    GetTargetSystemInfo(&pTargetSystemInfo);

    if (NULL != pTargetSystemInfo)
    {
        switch (type)
        {
            case PMC_PMU_CORE:
                pmcCount = pTargetSystemInfo->m_zen.m_perfMonInfo[0].m_numOfCorePmc;
                *pDebugPmcCnt = CORE_PMC_DEBUG_COUNT;
                break;

            case PMC_PMU_L3:
                pmcCount = pTargetSystemInfo->m_zen.m_perfMonInfo[0].m_numOfL3Pmc;
                *pDebugPmcCnt = 0;
                break;

            case PMC_PMU_DF:
                pmcCount = pTargetSystemInfo->m_zen.m_perfMonInfo[0].m_numOfDfPmc;
                *pDebugPmcCnt = 0;
                break;

            case PMC_PMU_UMC:
                // Note: This will fail if socket 0 has no active UMCs
                umcCount = POPCNT(pTargetSystemInfo->m_zen.m_perfMonInfo[0].m_activeUmcMask);
                pmcCount = (umcCount != 0) ? pTargetSystemInfo->m_zen.m_perfMonInfo[0].m_numOfUmcPmc / umcCount : 0;
                *pDebugPmcCnt = 0;
                break;

            default:
                break;
        }
    }

    return pmcCount;
}

// Note: Must be obtained before any pmc counters are configured
void GetPmcAvailabilityMask(void* pInfo)
{
    CoreContext* pCoreCtx = (CoreContext*)pInfo;
    int type = PMC_PMU_INVALID;
    uint32_t msrIdx = 0;
    uint16_t pmcCnt = 0;
    uint16_t debugPmcCnt = 0;
    uint64_t msrValue = 0;

    for (type = PMC_PMU_CORE; type < PMC_PMU_MAX && type != PMC_PMU_UMC; type++)
    {
        pmcCnt = GetMaxPmcCount((PmcPmuType)type, &debugPmcCnt);

        for (msrIdx = 0; msrIdx < pmcCnt; msrIdx++)
        {
            switch (type)
            {
                case PMC_PMU_CORE:
                    msrValue = ReadMSR(CORE_PMC_CFG_MSR(msrIdx));
                    break;

                case PMC_PMU_L3:
                    msrValue = ReadMSR(CHL3_PMC_CFG_MSR(msrIdx));
                    break;

                case PMC_PMU_DF:
                    msrValue = ReadMSR(DF_PMC_CFG_MSR(msrIdx));
                    break;

                default:
                    break;
            }

            if ((msrValue & PMC_CFG_ENABLE) == 0)
            {
                pCoreCtx->m_availabilityMask[type] |= (1 << msrIdx);
            }
        }
    }
}

// TODO: Move this function to Utils?
uint64_t GetDfClk(uint32_t coreId)
{
    uint64_t fclk = 0;
    uint32_t node = 0;
    uint32_t zenVer = 0;

    node = GetNodeIdForCore(coreId);
    zenVer = GetZenVersion();

    if (zenVer == PWR_ZEN2 || zenVer == PWR_ZEN3)
    {
        // FCLK in SSP:
        //     Low  - Bus 0, Device 0x18, Function 0x5, Offset 0x1D0
        //     High - Bus 0, Device 0x18, Function 0x5, Offset 0x1D4
        uint32_t low = 0;
        uint32_t hi = 0;
        uint32_t dev = 0x18 + node;

        low = ReadPCIDev(0x0, dev, 0x5, 0x1D0);
        hi = ReadPCIDev(0x0, dev, 0x5, 0x1D4);

        fclk = low;
        fclk |= ((uint64_t)(hi & 0xFF) << 32);
    }
    else if (zenVer >= PWR_ZEN4)
    {
        // FCLK in Stones:
        //     Low  - Bus 0, Device 0x18, Function 0x5, Offset 0x1D8
        //     High - Bus 0, Device 0x18, Function 0x5, Offset 0x1DC
        uint32_t low = 0;
        uint32_t hi = 0;
        uint32_t dev = 0x18 + node;

        low = ReadPCIDev(0x0, dev, 0x5, 0x1D8);
        hi = ReadPCIDev(0x0, dev, 0x5, 0x1DC);

        fclk = low;
        fclk |= ((uint64_t)(hi & 0xFF) << 32);
    }

    return fclk;
}

void ResetPmcConfigGroup(CoreContext* pCoreCtx, PmcPmuType type)
{
    uint16_t msrIdx = 0;
    uint16_t configGroupIdx = 0;
    uint16_t pmcCnt = 0;
    uint16_t debugPmcCnt = 0;
    uint16_t maxPmcCnt = 0;
    uint16_t configGroupCnt = 0;
    uint16_t pmcConfigCnt = 0;
    PmcConfigGroup* pPmcConfigGroup = NULL;
    PmcConfig* pPmcConfigArray = NULL;
    uint32_t umcMsrCount = 0;
    uint32_t umcMsrCountArrayIdx = 0;

    pmcCnt = GetMaxPmcCount(type, &debugPmcCnt);
    maxPmcCnt = pmcCnt + debugPmcCnt;

    configGroupCnt = pCoreCtx->m_pmcConfigGroupCnt[type];
    pPmcConfigGroup = pCoreCtx->m_pPmcConfigGroupArray[type];

    /* Iterate through all pmc config groups */
    for (configGroupIdx = 0; configGroupIdx < configGroupCnt; configGroupIdx++)
    {
        /* Reset delta tsc/irperf/mperf/aperf/fclk */
        pPmcConfigGroup->m_deltaTime = 0;
        pPmcConfigGroup->m_dfClkDelta = 0;
        pPmcConfigGroup->m_irPerfDelta = 0;
        pPmcConfigGroup->m_mPerfDelta = 0;
        pPmcConfigGroup->m_aPerfDelta = 0;

        pmcConfigCnt = pPmcConfigGroup->m_pmcConfigCnt;
        pPmcConfigArray = pPmcConfigGroup->m_pPmcConfigArray;

        /* Iterate through all the pmc configs */
        for (msrIdx = 0; (msrIdx < maxPmcCnt) && (pmcConfigCnt != 0) && type != PMC_PMU_UMC; msrIdx++)
        {
            if (pPmcConfigArray[msrIdx].m_controlValue == 0)
            {
                continue;
            }

            pmcConfigCnt--;
            pPmcConfigArray[msrIdx].m_counterValue = 0;
        }

        if (PMC_PMU_UMC == type)
        {
            umcMsrCount = pPmcConfigGroup->m_umcMsrCount;

            for (umcMsrCountArrayIdx = 0; umcMsrCountArrayIdx < umcMsrCount; umcMsrCountArrayIdx++)
            {
                pPmcConfigGroup->m_pUmcMsrCountArray[umcMsrCountArrayIdx] = 0;
            }
        }

        pPmcConfigGroup = pPmcConfigGroup->m_pNext;
    }
}

int PmcCallBack(ClientContext* pClientCtx, CoreContext* pCoreCtx)
{
    int retVal = 0;
    int type = PMC_PMU_INVALID;
    PmcConfigGroup* pPmcConfigGroup = NULL;
    uint64_t dfClk = 0;
    uint64_t tsc = 0;
    uint64_t irPerf = 0;
    uint64_t mPerf = 0;
    uint64_t aPerf = 0;
    uint64_t delta = 0;
    uint32_t recordSize = 0;

    DRVPRINT("pClientCtx(%p) pCoreCtx(%p)", pClientCtx, pCoreCtx);

    /* Save count values */
    for (type = PMC_PMU_CORE; type < PMC_PMU_MAX && !retVal; type++)
    {
        /* Skip if pmc type does not have a valid configuration */
        if (pCoreCtx->m_pPmcConfigGroupArray[type] == NULL)
        {
            continue;
        }

        /* Decrement sampling counter */
        pCoreCtx->m_currSamplingCounter[type]--;

        /* Save counter values
         *  - Before sample collection
         *  - Before multiplexing
         */
        if ((pCoreCtx->m_currSamplingCounter[type] == 0) || (pCoreCtx->m_pmcConfigGroupCnt[type] > 1))
        {
            /* Save count of current pmc config group */
            retVal = ReadPmcConfigGroup(pCoreCtx->m_pPmcConfigGroupArray[type], (PmcPmuType)type, pCoreCtx->m_umcCount);
        }
    }

    /* Multiplex */
    for (type = PMC_PMU_CORE; type < PMC_PMU_MAX && !retVal; type++)
    {
        pPmcConfigGroup = pCoreCtx->m_pPmcConfigGroupArray[type];

        /* Skip if pmc type does not have a valid configuration */
        if (pPmcConfigGroup == NULL)
        {
            continue;
        }

        /* For more than one event group */
        if (pCoreCtx->m_pmcConfigGroupCnt[type] > 1)
        {
            /* Note: Multiplex before writing sample data to
             * accurately capture delta time, which is captured once
             * the current group is unloaded during multiplexing. */
            retVal = MultiplexPmcConfigGroup(pCoreCtx, (PmcPmuType)type);
        }
        /* For single event group */
        else if (pCoreCtx->m_pmcConfigGroupCnt[type] == 1)
        {
            /* Reset count values before logging sample if
             * multiplexing is not required. */
            if (pCoreCtx->m_currSamplingCounter[type] == 0)
            {
                /* Reset counters */
                ResetPmcCounters(pCoreCtx, (PmcPmuType)type);

                tsc = ReadMSR(PMC_TSC_MSR);

                /* Capture delta time before logging sample. */
                if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_TIMESTAMP)
                {
                    pPmcConfigGroup->m_deltaTime = tsc - pPmcConfigGroup->m_loadTime;
                    pPmcConfigGroup->m_loadTime = tsc;
                }

                /* Capture df clk delta time before logging sample. */
                if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_FCLK)
                {
                    dfClk = GetDfClk(pCoreCtx->m_coreId);
                    pPmcConfigGroup->m_dfClkDelta =  dfClk - pPmcConfigGroup->m_dfClk;
                    pPmcConfigGroup->m_dfClk = dfClk;
                }

                /* Capture IRPerf delta */
                if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_IRPERF)
                {
                    irPerf = ReadMSR(PMC_IRPERF_MSR);

                    // Check if irperf has rolled over
                    if (irPerf < pPmcConfigGroup->m_irPerf)
                    {
                        delta = PMC_IRPERF_MAX_VALUE - pPmcConfigGroup->m_irPerf;
                        delta += irPerf;
                    }
                    else
                    {
                        delta = irPerf - pPmcConfigGroup->m_irPerf;
                    }

                    pPmcConfigGroup->m_irPerfDelta = delta;
                    pPmcConfigGroup->m_irPerf = irPerf;
                }

                /* Capture MPerf delta */
                if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_MPERF)
                {
                    mPerf = ReadMSR(PMC_MPERF_MSR);

                    // Check if mperf has rolled over
                    if (mPerf < pPmcConfigGroup->m_mPerf)
                    {
                        delta = PMC_MPERF_MAX_VALUE - pPmcConfigGroup->m_mPerf;
                        delta += mPerf;
                    }
                    else
                    {
                        delta = mPerf - pPmcConfigGroup->m_mPerf;
                    }

                    pPmcConfigGroup->m_mPerfDelta = delta;
                    pPmcConfigGroup->m_mPerf = mPerf;
                }

                /* Capture APerf delta */
                if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_APERF)
                {
                    aPerf = ReadMSR(PMC_APERF_MSR);

                    // Check if aperf has rolled over
                    if (aPerf < pPmcConfigGroup->m_aPerf)
                    {
                        delta = PMC_APERF_MAX_VALUE - pPmcConfigGroup->m_aPerf;
                        delta += aPerf;
                    }
                    else
                    {
                        delta = aPerf - pPmcConfigGroup->m_aPerf;
                    }

                    pPmcConfigGroup->m_aPerfDelta = delta;
                    pPmcConfigGroup->m_aPerf = aPerf;
                }

                /* Capture time enabled for single config group. */
                pCoreCtx->m_timeEnabled[type] = tsc - pCoreCtx->m_timeEnabledBegin[type];
                pCoreCtx->m_timeEnabledBegin[type] = tsc;
            }
        }
        else
        {
            DRVPRINT("Invalid config group count value(%u)", pCoreCtx->m_pmcConfigGroupCnt[type]);
        }
    }

    /* Collect sample */
    for (type = PMC_PMU_CORE; type < PMC_PMU_MAX && !retVal; type++)
    {
        /* Skip if pmc type does not have a valid configuration */
        if (pCoreCtx->m_pPmcConfigGroupArray[type] == NULL)
        {
            continue;
        }

        /* If core has a valid configuration and sampling
         * counter is zero */
        if (pCoreCtx->m_currSamplingCounter[type] == 0)
        {
            recordSize = (type == PMC_PMU_UMC) ? pCoreCtx->m_umcSampleRecordSize : pClientCtx->m_sampleRecordSize[type];

            retVal = PmcSampleDataCallBack(pCoreCtx, (PmcPmuType)type,
                                           recordSize);

            /* Reset sampling count */
            pCoreCtx->m_currSamplingCounter[type] = pClientCtx->m_samplingCount[type];

            ResetPmcConfigGroup(pCoreCtx, (PmcPmuType)type);
        }
    }

    return retVal;
}

/* Note: Sample record size is fixed for a specific pmc type.
 * Modifying pmc configuration will require
 * recalculation of sample record size. */
static void SetSampleRecordSize(ClientContext* pClientCtx)
{
    int type = PMC_PMU_INVALID;
    uint32_t sampleSize = 0;
    uint32_t coreId = 0;
    uint32_t socketId = 0;
    uint32_t numOfCores = (uint32_t)GetCoreCount();
    uint64_t coreMask = 0;
    uint32_t umcCount = 0;
    uint32_t coreMaskArrayIdx = 0;

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    for (sampleSize = 0, type = PMC_PMU_CORE; type < PMC_PMU_MAX && type != PMC_PMU_UMC; type++)
    {
        /* Skip if there is no valid config for pmc type */
        if (pClientCtx->m_pmcConfigGroupCnt[type] == 0)
        {
            continue;
        }

        /* Exclude size of variable element: m_data */
        sampleSize = sizeof(PmcSample) - sizeof(uint64_t);

        /* Include PMC configuration group header */
        sampleSize += pClientCtx->m_pmcConfigGroupCnt[type] * sizeof(uint64_t);

        sampleSize += sizeof(uint64_t) * pClientCtx->m_totalPmcConfigCnt[type];
        sampleSize += sizeof(uint64_t) * pClientCtx->m_totalPmcAttrCnt[type];

        pClientCtx->m_sampleRecordSize[type] = sampleSize;

        DRVPRINT("SampleSize[%d](%u)", type, sampleSize);
    }

    /* Sample record size for UMC will vary for each socket depending
     * on the number of active UMCs */
    if (PMC_PMU_UMC == type)
    {
        CoreContext* pCoreCtx = NULL;

        for (coreId = 0; coreId < numOfCores; coreId++)
        {
            coreMaskArrayIdx = coreId / PMC_CORE_MASK_BIT_WIDTH;
            coreMask = (coreMaskArrayIdx < PMC_CORE_MASK_ARRAY_SIZE) ? pClientCtx->m_pPmcCoreMaskArray[type][coreMaskArrayIdx] : 0;

            // Check if this coreId is set in coreMask
            if ((coreMask & (1ULL << (coreId - (coreMaskArrayIdx * PMC_CORE_MASK_BIT_WIDTH)))) == 0)
            {
                continue;
            }

            pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

            /* Exclude size of variable element: m_data */
            sampleSize = sizeof(PmcSample) - sizeof(uint64_t);

            /* Include PMC configuration group header */
            sampleSize += (pClientCtx->m_pmcConfigGroupCnt[type] * sizeof(uint64_t));

            // Get socketId for the core
            socketId = GetSocketIdForCore(coreId);

            // Get umcCount for socket
            umcCount = POPCNT(pClientCtx->m_pUmcMaskArray[socketId]);

            sampleSize += (sizeof(uint64_t) * pClientCtx->m_totalPmcConfigCnt[type] * umcCount);
            sampleSize += (sizeof(uint64_t) * pClientCtx->m_totalPmcAttrCnt[type]);

            if (NULL != pCoreCtx)
            {
                pCoreCtx->m_umcSampleRecordSize = sampleSize;
                pCoreCtx->m_umcCount = umcCount;
                pCoreCtx->m_socketId = socketId;
            }

            DRVPRINT("SampleSize[%d](%u) coreId(%u) socketId(%u)", type, sampleSize, coreId, socketId);
        }
    }
}

int GetGroupAttrCount(uint8_t groupAttr)
{
    int count = 0;
    int i = 0;

    for (i = 0; i < PMC_GROUP_ATTR_WIDTH; i++)
    {
        count += (groupAttr & (1 << i)) ? 1 : 0;
    }

    return count;
}

int PmcWriteSampleData(CoreContext* pCoreCtx,
                       PmcPmuType type,
                       char* pBuffer)
{
    PmcSample* pSample = NULL;
    uint16_t msrIdx = 0;
    PmcConfig* pPmcConfig = NULL;
    uint16_t configCnt = 0;
    int i = 0;
    uint16_t pmcCnt = 0;
    uint16_t debugPmcCnt = 0;
    uint16_t maxPmcCnt = 0;
    uint64_t pmcConfigGroupAttrs = 0;
    uint32_t umcIdx = 0;
    uint32_t umcMsrCountArrayIdx = 0;
    uint16_t cfgGroupCnt = 0;

    if (NULL != pCoreCtx)
    {
        PmcConfigGroup* pCfg = pCoreCtx->m_pPmcConfigGroupArray[type];
        cfgGroupCnt = pCoreCtx->m_pmcConfigGroupCnt[type];

        DRVPRINT("pPmcConfigGroup(%p) configGroupCnt(%d) type(%s) "
                 "coreId(%d) pBuffer(%p)", pCoreCtx->m_pPmcConfigGroupArray[type],
                 cfgGroupCnt, GetPmcTypeString(type), pCoreCtx->m_coreId, pBuffer);

        pmcCnt = GetMaxPmcCount(type, &debugPmcCnt);
        maxPmcCnt = pmcCnt + debugPmcCnt;

        /* Write Sample header */
        pSample = (PmcSample*)pBuffer;

        if ((NULL != pSample) && (NULL != pCfg))
        {
            pSample->m_time = GetTimestamp();
            pSample->m_coreId = pCoreCtx->m_coreId;
            pSample->m_socketId = pCoreCtx->m_socketId;
            pSample->m_deltaTimeEnabled = pCoreCtx->m_timeEnabled[type];

            while (cfgGroupCnt--)
            {
                configCnt = pCfg->m_pmcConfigCnt;
                pmcConfigGroupAttrs = pCfg->m_pmcConfigGroupAttrs;

                // TODO: Add configCnt and type to header? Not required?
                pSample->m_data[i] = (pCfg->m_pmcConfigGroupId & PMC_SAMPLE_HDR_GROUP_ID_MASK);
                pSample->m_data[i] |= (pCfg->m_pmcConfigGroupAttrs & PMC_SAMPLE_HDR_ATTR_MASK) << PMC_SAMPLE_HDR_ATTR_SHIFT;
                i++;

                if (pmcConfigGroupAttrs != 0)
                {
                    /* Include timestamp in this group? */
                    if (pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_TIMESTAMP)
                    {
                        pSample->m_data[i] = pCfg->m_deltaTime;
                        i++;
                    }

                    if (pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_IRPERF)
                    {
                        pSample->m_data[i] = pCfg->m_irPerfDelta;
                        i++;
                    }

                    if (pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_MPERF)
                    {
                        pSample->m_data[i] = pCfg->m_mPerfDelta;
                        i++;
                    }

                    if (pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_APERF)
                    {
                        pSample->m_data[i] = pCfg->m_aPerfDelta;
                        i++;
                    }

                    if (pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_FCLK)
                    {
                        pSample->m_data[i] = pCfg->m_dfClkDelta;
                        i++;
                    }
                }

                /* Write Sample data */
                for (msrIdx = 0; msrIdx < maxPmcCnt && configCnt > 0 && type != PMC_PMU_UMC; msrIdx++)
                {
                    pPmcConfig = &pCfg->m_pPmcConfigArray[msrIdx];

                    if (!pPmcConfig->m_controlValue)
                    {
                        continue;
                    }

                    pSample->m_data[i] = pPmcConfig->m_counterValue;
                    i++;
                    configCnt--;
                }

                if (PMC_PMU_UMC == type)
                {
                    uint32_t umcConfigIdx = 0;

                    DRVPRINT("core(%d) cfgGroupCnt(%d) pCoreCtx->m_umcCount(%d) configCnt(%d)", GetCurrentCoreId(), cfgGroupCnt, pCoreCtx->m_umcCount, configCnt);

                    for (umcIdx = 0, umcMsrCountArrayIdx = 0; umcIdx < pCoreCtx->m_umcCount; umcIdx++)
                    {
                        for (umcConfigIdx = 0; umcConfigIdx < configCnt; umcConfigIdx++)
                        {
                            if (pCfg->m_pPmcConfigArray[umcConfigIdx].m_controlValue == 0)
                            {
                                continue;
                            }

                            pSample->m_data[i] = pCfg->m_pUmcMsrCountArray[umcMsrCountArrayIdx];
                            DRVPRINT("DATA[%d]=(0x%llx)", i, pSample->m_data[i]);
                            i++;
                            umcMsrCountArrayIdx++;
                        }
                    }
                }

                pCfg = pCfg->m_pNext;
            }

            /* Update size of sample record (including header)
             * Adjust i to account for last element in PmcSample */
            pSample->m_sampleHeader.m_header.m_sampleSize = sizeof(PmcSample) + (i - 1) * sizeof(uint64_t);

            //DRVPRINT("sampleSize(%ubytes)", pSample->m_sampleHeader.m_header.m_sampleSize);
        }
    }

    // Always return success
    return 0;
}

int PmcSampleDataCallBack(CoreContext* pCoreCtx,
                          PmcPmuType type,
                          uint32_t recordSize)
{
    int retVal = 0;
    void* pBuffer = NULL;

    DRVPRINT("pCoreCtx(%p) type(%s) recordSize(%u)",
             pCoreCtx, GetPmcTypeString(type), recordSize);

    /* Reserve space in buffer for sample record */
    pBuffer = PmcGetDataBuffer(pCoreCtx->m_pDataBufferContext[type],
                               recordSize);

    if (pBuffer != NULL)
    {
        PmcWriteSampleData(pCoreCtx,
                           type,
                           (char*)pBuffer);
    }
    else
    {
        /* TODO: Handle dropped sample stats here */
        pCoreCtx->m_droppedSampleCount[type]++;
        retVal = ENOMEM;
    }

    if (pCoreCtx->m_pDataBufferContext[type]->m_pendingRead)
    {
        /* Notify consumer of data availibility and clear
         * the pending flag */
        NotifyPendingRead(pCoreCtx->m_pDataBufferContext[type]);
        pCoreCtx->m_pDataBufferContext[type]->m_pendingRead = false;
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

/*
 * TODO: How to determine if core pmcs are already occupied
 * TODO: Watchdog will occupy one pmc if active, how do we know
 * which pmc is occuped by watchdog or other profilers
 * Note: PmcConfigs can be staggered
 */
int LoadPmcConfig(PmcConfigGroup* pPmcConfigGroup, PmcPmuType type, uint32_t umcCount, bool reset)
{
    int retVal = 0;
    int msrIdx = 0;
    int debugMsrIdx = 0;
    PmcConfig* pPmcConfigArray = pPmcConfigGroup->m_pPmcConfigArray;
    uint16_t pmcConfigCnt = pPmcConfigGroup->m_pmcConfigCnt;
    uint16_t maxPmcCnt = 0;
    uint16_t pmcCnt = 0;
    uint16_t debugPmcCnt = 0;
    uint64_t controlValue = 0;
    uint64_t counterValue = 0;
    uint32_t umcIdx = 0;
    uint32_t umcMsrIdx = 0;
    uint32_t msrCountPerUmc = 0;

    DRVPRINT("pPmcConfigGroup(%p) type(%d) reset(%d) pmcConfigCnt(%u) pPmcConfigArray(%p)",
             pPmcConfigGroup, type, reset, pmcConfigCnt, pPmcConfigArray);

    pmcCnt = GetMaxPmcCount(type, &debugPmcCnt);
    maxPmcCnt = pmcCnt + debugPmcCnt;

    for (msrIdx = 0; (pmcConfigCnt > 0) && (msrIdx < maxPmcCnt) && (type != PMC_PMU_UMC); msrIdx++)
    {
        controlValue = pPmcConfigArray[msrIdx].m_controlValue;

        if (controlValue == 0)
        {
            continue;
        }

        --pmcConfigCnt;
        counterValue = reset ? 0 : pPmcConfigArray[msrIdx].m_counterValue;

        /* Public Pmcs*/
        if (msrIdx < pmcCnt)
        {
            switch (type)
            {
                case PMC_PMU_CORE:
                    WriteMSR(CORE_PMC_CFG_MSR(msrIdx), controlValue);
                    WriteMSR(CORE_PMC_COUNT_MSR(msrIdx), counterValue);
                    break;

                case PMC_PMU_L3:
                    WriteMSR(CHL3_PMC_CFG_MSR(msrIdx), controlValue);
                    WriteMSR(CHL3_PMC_COUNT_MSR(msrIdx), counterValue);
                    break;

                case PMC_PMU_DF:
                    WriteMSR(DF_PMC_CFG_MSR(msrIdx), controlValue);
                    WriteMSR(DF_PMC_COUNT_MSR(msrIdx), counterValue);
                    break;

                default:
                    break;
            }
        }
        /* Debug Pmcs*/
        else if (msrIdx < maxPmcCnt)
        {
            debugMsrIdx = msrIdx - pmcCnt;

            switch (type)
            {
                case PMC_PMU_CORE:
                    WriteMSR(CORE_PMC_DEBUG_CFG_MSR(debugMsrIdx), controlValue);
                    WriteMSR(CORE_PMC_DEBUG_COUNT_MSR(debugMsrIdx), counterValue);
                    break;

                case PMC_PMU_DF:
                    WriteMSR(DF_PMC_DEBUG_CFG_MSR(debugMsrIdx), controlValue);
                    WriteMSR(DF_PMC_DEBUG_COUNT_MSR(debugMsrIdx), counterValue);
                    break;

                case PMC_PMU_L3:
                default:
                    break;
            }
        }
        else
        {
            DRVPRINT("Invalid msrIdx(%d).", msrIdx);
        }
    }

    /*
     * Load Config for all UMCs set in umcMask
     */
    if (PMC_PMU_UMC == type)
    {
        msrCountPerUmc = maxPmcCnt;

        for (umcIdx = 0; umcIdx < umcCount; umcIdx++)
        {
            for (umcMsrIdx = 0; umcMsrIdx < msrCountPerUmc; umcMsrIdx++)
            {
                controlValue = pPmcConfigArray[umcMsrIdx].m_controlValue;

                if (controlValue == 0)
                {
                    continue;
                }

                counterValue = reset ? 0 : pPmcConfigArray[umcMsrIdx].m_counterValue;

                WriteMSR(UMC_PMC_CFG_MSR((umcMsrIdx + (umcIdx * msrCountPerUmc))), controlValue);
                WriteMSR(UMC_PMC_COUNT_MSR((umcMsrIdx + (umcIdx * msrCountPerUmc))), counterValue);
            }
        }
    }

    /* Capture pmc config group load time */
    if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_TIMESTAMP)
    {
        pPmcConfigGroup->m_loadTime = ReadMSR(PMC_TSC_MSR);
    }

    /* Capture DfClk if required */
    if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_FCLK)
    {
        pPmcConfigGroup->m_dfClk = GetDfClk(GetCurrentCoreId());
    }

    /* Capture IRPerf if required */
    if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_IRPERF)
    {
        pPmcConfigGroup->m_irPerf = ReadMSR(PMC_IRPERF_MSR);
    }

    /* Capture MPerf if required */
    if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_MPERF)
    {
        pPmcConfigGroup->m_mPerf = ReadMSR(PMC_MPERF_MSR);
    }

    /* Capture APerf if required */
    if (pPmcConfigGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_APERF)
    {
        pPmcConfigGroup->m_aPerf = ReadMSR(PMC_APERF_MSR);
    }

    return retVal;
}

/* TODO: Add a flag to enable/disable collecting debug pmcs */
int ReadPmcConfigGroup(PmcConfigGroup* pPmcConfigGroup, PmcPmuType type, uint32_t umcCount)
{
    int retVal = 0;
    uint32_t debugMsrIdx = 0;
    uint32_t msrIdx = 0;
    PmcConfig* pPmcConfigArray = pPmcConfigGroup->m_pPmcConfigArray;
    uint16_t pmcConfigCnt = pPmcConfigGroup->m_pmcConfigCnt;
    uint32_t maxPmcCnt = 0;
    uint16_t pmcCnt = 0;
    uint16_t debugPmcCnt = 0;
    uint32_t umcIdx = 0;
    uint32_t umcMsrIdx = 0;
    uint32_t msrCountPerUmc = 0;
    uint32_t umcMsrCountArrayIdx = 0;

    pmcCnt = GetMaxPmcCount(type, &debugPmcCnt);
    maxPmcCnt = pmcCnt + debugPmcCnt;

    DRVPRINT("pPmcConfigGroup(%p) type(%d) pmcConfigCnt(%u) pPmcConfigArray(%p)",
             pPmcConfigGroup, type, pmcConfigCnt, pPmcConfigArray);

    for (msrIdx = 0; pmcConfigCnt > 0 && type != PMC_PMU_UMC; msrIdx++)
    {
        if (!pPmcConfigArray[msrIdx].m_controlValue)
        {
            continue;
        }

        pmcConfigCnt--;

        /* Public Pmcs*/
        if (msrIdx < pmcCnt)
        {
            switch (type)
            {
                case PMC_PMU_CORE:
                    pPmcConfigArray[msrIdx].m_counterValue =
                        ReadMSR(CORE_PMC_COUNT_MSR(msrIdx));
                    break;

                case PMC_PMU_L3:
                    pPmcConfigArray[msrIdx].m_counterValue =
                        ReadMSR(CHL3_PMC_COUNT_MSR(msrIdx));
                    break;

                /* TODO: Do we need separate reads fir HI/Lo
                 * for DF MSR. Is that for Legacy??.
                 * Do we need to add a memory barrier in between
                 * do they are not executed out of order?.*/
                case PMC_PMU_DF:
                    pPmcConfigArray[msrIdx].m_counterValue =
                        ReadMSR(DF_PMC_COUNT_MSR(msrIdx));
                    break;

                default:
                    break;
            }
        }
        /* Debug Pmcs*/
        else if (msrIdx < maxPmcCnt)
        {
            debugMsrIdx = msrIdx - pmcCnt;

            switch (type)
            {
                case PMC_PMU_CORE:
                    pPmcConfigArray[msrIdx].m_counterValue =
                        ReadMSR(CORE_PMC_COUNT_MSR(debugMsrIdx));
                    break;

                case PMC_PMU_DF:
                    /* TODO: Do we need separate reads fir HI/Lo
                     * for DF MSR */
                    pPmcConfigArray[msrIdx].m_counterValue =
                        ReadMSR(DF_PMC_COUNT_MSR(debugMsrIdx));
                    break;

                case PMC_PMU_L3:
                default:
                    break;
            }
        }
        else
        {
            DRVPRINT("Invalid msrIdx(%d)", msrIdx);
        }
    }

    if (PMC_PMU_UMC == type)
    {
        msrCountPerUmc = maxPmcCnt;

        for (umcIdx = 0, umcMsrCountArrayIdx = 0; umcIdx < umcCount;  umcIdx++)
        {
            for (umcMsrIdx = 0; umcMsrIdx < msrCountPerUmc; umcMsrIdx++)
            {
                if (pPmcConfigArray[umcMsrIdx].m_controlValue == 0)
                {
                    continue;
                }

                pPmcConfigGroup->m_pUmcMsrCountArray[umcMsrCountArrayIdx] =
                    ReadMSR(UMC_PMC_COUNT_MSR((umcMsrIdx + (umcIdx * msrCountPerUmc))));

                umcMsrCountArrayIdx++;
            }
        }
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

void ClearPmcConfig(void* pCtx)
{
    CoreContext* pCoreCtx = (CoreContext*)pCtx;
    int type = PMC_PMU_INVALID;
    int msrIdx = 0;
    int debugMsrIdx = 0;
    uint16_t pmcCnt = 0;
    uint16_t debugPmcCnt = 0;
    uint16_t maxPmcCnt = 0;
    uint32_t umcCount = 0;
    uint32_t umcIdx = 0;
    uint32_t umcMsrIdx = 0;
    uint32_t msrCountPerUmc = 0;

    for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
    {
        if (pCoreCtx->m_pPmcConfigGroupArray[type] == NULL)
        {
            continue;
        }

        pmcCnt = GetMaxPmcCount((PmcPmuType)type, &debugPmcCnt);
        maxPmcCnt = pmcCnt + debugPmcCnt;

        /* TODO: For now clear all MSRs, but ideally clear the
         * ones used by config groups? How to track the msrs used
         * with multiple config groups */
        for (msrIdx = 0; msrIdx < maxPmcCnt && type != PMC_PMU_UMC; msrIdx++)
        {
#if defined(__linux__)

            if ((pCoreCtx->m_availabilityMask[type] & (1UL << msrIdx)) == 0)
            {
                continue;
            }

#endif

            if (msrIdx < pmcCnt)
            {
                switch (type)
                {
                    case PMC_PMU_CORE:
                        WriteMSR(CORE_PMC_CFG_MSR(msrIdx), 0);
                        WriteMSR(CORE_PMC_COUNT_MSR(msrIdx), 0);
                        break;

                    case PMC_PMU_L3:
                        WriteMSR(CHL3_PMC_CFG_MSR(msrIdx), 0);
                        WriteMSR(CHL3_PMC_COUNT_MSR(msrIdx), 0);
                        break;

                    case PMC_PMU_DF:
                        WriteMSR(DF_PMC_CFG_MSR(msrIdx), 0);
                        WriteMSR(DF_PMC_COUNT_MSR(msrIdx), 0);
                        break;

                    default:
                        break;
                }
            }
            else if (msrIdx < maxPmcCnt)
            {
                debugMsrIdx = msrIdx - pmcCnt;

                switch (type)
                {
                    case PMC_PMU_CORE:
                        WriteMSR(CORE_PMC_DEBUG_CFG_MSR(debugMsrIdx), 0);
                        WriteMSR(CORE_PMC_DEBUG_COUNT_MSR(debugMsrIdx), 0);
                        break;

                    case PMC_PMU_DF:
                        WriteMSR(DF_PMC_DEBUG_CFG_MSR(debugMsrIdx), 0);
                        WriteMSR(DF_PMC_DEBUG_COUNT_MSR(debugMsrIdx), 0);
                        break;

                    case PMC_PMU_L3:
                    default:
                        break;
                }
            }
            else
            {
                DRVPRINT("Invalid msrdIdx(%d).", msrIdx);
            }
        }

        if (PMC_PMU_UMC == type)
        {
            umcCount = pCoreCtx->m_umcCount;
            msrCountPerUmc = maxPmcCnt;

            for (umcIdx = 0; umcIdx < umcCount; umcIdx++)
            {
                for (umcMsrIdx = 0; umcMsrIdx < msrCountPerUmc; umcMsrIdx++)
                {
                    WriteMSR(UMC_PMC_CFG_MSR((umcMsrIdx + (umcIdx * msrCountPerUmc))), 0);
                    WriteMSR(UMC_PMC_COUNT_MSR((umcMsrIdx + (umcIdx * msrCountPerUmc))), 0);
                }
            }
        }
    }
}

void ResetPmcCounters(CoreContext* pCoreCtx, PmcPmuType type)
{
    int msrIdx = 0;
    int debugMsrIdx = 0;
    uint16_t pmcCnt = 0;
    uint16_t debugPmcCnt = 0;
    uint16_t maxPmcCnt = 0;
    uint16_t pmcConfigCnt = 0;
    PmcConfigGroup* pPmcConfigGroupArray = NULL;
    uint32_t umcIdx = 0;
    uint32_t umcMsrIdx = 0;
    uint32_t msrCountPerUmc = 0;
    uint32_t umcCount = 0;

    pmcCnt = GetMaxPmcCount((PmcPmuType)type, &debugPmcCnt);
    maxPmcCnt = pmcCnt + debugPmcCnt;

    pPmcConfigGroupArray = pCoreCtx->m_pPmcConfigGroupArray[type];
    pmcConfigCnt = pPmcConfigGroupArray->m_pmcConfigCnt;

    for (msrIdx = 0; msrIdx < maxPmcCnt && (pmcConfigCnt != 0) && type != PMC_PMU_UMC; msrIdx++)
    {
        /* Skip if there is no valid control value at msrIdx */
        if (pPmcConfigGroupArray->m_pPmcConfigArray[msrIdx].m_controlValue == 0)
        {
            continue;
        }

        pmcConfigCnt--;

        if (msrIdx < pmcCnt)
        {
            switch (type)
            {
                case PMC_PMU_CORE:
                    WriteMSR(CORE_PMC_COUNT_MSR(msrIdx), 0);
                    break;

                case PMC_PMU_L3:
                    WriteMSR(CHL3_PMC_COUNT_MSR(msrIdx), 0);
                    break;

                case PMC_PMU_DF:
                    WriteMSR(DF_PMC_COUNT_MSR(msrIdx), 0);
                    break;

                default:
                    break;
            }
        }
        else if (msrIdx < maxPmcCnt)
        {
            debugMsrIdx = msrIdx - pmcCnt;

            switch (type)
            {
                case PMC_PMU_CORE:
                    WriteMSR(CORE_PMC_DEBUG_COUNT_MSR(debugMsrIdx), 0);
                    break;

                case PMC_PMU_DF:
                    WriteMSR(DF_PMC_DEBUG_COUNT_MSR(debugMsrIdx), 0);
                    break;

                case PMC_PMU_L3:
                default:
                    break;
            }
        }
        else
        {
            DRVPRINT("Invalid msrdIdx(%d).", msrIdx);
        }
    }

    if (PMC_PMU_UMC == type)
    {
        umcCount = pCoreCtx->m_umcCount;
        msrCountPerUmc = maxPmcCnt;

        for (umcIdx = 0; umcIdx < umcCount; umcIdx++)
        {
            for (umcMsrIdx = 0; umcMsrIdx < msrCountPerUmc; umcMsrIdx++)
            {
                /* Skip if there is no valid control value at msrIdx */
                if (pPmcConfigGroupArray->m_pPmcConfigArray[umcMsrIdx].m_controlValue == 0)
                {
                    continue;
                }

                WriteMSR(UMC_PMC_COUNT_MSR((umcMsrIdx + (umcIdx * msrCountPerUmc))), 0);
            }
        }
    }
}

/*
 * Multiplex pmc configuration group
 */
int MultiplexPmcConfigGroup(CoreContext* pCoreCtx, PmcPmuType type)
{
    int retVal = 0;
    PmcConfigGroup* pCurrentCfgGroup = NULL;
    bool reset = false;
    uint64_t tsc = 0;
    uint64_t delta = 0;
    uint64_t irPerf = 0;
    uint64_t mPerf = 0;
    uint64_t aPerf = 0;

    //DRVPRINT("pCoreCtx(%p)", pCoreCtx);

    if (pCoreCtx == NULL)
    {
        retVal = EINVAL;
    }

    if (!retVal)
    {
        pCurrentCfgGroup = pCoreCtx->m_pPmcConfigGroupArray[type];

        if (pCurrentCfgGroup == NULL)
        {
            retVal = EINVAL;
        }
    }

    if (!retVal)
    {
        /* Timestamp before multiplexing */
        tsc = ReadMSR(PMC_TSC_MSR);

        /* Capture pmc config group delta time */
        if (pCurrentCfgGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_TIMESTAMP)
        {
            pCurrentCfgGroup->m_deltaTime += tsc - pCurrentCfgGroup->m_loadTime;
        }

        if (pCurrentCfgGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_FCLK)
        {
            /* Capture delta fclk */
            pCurrentCfgGroup->m_dfClkDelta +=
                GetDfClk(pCoreCtx->m_coreId) - pCurrentCfgGroup->m_dfClk;
        }

        /* Capture IRPerf delta*/
        if (pCurrentCfgGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_IRPERF)
        {
            irPerf = ReadMSR(PMC_IRPERF_MSR);

            // Check for irPerf rollover
            if (irPerf < pCurrentCfgGroup->m_irPerf)
            {
                delta = PMC_IRPERF_MAX_VALUE - pCurrentCfgGroup->m_irPerf;
                delta += irPerf;
            }
            else
            {
                delta = irPerf - pCurrentCfgGroup->m_irPerf;
            }

            pCurrentCfgGroup->m_irPerfDelta += delta;
        }

        /* Capture MPerf delta*/
        if (pCurrentCfgGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_MPERF)
        {
            mPerf = ReadMSR(PMC_MPERF_MSR);

            // Check for mPerf rollover
            if (mPerf < pCurrentCfgGroup->m_mPerf)
            {
                delta = PMC_MPERF_MAX_VALUE - pCurrentCfgGroup->m_mPerf;
                delta += mPerf;
            }
            else
            {
                delta = mPerf - pCurrentCfgGroup->m_mPerf;
            }

            pCurrentCfgGroup->m_mPerfDelta += delta;
        }

        /* Capture APerf delta*/
        if (pCurrentCfgGroup->m_pmcConfigGroupAttrs & PMC_CONFIG_GROUP_ATTR_APERF)
        {
            aPerf = ReadMSR(PMC_APERF_MSR);

            // Check for aPerf rollover
            if (aPerf < pCurrentCfgGroup->m_aPerf)
            {
                delta = PMC_APERF_MAX_VALUE - pCurrentCfgGroup->m_aPerf;
                delta += aPerf;
            }
            else
            {
                delta = aPerf - pCurrentCfgGroup->m_aPerf;
            }

            pCurrentCfgGroup->m_aPerfDelta += delta;
        }

        /* Reset count if about to log sample. */
        if (pCoreCtx->m_currSamplingCounter[type] == 0)
        {
            pCoreCtx->m_timeEnabled[type] = tsc - pCoreCtx->m_timeEnabledBegin[type];
            reset = true;
        }

        /* Load next config group */
        retVal = LoadPmcConfig(pCurrentCfgGroup->m_pNext, (PmcPmuType)type, pCoreCtx->m_umcCount, reset);

        if (!retVal)
        {
            /* Capture time enabled begin time for upcoming sample */
            if (pCoreCtx->m_currSamplingCounter[type] == 0)
            {
                pCoreCtx->m_timeEnabledBegin[type] = pCurrentCfgGroup->m_pNext->m_loadTime;
            }

            pCoreCtx->m_pPmcConfigGroupArray[type] = pCurrentCfgGroup->m_pNext;
        }
    }

    //DRVPRINT("retVal(%d)", retVal);
    return retVal;
}

/* Write sample for all types */
void PmcFlushDataBuffer(void* pCtx)
{
    CoreContext* pCoreCtx = (CoreContext*)pCtx;
    int type = PMC_PMU_INVALID;

    DRVPRINT("pCoreCtx(%p)", pCoreCtx);

    if (pCoreCtx != NULL)
    {
        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            // TODO: Should this be set unconditionally?
            pCoreCtx->m_currSamplingCounter[type] = 1;
        }

        PmcCallBack(g_pPmcClientContext, pCoreCtx);

#if defined (_WIN32)
        KeSetEvent(&pCoreCtx->m_event, 1, false);
#endif
    }
}

void* PmcGetDataBuffer(PmcDataBufferContext* pCtx, uint64_t recordSize)
{
    char* pBuffer = (char*)pCtx->m_pBuffer;
    uint64_t offset = pCtx->m_offset;
    uint64_t chunkMask = pCtx->m_chunkSize - 1;
    PmcBufferMetaData* pHdr = NULL;
    /* Adjust chunk size */
    uint64_t chunkSize = pCtx->m_chunkSize - sizeof(PmcBufferMetaData);

    /* Record too big to fit in a single chunk */
    if (recordSize > chunkSize)
    {
        return NULL;
    }

    /* Get header for current chunk */
    // TODO: If we remove chunkMask, then chunk size would no
    // longer need be page size multiple.
    pHdr = (PmcBufferMetaData*)(pBuffer + (offset & ~chunkMask));

    if (!pHdr->m_dirty)
    {
        /* Update chunk header */
        pHdr->m_dirty = true;
        pHdr->m_size = recordSize;

        /* Adjust for buffer metadata */
        pBuffer += (offset + sizeof(PmcBufferMetaData));

        /* Calculate new offset */
        offset += pCtx->m_chunkSize;

        if (offset >= pCtx->m_bufferSize)
        {
            offset = 0;
        }

        /* Save new offset */
        pCtx->m_offset = offset;
    }
    else
    {
        // No space available in buffer.
        pBuffer = NULL;
    }

    /* Set notification for data availability */
    pCtx->m_pendingRead = true;

    DRVPRINT("pBuffer(%p) offset(%llu)", pBuffer, offset);

    return (void*)(pBuffer);
}

/* Note: Must be called after all the configurations have
 * been processed */
int AllocateDataBufferContext(ClientContext* pClientCtx)
{
    int retVal = 0;
    CoreContext* pCoreCtx = NULL;
    PmcDataBufferContext* pDataBufferCtx = NULL;
    int type = PMC_PMU_INVALID;
    int coreId = 0;
    int numOfCores = GetCoreCount();

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    for (type = PMC_PMU_CORE; type < PMC_PMU_MAX && !retVal; type++)
    {
        for (coreId = 0; coreId < numOfCores && !retVal; coreId++)
        {
            pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

            if (NULL == pCoreCtx)
            {
                retVal = ENOMEM;
                break;
            }

            /* Skip if there are no valid configs for this type */
            if (pCoreCtx->m_pmcConfigGroupCnt[type] == 0)
            {
                continue;
            }

            pDataBufferCtx = (PmcDataBufferContext*)AllocateMemory(sizeof(PmcDataBufferContext));

            if (pDataBufferCtx == NULL)
            {
                retVal = ENOMEM;
                break;
            }

            pDataBufferCtx->m_coreId = coreId;
            pDataBufferCtx->m_pBuffer = NULL;
            pDataBufferCtx->m_bufferSize = pClientCtx->m_dataBufferSize[type];
            pDataBufferCtx->m_offset = 0;
            pDataBufferCtx->m_chunkSize = pClientCtx->m_dataBufferThreshold[type];
            pDataBufferCtx->m_pendingRead = false;

#if defined(__linux__)
            atomic_set(&pDataBufferCtx->m_pollStatus, 0);
            InitDataBufferWaitQueue(pDataBufferCtx);
            atomic_set(&pDataBufferCtx->m_mmapCount, 0);
#endif

#if defined (_WIN32)
            pDataBufferCtx->m_pClientContext = NULL;
            pDataBufferCtx->m_type = (PmcPmuType)type;
#endif
            pCoreCtx->m_pDataBufferContext[type] = pDataBufferCtx;

            DRVPRINT("type(%s) coreId(%d) pDataBufferCtx(%p)",
                     GetPmcTypeString((PmcPmuType)type), coreId, pDataBufferCtx);
        }
    }

    if (retVal)
    {
        FreeDataBufferContext(pClientCtx);
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

void FreeDataBufferContext(ClientContext* pClientCtx)
{
    int coreId = 0;
    int type = PMC_PMU_INVALID;
    CoreContext* pCoreCtx = NULL;
    int numOfCores = GetCoreCount();

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    /* Get total number of cores */
    for (coreId = 0; coreId < numOfCores; coreId++)
    {
        pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            if (pCoreCtx->m_pDataBufferContext[type] != NULL)
            {
                FreeMemory(pCoreCtx->m_pDataBufferContext[type]);
            }
        }
    }
}

int AddPmcConfigGroup(CoreContext* pCoreCtx,
                      PmcPmuType type,
                      PmcConfigGroup* pPmcConfigGroup)
{
    int retVal = 0;
    PmcConfigGroup* pCurrentGroup = pCoreCtx->m_pPmcConfigGroupArray[type];

    DRVPRINT("pCoreCtx(%p) type(%s) pPmcConfigGroup(%p) pPmcConfigArray(%p)",
             pCoreCtx, GetPmcTypeString(type), pPmcConfigGroup, pPmcConfigGroup->m_pPmcConfigArray);

    if (pCurrentGroup == NULL)
    {
        /* First node will point to itself
         * in a circular linked list */
        pCoreCtx->m_pPmcConfigGroupArray[type] = pPmcConfigGroup;
        pPmcConfigGroup->m_pNext = pPmcConfigGroup;
    }
    else
    {
        pPmcConfigGroup->m_pNext = pCurrentGroup->m_pNext;
        /* Should this be an atomic set? */
        pCurrentGroup->m_pNext = pPmcConfigGroup;
    }

    pCoreCtx->m_pmcConfigGroupCnt[type]++;
    pCoreCtx->m_totalPmcConfigGroupCnt++;

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

uint64_t SetPmcConfigAttrs(uint8_t groupAttrs)
{
    uint8_t pmcConfigGroupAttrs = 0;

    if (groupAttrs & GROUP_ATTR_TIMESTAMP)
    {
        pmcConfigGroupAttrs |= PMC_CONFIG_GROUP_ATTR_TIMESTAMP;
    }

    if (groupAttrs & GROUP_ATTR_IRPERF)
    {
        pmcConfigGroupAttrs |= PMC_CONFIG_GROUP_ATTR_IRPERF;
    }

    if (groupAttrs & GROUP_ATTR_MPERF)
    {
        pmcConfigGroupAttrs |= PMC_CONFIG_GROUP_ATTR_MPERF;
    }

    if (groupAttrs & GROUP_ATTR_APERF)
    {
        pmcConfigGroupAttrs |= PMC_CONFIG_GROUP_ATTR_APERF;
    }

    if (groupAttrs & GROUP_ATTR_FCLK)
    {
        pmcConfigGroupAttrs |= PMC_CONFIG_GROUP_ATTR_FCLK;
    }

    return pmcConfigGroupAttrs;
}

int AllocatePmcConfigGroup(PmcConfigGroup** ppPmcConfigGroup,
                           uint64_t* pPmcConfigArray,
                           uint32_t pmcConfigCount,
                           uint16_t maxPmcCnt,
                           uint16_t groupAttrs,
                           uint64_t groupId,
                           uint32_t availabilityMask,
                           uint32_t umcCount,
                           PmcPmuType type)
{
    int retVal = 0;
    int msrIdx = 0;
    int j = 0;
    PmcConfig* pConfigArray = NULL;
    PmcConfigGroup* pPmcConfigGroup = NULL;
    uint32_t umcMsrCount = 0;
    uint32_t msrCountPerUmc = 0;

    DRVPRINT("pPmcConfigGroup(%p) pPmcConfigArray(%p) "
             "pmcConfigCnt(%u) maxPmcCnt(%u) pmcConfigGroupAttrs(%u) availabilityMask(%x) umcCount(%u)",
             pPmcConfigGroup, pPmcConfigArray, pmcConfigCount,
             maxPmcCnt, groupAttrs, availabilityMask, umcCount);

    pPmcConfigGroup = (PmcConfigGroup*)AllocateMemory(sizeof(PmcConfigGroup));

    if (pPmcConfigGroup == NULL)
    {
        retVal = ENOMEM;
    }

    if (!retVal)
    {
        pPmcConfigGroup->m_pmcConfigCnt = pmcConfigCount;
        pPmcConfigGroup->m_pNext = NULL;
        pPmcConfigGroup->m_loadTime = 0;
        pPmcConfigGroup->m_deltaTime = 0;
        pPmcConfigGroup->m_dfClkDelta = 0;
        pPmcConfigGroup->m_irPerfDelta = 0;
        pPmcConfigGroup->m_mPerfDelta = 0;
        pPmcConfigGroup->m_aPerfDelta = 0;
        pPmcConfigGroup->m_pmcConfigGroupAttrs = SetPmcConfigAttrs(groupAttrs);
        pPmcConfigGroup->m_pmcConfigGroupId = groupId;
        pPmcConfigGroup->m_umcMsrCount = 0;
        pPmcConfigGroup->m_pUmcMsrCountArray = NULL;

        pConfigArray = (PmcConfig*)AllocateMemory(maxPmcCnt * sizeof(PmcConfig));

        if (pConfigArray == NULL)
        {
            retVal = ENOMEM;
        }
    }

    if (!retVal)
    {
        DRVPRINT("pConfigArray(%p) ", pConfigArray);

        memset(pConfigArray, 0, maxPmcCnt * sizeof(PmcConfig));

        for (msrIdx = 0, j = 0; msrIdx < maxPmcCnt && j < pmcConfigCount; msrIdx++)
        {
#if defined(__linux__)

            // Note: Skip availability check for windows
            if ((type != PMC_PMU_UMC) && ((availabilityMask & (1UL << msrIdx)) == 0))
            {
                continue;
            }

#endif

            pConfigArray[msrIdx].m_controlValue = pPmcConfigArray[j];
            pConfigArray[msrIdx].m_counterValue = 0;
            j++;

            DRVPRINT("pConfigArray[%d](%llx) ", msrIdx, pConfigArray[msrIdx].m_controlValue);
        }

        // Set error code if all the configs were not consumned
        // This happens when watchdog takes up a counter on linux
        if (j < pmcConfigCount)
        {
            // TODO: Replace this with appropriate error code
            retVal = EINVAL;
        }

        pPmcConfigGroup->m_pPmcConfigArray = pConfigArray;

        if (PMC_PMU_UMC == type)
        {
            msrCountPerUmc = maxPmcCnt;
            umcMsrCount = umcCount * msrCountPerUmc;
            pPmcConfigGroup->m_umcMsrCount = umcMsrCount;

            pPmcConfigGroup->m_pUmcMsrCountArray = (uint64_t*)AllocateMemory(umcMsrCount * sizeof(uint64_t));

            if (pPmcConfigGroup->m_pUmcMsrCountArray == NULL)
            {
                retVal = ENOMEM;
            }

            if (!retVal)
            {
                memset(pPmcConfigGroup->m_pUmcMsrCountArray, 0, sizeof(uint64_t) * umcMsrCount);
            }
        }
    }

    if (!retVal)
    {
        *ppPmcConfigGroup = pPmcConfigGroup;
    }

    if (retVal)
    {
        if (pPmcConfigGroup != NULL)
        {
            if (pPmcConfigGroup->m_pPmcConfigArray != NULL)
            {
                FreeMemory(pPmcConfigGroup->m_pPmcConfigArray);
                pPmcConfigGroup->m_pPmcConfigArray = NULL;
            }

            if (pPmcConfigGroup->m_pUmcMsrCountArray != NULL)
            {
                FreeMemory(pPmcConfigGroup->m_pUmcMsrCountArray);
                pPmcConfigGroup->m_pUmcMsrCountArray = NULL;
            }

            FreeMemory(pPmcConfigGroup);
            pPmcConfigGroup = NULL;
        }
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

void FreePmcConfigGroup(ClientContext* pClientCtx)
{
    int coreId = 0;
    CoreContext* pCoreCtx = NULL;
    PmcConfigGroup* pPmcCfgGroup = NULL;
    int type = PMC_PMU_INVALID;
    int numOfCores = GetCoreCount();

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    if (pClientCtx != NULL)
    {
        for (coreId = 0; coreId < numOfCores; coreId++)
        {
            if (pCoreCtx != NULL)
            {
                for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
                {
                    pPmcCfgGroup = pCoreCtx->m_pPmcConfigGroupArray[type];

                    if (pPmcCfgGroup != NULL)
                    {
                        if (pPmcCfgGroup->m_pUmcMsrCountArray != NULL)
                        {
                            FreeMemory(pPmcCfgGroup->m_pUmcMsrCountArray);
                            pPmcCfgGroup->m_pUmcMsrCountArray = NULL;
                        }

                        if (pPmcCfgGroup->m_pPmcConfigArray != NULL)
                        {
                            FreeMemory(pPmcCfgGroup->m_pPmcConfigArray);
                            pPmcCfgGroup->m_pPmcConfigArray = NULL;
                        }

                        FreeMemory(pPmcCfgGroup);
                        pCoreCtx->m_pPmcConfigGroupArray[type] = NULL;
                    }
                }
            }
        }
    }
}

/* Initialize sampling counters for all configured cores. */
static void InitSamplingCounter(ClientContext* pClientCtx)
{
    int type = PMC_PMU_INVALID;
    int coreId = 0;
    CoreContext* pCoreCtx = NULL;
    uint32_t numOfCores = GetCoreCount();

    DRVPRINT("pClientCtx(%p) numOfCores(%d)", pClientCtx, numOfCores);

    for (coreId = 0; coreId < numOfCores; coreId++)
    {
        pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            /* Is this part of any core masks? */
            pCoreCtx->m_currSamplingCounter[type] =
                pClientCtx->m_samplingCount[type];
        }
    }
}

// Allocate and initialize core context
int AllocateCoreContext(ClientContext* pClientCtx)
{
    bool retVal = 0;
    int i = 0;
    CoreContext* pCoreCtxArray = NULL;
    int numOfCores = GetCoreCount();
    int type = PMC_PMU_INVALID;

    DRVPRINT("pClientCtx(%p) numOfCores(%d)", pClientCtx, numOfCores);

    /* Note: Allocate memory for all available cores
     * even if not included in core mask */
    pCoreCtxArray = (CoreContext*)AllocateMemory(numOfCores * sizeof(CoreContext));

    if (pCoreCtxArray == NULL)
    {
        retVal = ENOMEM;
    }

    if (!retVal)
    {
        for (i = 0; i < numOfCores; i++)
        {
            pCoreCtxArray[i].m_coreId = i;
            pCoreCtxArray[i].m_socketId = 0;
            pCoreCtxArray[i].m_pTimerConfig = NULL;

            for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
            {
                pCoreCtxArray[i].m_pPmcConfigGroupArray[type] = NULL;
                pCoreCtxArray[i].m_pDataBufferContext[type] = NULL;
                pCoreCtxArray[i].m_currSamplingCounter[type] = 0;
                pCoreCtxArray[i].m_pmcConfigGroupCnt[type] = 0;
                pCoreCtxArray[i].m_timeEnabled[type] = 0;
                pCoreCtxArray[i].m_timeEnabledBegin[type] = 0;
                pCoreCtxArray[i].m_droppedSampleCount[type] = 0;
                pCoreCtxArray[i].m_availabilityMask[type] = 0;
            }

            pCoreCtxArray[i].m_umcSampleRecordSize = 0;
            pCoreCtxArray[i].m_umcCount = 0;
            pCoreCtxArray[i].m_totalPmcConfigGroupCnt = 0;
        }

        pClientCtx->m_pCoreContext = pCoreCtxArray;
    }

    if (retVal)
    {
        FreeCoreContext(pClientCtx);
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

void FreeCoreContext(ClientContext* pClientCtx)
{
    DRVPRINT("pClientCtx(%p)", pClientCtx);

    if (pClientCtx != NULL)
    {
        FreeMemory(pClientCtx->m_pCoreContext);
        pClientCtx = NULL;
    }
}

static void SetSamplingFactor(ClientContext* pClientCtx)
{
    uint64_t timerInterval = pClientCtx->m_timerInterval;
    uint64_t logInterval = pClientCtx->m_logInterval;
    uint16_t configGroupCnt = 0;
    uint64_t samplingFactor = 0;
    int type = PMC_PMU_INVALID;

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    if (pClientCtx != NULL)
    {
        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            configGroupCnt = pClientCtx->m_pmcConfigGroupCnt[type];

            /* Skip if there are no valid configurations for pmc type
             * and prevent divide by zero.*/
            if (configGroupCnt == 0)
            {
                continue;
            }

            /* Sampling Factor =
             * LogInterval / (MuxInterval * Number of Event Groups) */
            samplingFactor = logInterval / timerInterval;
            samplingFactor /= configGroupCnt;

            /* TODO: Should we round up instead of down? But how? */
            /* Cannot be zero */
            if (!samplingFactor)
            {
                samplingFactor++;
            }

            /* If new interval is not equal to log interval */
            if (logInterval != (samplingFactor * timerInterval * configGroupCnt))
            {
                /* TODO: Print log interval changed to xxx for pmc type yyy */
            }

            pClientCtx->m_samplingCount[type] = (uint16_t)samplingFactor * configGroupCnt;

            DRVPRINT("samplingCount[%d](%u)", type, pClientCtx->m_samplingCount[type]);
        }
    }
}

static void SetTimerInterval(ClientContext* pClientCtx)
{
    bool multiplex = false;
    int type = PMC_PMU_INVALID;

    if (pClientCtx != NULL)
    {
        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            if (pClientCtx->m_pmcConfigGroupCnt[type] > 1)
            {
                multiplex = true;
                break;
            }
        }

        if (multiplex)
        {
            pClientCtx->m_timerInterval = pClientCtx->m_muxInterval;
        }
        else
        {
            pClientCtx->m_timerInterval = pClientCtx->m_logInterval;
        }

        SetSamplingFactor(pClientCtx);

        /* Initialize current sampling counter for each core and other
         * initializations */
        InitSamplingCounter(pClientCtx);

        pClientCtx->m_multiplex = multiplex;
    }
}

static int GetCoreMaskArrayCount(uint64_t* pCoreMaskArrary)
{
    int count = 0;
    uint64_t coreMask = 0;
    int i = 0;
    int j = 0;

    for (i = 0; i < PMC_CORE_MASK_ARRAY_SIZE; i++)
    {
        coreMask = pCoreMaskArrary[i];

        for (j = 0; j < PMC_CORE_MASK_BIT_WIDTH; j++)
        {
            if (coreMask & (1ULL << j))
            {
                count++;
            }
        }
    }

    return count;
}

int AllocateUmcMaskArray(ClientContext* pClientCtx)
{
    int retVal = ENOMEM;
    uint32_t* pUmcMaskArray = NULL;
    uint32_t socketCount = GetSocketCount();

    if (NULL != pClientCtx)
    {
        DRVPRINT("pClientCtx(%p)", pClientCtx);

        pUmcMaskArray = (uint32_t*)AllocateMemory(socketCount * sizeof(uint32_t));

        if (pUmcMaskArray != NULL)
        {
            memset(pUmcMaskArray, 0, socketCount * sizeof(uint32_t));
            pClientCtx->m_pUmcMaskArray = pUmcMaskArray;
            retVal = 0;
        }
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

void FreeUmcMaskArray(ClientContext* pClientCtx)
{
    DRVPRINT("pClientCtx(%p)", pClientCtx);

    if (pClientCtx != NULL)
    {
        if (pClientCtx->m_pUmcMaskArray != NULL)
        {
            FreeMemory(pClientCtx->m_pUmcMaskArray);
            pClientCtx->m_pUmcMaskArray = NULL;
            pClientCtx->m_umcMaskArraySize = 0;
        }
    }
}

int AllocateCoreMaskArray(ClientContext* pClientCtx)
{
    int type = PMC_PMU_INVALID;
    int retVal = 0;
    uint64_t* pCoreMask = NULL;

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
    {
        pCoreMask = (uint64_t*)AllocateMemory(PMC_CORE_MASK_ARRAY_SIZE * sizeof(uint64_t));

        if (pCoreMask != NULL)
        {
            memset(pCoreMask, 0 , PMC_CORE_MASK_ARRAY_SIZE * sizeof(uint64_t));
            pClientCtx->m_pPmcCoreMaskArray[type] = pCoreMask;
        }
        else
        {
            DRVPRINT("Failed AllocateMemory");
            retVal = ENOMEM;
            break;
        }
    }

    if (retVal)
    {
        FreeCoreMaskArray(pClientCtx);
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

void FreeCoreMaskArray(ClientContext* pClientCtx)
{
    int type = PMC_PMU_INVALID;

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    if (pClientCtx != NULL)
    {
        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            if (pClientCtx->m_pPmcCoreMaskArray[type] != NULL)
            {
                FreeMemory(pClientCtx->m_pPmcCoreMaskArray[type]);
                pClientCtx->m_pPmcCoreMaskArray[type] = NULL;
            }
        }
    }
}

/* Process configuration */
int ProcessCountModeProfileConfig(ClientContext* pClientCtx,
                                  CountModeProfileConfig* pConfig)
{

    int retVal = 0;
    int type = PMC_PMU_INVALID;
    uint32_t grpIdx = 0;
    uint16_t coreId = 0;
    uint64_t coreMask = 0;
    GroupType groupType = GROUP_TYPE_INVALID;
    uint16_t groupConfigCnt = 0;
    uint16_t maxPmcCnt = 0;
    uint16_t groupAttrs = 0;
    uint64_t groupId = 0;
    uint32_t numOfConfigGroups = 0;
    bool enableIRPerf = false;
    int numOfCores = GetCoreCount();
    uint16_t debugPmcCnt = 0;
    uint32_t socketId = 0;
    uint32_t umcCount = 0;
    uint64_t* pCoreMaskArray = NULL;
    CoreContext* pCoreCtx = NULL;
    uint64_t* pPmcConfigArray = NULL;
    CountModeGroupConfig* pGroupConfig = NULL;
    PTARGET_SYSTEM_INFO pTargetSystemInfo = NULL;
    PmcConfigGroup* pPmcConfigGroup = NULL;


    DRVPRINT("pClientCtx(%p) pConfig(%p)", pClientCtx, pConfig);

    GetTargetSystemInfo(&pTargetSystemInfo);

    if (pClientCtx == NULL || pConfig == NULL || pTargetSystemInfo == NULL)
    {
        DRVPRINT("pClientCtx == NULL || pConfig == NULL || pTargetSystemInfo == NULL");
        retVal = EINVAL;
    }

    if (!retVal)
    {
        /* Allocate space for Core mask array */
        retVal = AllocateCoreMaskArray(pClientCtx);
    }
    else
    {
        DRVPRINT("FAILED: AllocateCoreMaskArray failed\n");
    }

    if (!retVal)
    {
        /* Save a copy of core mask */
        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            pCoreMaskArray = GetCoreMaskArray(pConfig, (PmcPmuType)type);

            if (NULL != pCoreMaskArray)
            {
                memcpy(pClientCtx->m_pPmcCoreMaskArray[type],
                       pCoreMaskArray,
                       PMC_CORE_MASK_ARRAY_SIZE * sizeof(uint64_t));
            }
            else
            {
                DRVPRINT("Failed to get GetCoreMaskArray for PMU type %d\n", type);
                retVal = EINVAL;
            }
        }

        if (!retVal)
        {
            /* Set default mux interval if not provided */
            pClientCtx->m_muxInterval = (pConfig->m_muxInterval) ?
                                        pConfig->m_muxInterval : MUX_INTERVAL_DEFAULT;

            /* Save log interval, set to default if not provided */
            pClientCtx->m_logInterval = (pConfig->m_logInterval) ?
                                        pConfig->m_logInterval : LOG_INTERVAL_DEFAULT;

            retVal = AllocateUmcMaskArray(pClientCtx);

            if (retVal)
            {
                DRVPRINT("FAILED: AllocateUmcMaskArray failed\n");
            }
        }
    }

    if (!retVal)
    {
        /* Save umc mask provided by the user */
        memcpy(pClientCtx->m_pUmcMaskArray, pConfig->m_umcMask, PMC_MAX_SOCKET_COUNT * sizeof(uint32_t));

        pClientCtx->m_umcMaskArraySize = pTargetSystemInfo->m_socketCount;
        memcpy(pClientCtx->m_firstCore, pTargetSystemInfo->m_zen.m_firstCore, PMC_MAX_SOCKET_COUNT * sizeof(uint32_t));

        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            /* Save data buffer size and threshold */
            pClientCtx->m_dataBufferSize[type] = pConfig->m_dataBufferSize[type];
            pClientCtx->m_dataBufferThreshold[type] = pConfig->m_dataBufferThreshold[type];
            pClientCtx->m_bufferMaxFillCount[type] = GetCoreMaskArrayCount(pClientCtx->m_pPmcCoreMaskArray[type]);
        }

        /* TODO: Should we do this on client registration for each client
         * instead of doing it here? */
        retVal = AllocateCoreContext(pClientCtx);

        if (retVal)
        {
            DRVPRINT("FAILED: AllocateCoreContext\n");
        }
    }

    if (!retVal)
    {
        numOfConfigGroups = pConfig->m_configArraySize / sizeof(CountModeGroupConfig);
    }

#if defined(__linux__)

    if (!retVal)
    {
        // Get availability mask for each core with valid core mask
        for (coreId = 0; coreId < numOfCores; coreId++)
        {
            if (!cpu_online(coreId))
            {
                continue;
            }

            pCoreCtx = &pClientCtx->m_pCoreContext[coreId];
            ExecuteOnCore(coreId, (void*)GetPmcAvailabilityMask, (void*)pCoreCtx);
        }
    }

#endif

    /* Process each config group */
    for (grpIdx = 0; grpIdx < numOfConfigGroups && !retVal; grpIdx++)
    {
        uint32_t maskIdx = 0;

        pGroupConfig = (CountModeGroupConfig*)pConfig->m_pConfigArray + grpIdx;

        groupType = (GroupType)pGroupConfig->m_configHeader.m_header.m_groupType;
        groupConfigCnt = pGroupConfig->m_configHeader.m_header.m_groupConfigCount;
        groupAttrs = pGroupConfig->m_configHeader.m_header.m_groupAttributes;
        groupId = pGroupConfig->m_configHeader.m_header.m_groupId;

        if (groupAttrs & GROUP_ATTR_IRPERF && !enableIRPerf)
        {
            enableIRPerf = true;
        }

        type = GetPmcType(groupType);

        /* End of valid configurations */
        if (groupType == GROUP_TYPE_INVALID)
        {
            break;
        }

        pCoreMaskArray = pClientCtx->m_pPmcCoreMaskArray[type];
        pPmcConfigArray = GetPmcConfigArray(pGroupConfig);

        if ((NULL != pCoreMaskArray) && (NULL != pPmcConfigArray))
        {
            maxPmcCnt = (uint16_t)GetMaxPmcCount((PmcPmuType)type, &debugPmcCnt);

            pClientCtx->m_pmcConfigGroupCnt[type]++;

            for (maskIdx = 0, coreId = 0; maskIdx < PMC_CORE_MASK_ARRAY_SIZE && !retVal; maskIdx++)
            {
                uint32_t bit = 0;
                coreMask = pCoreMaskArray[maskIdx];

                for (bit = 0; bit < PMC_CORE_MASK_BIT_WIDTH && !retVal; bit++, coreId++)
                {
                    pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

                    if (coreMask & (1ULL << bit))
                    {
                        if (PMC_PMU_UMC == type)
                        {
                            socketId = GetSocketIdForCore(coreId);

                            /* Throw an error if socket Id exceeds array size
                             * Will happen in case of incorrect topology deduction */
                            if (socketId < pClientCtx->m_umcMaskArraySize)
                            {
                                umcCount = POPCNT(pClientCtx->m_pUmcMaskArray[socketId]);
                            }
                            else
                            {
                                DRVPRINT("FAILED: pClientCtx->m_umcMaskArraySize(%d) <= socketId(%d)\n", pClientCtx->m_umcMaskArraySize, socketId);
                                retVal = EINVAL;
                            }
                        }

                        if (!retVal)
                        {
                            pPmcConfigGroup = NULL;

                            retVal = AllocatePmcConfigGroup(&pPmcConfigGroup,
                                                            pPmcConfigArray,
                                                            groupConfigCnt,
                                                            maxPmcCnt,
                                                            groupAttrs,
                                                            groupId,
                                                            pCoreCtx->m_availabilityMask[type],
                                                            umcCount,
                                                            (PmcPmuType)type);
                        }

                        if (retVal || (NULL == pPmcConfigGroup))
                        {
                            DRVPRINT("FAILED: AllocatePmcConfigGroup\n");
                            retVal = EINVAL;
                            break;
                        }

                        retVal = AddPmcConfigGroup(pCoreCtx,
                                                   (PmcPmuType)type,
                                                   pPmcConfigGroup);

                        if (retVal)
                        {
                            DRVPRINT("FAILED: AddPmcConfigGroup\n");
                        }

                        /* TODO: Free already allocated memory and
                         * return appropriate error code */

                        /* TODO: Should we load Pmc Config once we have added it?
                         * To avoid waiting for all Pmc configs to be added before we start
                         * monitoring. But we need timer to be configured in order to
                         * collect sample data. Time configuration requires sampling
                         * factor determination which in turn requires a config group cnt
                         * for each pmc type. Circular dependency. Can be avoided if
                         * total pmc config group count is provided by backend */
                    }
                }
            }

            pClientCtx->m_totalPmcAttrCnt[type] += (uint16_t)GetGroupAttrCount((uint8_t)groupAttrs);
            pClientCtx->m_totalPmcConfigCnt[type] += groupConfigCnt;
        }
        else
        {
            DRVPRINT("Invalid pointer pCoreMaskArray or pPmcConfigArray");
            retVal = EINVAL;
        }
    }

    if (!retVal)
    {
        if (enableIRPerf)
        {
            if (!EnableIRPerf(pTargetSystemInfo))
            {
                DRVPRINT("Failed: EnableIRPerf");
                retVal = EPERM;
            }
        }

        /* Calculate size of sample record
         * Note: Must be called after adding Pmc Configurations */
        SetSampleRecordSize(pClientCtx);

        retVal = AllocateDataBufferContext(pClientCtx);
    }

#if defined(__linux__)

    if (!retVal)
    {
        /* File descriptors to be returned as output */
        /* TODO: This is Linux specific.*/
        retVal = CreatePmcFileDescriptors(pConfig, pClientCtx);
    }

#endif

    if (!retVal)
    {
        /* Note: Requires pmc config group count for each pmc type and
         * hence can only be set once config groups have been added. */
        SetTimerInterval(pClientCtx);

        /* Setup timer */
        retVal = PmcSetupTimer(pClientCtx);

        /* TODO: Load first PMC config groups for all cores?
         * or shoud it be done before starting the timer */
    }
    else
    {
        FreeDataBufferContext(pClientCtx);
        FreePmcConfigGroup(pClientCtx);
        FreeCoreContext(pClientCtx);
        FreeUmcMaskArray(pClientCtx);
        FreeCoreMaskArray(pClientCtx);
    }

    DRVPRINT("retVal(%d)", retVal);

    return retVal;
}

int AllocateClientContext(uint32_t clientId)
{

    int type = PMC_PMU_INVALID;
    int retVal = ENOMEM;
    ClientContext* pClientContext = NULL;

    DRVPRINT("clientId(%lu)", (unsigned long int)clientId);

    pClientContext = (ClientContext*)AllocateMemory((sizeof(ClientContext)));

    if (pClientContext != NULL)
    {
        pClientContext->m_clientId = clientId;

        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX; type++)
        {
            pClientContext->m_pPmcCoreMaskArray[type] = NULL;
            pClientContext->m_sampleRecordSize[type] = 0;
            pClientContext->m_totalPmcConfigCnt[type] = 0;
            pClientContext->m_totalPmcAttrCnt[type] = 0;
            pClientContext->m_pmcConfigGroupCnt[type] = 0;
            pClientContext->m_samplingCount[type] = 0;
            pClientContext->m_dataBufferSize[type] = 0;
            pClientContext->m_dataBufferThreshold[type] = 0;
            pClientContext->m_bufferFillCount[type] = 0;
            pClientContext->m_bufferMaxFillCount[type] = 0;
        }

        pClientContext->m_muxInterval = 0;
        pClientContext->m_logInterval = 0;
        pClientContext->m_timerInterval = 0;
        pClientContext->m_pCoreContext = NULL;
        pClientContext->m_multiplex = false;
        pClientContext->m_pUmcMaskArray = NULL;
        pClientContext->m_umcMaskArraySize = 0;

#if defined(_WIN32)
        pClientContext->m_pDevExt = NULL;
#endif
        /* Save reference to client context */
        g_pPmcClientContext = pClientContext;
        retVal = 0;
    }

    DRVPRINT("pClientCtx(%p) retVal(%d)", g_pPmcClientContext, retVal);

    return retVal;
}

void FreeClientContext(uint32_t clientId)
{
    DRVPRINT("clientId(%lu)", (unsigned long int)clientId);

    if (g_pPmcClientContext != NULL)
    {
        if (g_pPmcClientContext->m_clientId == clientId)
        {
            FreeMemory(g_pPmcClientContext);
            g_pPmcClientContext = NULL;
        }
    }

    DRVPRINT("pClientCtx(%p)", g_pPmcClientContext);
}

#if defined (_WIN32)
typedef struct
{
    PmcPmuType m_type;
    PmcConfigGroup* m_pConfigGroup;
    uint32_t m_umcCount;
    KEVENT m_event;
} DpcLoadConfig;

void _LoadPmcConfig(void* pContext)
{
    DpcLoadConfig* pCtx = (DpcLoadConfig*)pContext;

    if (pCtx != NULL)
    {
        LoadPmcConfig(pCtx->m_pConfigGroup, pCtx->m_type, pCtx->m_umcCount, false);

        KeSetEvent(&pCtx->m_event, 1, FALSE);
    }
}
#endif

/* TODO: This is linux specific since the type of
 * this function will be same as smp_call_func_t */
static void _PmcStartProfiler(void* pInfo)
{
    CoreContext* pCoreCtx = (CoreContext*)pInfo;
    int type = PMC_PMU_INVALID;
    int retVal = 0;
#if defined (_WIN32)
    DpcLoadConfig dpcCtx;

    KeInitializeEvent(&dpcCtx.m_event, SynchronizationEvent, false);
#endif

    DRVPRINT("pCoreCtx(%p)", pCoreCtx);

    if (pCoreCtx != NULL)
    {
        // Load PMC config core
        for (type = PMC_PMU_CORE; type < PMC_PMU_MAX && !retVal; type++)
        {
            // If there is a valid PMC config group for this type
            if (pCoreCtx->m_pPmcConfigGroupArray[type] != NULL)
            {
#if defined (_WIN32)
                dpcCtx.m_pConfigGroup = pCoreCtx->m_pPmcConfigGroupArray[type];
                dpcCtx.m_type = (PmcPmuType)type;
                dpcCtx.m_umcCount = pCoreCtx->m_umcCount;

                DeferedCoreExecution(pCoreCtx->m_coreId, (void*)_LoadPmcConfig, (void*)&dpcCtx);
#else
                retVal = LoadPmcConfig(pCoreCtx->m_pPmcConfigGroupArray[type],
                                       (PmcPmuType)type, pCoreCtx->m_umcCount, false);

#endif
                /* Capture time enabled */
                pCoreCtx->m_timeEnabledBegin[type] = pCoreCtx->m_pPmcConfigGroupArray[type]->m_loadTime;

                if (retVal)
                {
                    DRVPRINT("Error loading pmc config group. pPmcConfigGroup(%p) type(%d)",
                             pCoreCtx->m_pPmcConfigGroupArray[type], type);
                }

#if defined (_WIN32)
                KeWaitForSingleObject((void*)&dpcCtx.m_event, Executive, KernelMode, false, NULL);
#endif
            }
        }

        // Start timer for this core
        // Note: On windows this registers a DPC
        PmcStartTimerOnCore(pCoreCtx);
    }
}

// This function needs to block until timer starts
/* Load configurations for all cores and start timer */
int PmcStartProfiler()
{
    int retVal = 0;
    int coreId = 0;
    int numOfCores = GetCoreCount();
    CoreContext* pCoreCtx = NULL;

    DRVPRINT("pClientCtx(%p)", g_pPmcClientContext);

    /* TODO: Check profiler state to confirm
     * if profiler has already been configured. */
    if (g_pPmcClientContext == NULL)
    {
        retVal = EINVAL;
    }

    for (coreId = 0; coreId < numOfCores && !retVal; coreId++)
    {
        if (g_pPmcClientContext->m_pCoreContext != NULL)
        {
            pCoreCtx = &g_pPmcClientContext->m_pCoreContext[coreId];

            /* If the core has atleast one valid PMC config group */
            if (pCoreCtx != NULL && pCoreCtx->m_totalPmcConfigGroupCnt)
            {
#if defined (__linux__)
                retVal = ExecuteOnCore(coreId, (void*)_PmcStartProfiler,
                                       (void*)pCoreCtx);
#endif

#if defined (_WIN32)
                _PmcStartProfiler(pCoreCtx);
#endif
            }
        }
    }

    DRVPRINT("retval(%d)", retVal);

    return retVal;
}

/* TODO: This is linux specific since the type of
 * this function will be same as smp_call_func_t */
static void _PmcStopProfiler(void* pInfo)
{
    CoreContext* pCoreCtx = (CoreContext*)pInfo;

    if (pCoreCtx != NULL)
    {
        /* Stop Timer */
        PmcStopTimerOnCore(pCoreCtx);
    }
}

int PmcStopProfiler()
{
    int retVal = 0;
    int coreId = 0;
    int numOfCores = GetCoreCount();
    CoreContext* pCoreCtx = NULL;
    ClientContext* pClientCtx = g_pPmcClientContext;

    DRVPRINT("pClientCtx(%p)", pClientCtx);

    if (pClientCtx == NULL || pClientCtx->m_pCoreContext == NULL)
    {
        retVal = EINVAL;
    }

    // Stop timers on all cores
    for (coreId = 0; coreId < numOfCores && !retVal; coreId++)
    {
        pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

        if (pCoreCtx != NULL && pCoreCtx->m_totalPmcConfigGroupCnt)
        {
#if defined(__linux__)
            retVal = ExecuteOnCore(coreId, (void*)_PmcStopProfiler,
                                   (void*)pCoreCtx);
#endif

#if defined (_WIN32)
            // Note: Ideally, we should wait for the timers to stop
            // on windows but unfortunately Pcore doesn't have
            // a blocking version of PcoreRemoveConfiguration
            PmcStopTimerOnCore(pCoreCtx);
#endif
        }
    }

    /* Flush data buffers */
    for (coreId = 0; coreId < numOfCores && !retVal; coreId++)
    {
        pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

        // Skip if there are no valid configs for this core
        if (pCoreCtx == NULL || pCoreCtx->m_totalPmcConfigGroupCnt == 0)
        {
            continue;
        }

#if defined (_WIN32)
        KeInitializeEvent(&pCoreCtx->m_event, SynchronizationEvent, false);
#endif
        /* Flush data buffer */
        ExecuteOnCore(coreId, (void*)PmcFlushDataBuffer, (void*)pCoreCtx);

#if defined (_WIN32)
        KeWaitForSingleObject((void*)&pCoreCtx->m_event, Executive, KernelMode, false, NULL);
#endif
    }

    /* Clear config on occupied cores */
    for (coreId = 0; coreId < numOfCores && !retVal; coreId++)
    {
        pCoreCtx = &pClientCtx->m_pCoreContext[coreId];

        // Skip if there are no valid configs for this core
        if (pCoreCtx == NULL || pCoreCtx->m_totalPmcConfigGroupCnt == 0)
        {
            continue;
        }

        ExecuteOnCore(coreId, (void*)ClearPmcConfig, (void*)pCoreCtx);
    }

    PmcDestroyTimer(pClientCtx);

    DRVPRINT("retval(%d)", retVal);

    return retVal;
}

void PmcClearProfiler()
{
    /* Free Configurations */
    FreePmcConfigGroup(g_pPmcClientContext);
    FreeCoreMaskArray(g_pPmcClientContext);
    FreeUmcMaskArray(g_pPmcClientContext);
    FreeDataBufferContext(g_pPmcClientContext);
    FreeCoreContext(g_pPmcClientContext);
}

/* TODO: Disable MSR configs and Stop timer
 * Flush data buffer? */
int PmcPauseProfiler()
{
    /* TODO: Add implementation */
    return 0;
}

/* TODO: Enable MSR configs and stop timer */
int PmcResumeProfiler()
{
    /* TODO: Add implementation */
    return 0;
}
