//==================================================================================
// Copyright (c) 2017 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file PwrCommonHelper.c
///
//==================================================================================
#include <PwrDriverTypedefs.h>
#include <PwrOsPrimitives.h>
#include <PwrDriverUtils.h>
#include <PwrCommonDataTypes.h>
#include <PmcInterface.h>

#define RAPL_PWR_UNIT_ADDR 0xC0010299
#define HWCR_REG_ADDR 0xC0010015
#define HWCR_ENABLE_MASK 0x40000000
#define HWCR_DISABLE_MASK 0xBFFFFFFF
#define PWR_INVALID_PLATFORM 0xFFFFFFFF

static bool g_perfEnable = false;
static uint32 g_platformId = PLATFORM_INVALID;
static PTARGET_SYSTEM_INFO g_pSystemInfo = NULL;
static TARGET_SYSTEM_INFO g_systemInfo;

#define CPUID_FnProcessorVendorAndLargestStdFuncNum 0x0
#define CPUID_FnBasicFeatures 0x00000001
#define CPUID_HypervisorMask 0x80000000
#define CPUID_FnExtendedTopology 0x0000000B
#define CPUID_FnAdvancePowerManagementInfo 0x80000007
#define CPUID_FnFeatureRapl (1 << 14)
#define CPUID_FnCacheProperties 0x8000001D

// PwrIsAmdPlatform
static bool PwrIsAMDPlatform(void)
{
    char vendorId[20];
    bool result = false;
    uint32 data = PwrReadCpuId(PWR_EBX_OFFSET, 0);
    memcpy(vendorId, &data, 4);
    data = PwrReadCpuId(PWR_EDX_OFFSET, 0);
    memcpy(vendorId + 4, &data, 4);
    data = PwrReadCpuId(PWR_ECX_OFFSET, 0);
    memcpy(vendorId + 8, &data, 4);
    vendorId[12] = '\0';

    if (0 == strcmp(vendorId, "AuthenticAMD"))
    {
        result = true;
    }

    return result;
}

// PwrIsRAPLAvailable: Check is RAPL counters are available
// Available only on family17
bool PwrIsRAPLAvailable()
{
    bool result = false;
    uint32 data = PwrReadCpuId(PWR_EDX_OFFSET, CPUID_FnAdvancePowerManagementInfo);
    result = (data & CPUID_FnFeatureRapl) != 0;
    return result;
}

// PwrIsHyperVisor: check if hypervisor is enabled
bool PwrIsHyperVisor()
{
    bool result = false;
    uint32 data = PwrReadCpuId(PWR_ECX_OFFSET, CPUID_FnBasicFeatures);
    result = (0 != (data & CPUID_HypervisorMask));
    return result;
}

// PwrIsIGPUAvailable: Check if iGPU is available with B0D1F0x18 register
// refer to the BKDG for this register. Available only in family 15 & 16
bool PwrIsIGPUAvailable()
{
    uint32 data = ReadPCIDev(0x0U, 0x1U, 0x0U, 0x18U);
    return (data < PWR_INVALID_PLATFORM ? true : false);
}

// GetTargetPlatformId: Get platform id
uint32 PwrGetTargetPlatformId(void)
{
    uint32 family = 0;
    uint32 model = 0;

    if (PLATFORM_INVALID == g_platformId)
    {
        GetCpuModelFamily(&family, &model);

        if ((0x15 == family) && (model >= 0x30 && model <= 0x3F))
        {
            // Kaveri : 0x15 30 to 3F
            g_platformId = PLATFORM_KAVERI;
        }
        else if ((0x15 == family) && (model >= 0x60 && model <= 0x6F))
        {
            // Carrizo: 0x15 60 to 6F
            g_platformId  = PLATFORM_CARRIZO;
        }
        else if ((0x15 == family) && (model >= 0x70 && model <= 0x7F))
        {
            // Carrizo: 0x15 70 to 7F
            g_platformId  = PLATFORM_STONEY;
        }
        else if ((0x16 == family) && (model >= 0x30 && model <= 0x3F))
        {
            // Mullins : 0x16 30 to 3F
            g_platformId = PLATFORM_MULLINS;
        }
        else if (0x17 > family)
        {
            g_platformId = PLATFORM_INVALID;
        }
    }

    return g_platformId;
}

// PwrEnablePerf: Enable perf bit
void PwrEnablePerf(bool enable)
{
    if (g_systemInfo.m_isZen)
    {
        uint64 data;
        data = ReadMSR(HWCR_REG_ADDR);

        if (true == enable)
        {
            if (!(data & HWCR_ENABLE_MASK))
            {
                data |= HWCR_ENABLE_MASK;
                WriteMSR(HWCR_REG_ADDR, data);
                g_perfEnable = true;
            }
        }
        else
        {
            if (g_perfEnable)
            {
                data = data & HWCR_DISABLE_MASK;
                WriteMSR(HWCR_REG_ADDR, data);
                g_perfEnable = false;
            }
        }
    }
}

// PwrGetSocketType: Get socket type
uint32 PwrGetSocketType(void)
{
    uint32 brandId = 0;

    if (g_systemInfo.m_isZen)
    {
        uint32 ebxOffset = PwrReadCpuId(PWR_EBX_OFFSET, CPUID_FnBrandIdIdentifier);
        brandId = ebxOffset >> 28;
    }

    return brandId;
}

// GetThreadsPerCore : Return number of threads per core
static uint32 GetThreadsPerCore(void)
{
    uint32 threadsPerCore = 0;

    if (g_systemInfo.m_isZen)
    {
        uint32 ebxOffset = PwrReadCpuId(PWR_EBX_OFFSET, CPUID_FnIdentifiers);
        threadsPerCore = ((ebxOffset >> 8) & 0xFF) + 1;
    }

    DRVPRINT("Threads per core :%d\n", threadsPerCore);
    return threadsPerCore;
}

// GetThreadsPerSocket : Get Threads per socket
static uint32 GetThreadsPerSocket(void)
{
    uint32 threadsPerSocket = 0;

#if defined(_WIN64)
    // On Windows VM, CPUId returns incorrect socket count (1 socket for each core)
    // Assume single socket for windows VMs
    if (g_systemInfo.m_isGuest)
    {
        return GetTargetCoreCount();
    }
#endif

    if (g_systemInfo.m_isZen)
    {
        uint32 ecxOffset = PwrReadCpuId(PWR_ECX_OFFSET, CPUID_FnSizeID);
        threadsPerSocket = (ecxOffset & 0xFF) + 1;
    }

    DRVPRINT("Threads per socket :%d\n", threadsPerSocket);
    return threadsPerSocket;
}

// GetNumberOfSockets : Get number of sockets per system
static uint32 GetNumberOfSockets(void)
{
    uint32 socketCnt = 0;

    if (g_systemInfo.m_isZen)
    {
        uint32 tgtThreadCount = GetTargetCoreCount();
        uint32 threadsPerSocket = GetThreadsPerSocket();

        socketCnt = tgtThreadCount / threadsPerSocket;

        if (socketCnt > PWR_MAX_SOCKET_COUNT)
        {
            socketCnt = PWR_MAX_SOCKET_COUNT;
        }
    }

    DRVPRINT("Socket Cnt : %d \n", socketCnt);
    return socketCnt;
}

// GetPhyCoresPerSocket : Get cores per socket
static uint32 GetPhyCoresPerSocket(void)
{
    DRVPRINT("GetPhyCoresPerSocket : %d \n", GetThreadsPerSocket() / GetThreadsPerCore());
    return GetThreadsPerSocket() / GetThreadsPerCore();
}

// GetTargetPhyCoreCnt : Get physical core count
static uint32 GetTargetPhyCoreCnt(void)
{
    DRVPRINT("GetTargetPhyCoreCnt : %d \n", GetTargetCoreCount() / GetThreadsPerCore());
    return GetPhyCoresPerSocket() * GetNumberOfSockets();
}

// GetEnergyUnit
uint32 GetEnergyUnit(void)
{
    uint64 data = 0;
    uint32 result = 0;

    if (PwrIsRAPLAvailable())
    {
        data = ReadMSR(RAPL_PWR_UNIT_ADDR);
        result = (uint8)((data & 0x1F00) >> 8) ? (uint8)((data & 0x1F00) >> 8) : 0x10;
    }

    return result;
}

//GetZenSystemInfo()
static void GetZenSystemInfo(void)
{
    uint32 cnt = 0;
    uint32 socketId = 0;
    bool isEpyc = false;
    bool isZen2 = false;
    bool isZen3 = false;
    bool isZen4AndAbove = false;
    uint32 maskWidth = 0;
    int32 aCPUInfo[PWR_NUM_CPUID_OFFSETS] = { -1 };
    uint32 coresPerCcx = 0;
    uint32 threadsPerCcx = 0;
    uint32 ccxPerSocket = 0;
    bool isExtTopoAvailable = false;

    // By default first core of socke 0 is core 0
    g_systemInfo.m_zen.m_firstCore[0] = 0UL;

    for (cnt = 1; cnt < PWR_MAX_SOCKET_COUNT; cnt++)
    {
        g_systemInfo.m_zen.m_firstCore[cnt] = 0xFFFFFFFFUL;
    }

    g_systemInfo.m_zen.m_energyUnit = GetEnergyUnit();
    g_systemInfo.m_zen.m_totalThreads = GetTargetCoreCount();
    g_systemInfo.m_zen.m_isSmtEnabled = PwrIsSmtEnabled();

    PwrSetExtendedApicId(&g_systemInfo);

    g_systemInfo.m_zen.m_threadsPerSocket              = GetThreadsPerSocket();
    g_systemInfo.m_socketCount                         = GetNumberOfSockets();
    g_systemInfo.m_zen.m_totalPhysicalCores            = GetTargetPhyCoreCnt();
    g_systemInfo.m_zen.m_physicalCoresPerSocket        = GetPhyCoresPerSocket();
    g_systemInfo.m_zen.m_isRaplAvailable               = PwrIsRAPLAvailable();

    isEpyc = (g_systemInfo.m_family == 0x17) && (g_systemInfo.m_model <= 0x2f);

    if (!isEpyc && g_systemInfo.m_family == 0x17)
    {
        isZen2 = ((0x30 <= g_systemInfo.m_model) && (g_systemInfo.m_model <= 0x3f))
                 || ((0x60 <= g_systemInfo.m_model) && (g_systemInfo.m_model <= 0x7f));
    }

    if (!isEpyc && ! isZen2 && (0x19 == g_systemInfo.m_family))
    {
        isZen3 = (g_systemInfo.m_model <= 0xf)
                 || ((0x20 <= g_systemInfo.m_model) && (g_systemInfo.m_model <= 0x5f));
    }

    if (!isEpyc && (0x19 <= g_systemInfo.m_family))
    {
        isZen4AndAbove = (0x19 == g_systemInfo.m_family &&
                          ((g_systemInfo.m_model >= 0x10 && g_systemInfo.m_model <= 0x1f) ||
                           (g_systemInfo.m_model >= 0x60 && g_systemInfo.m_model <= 0x6f))) ||
                         (g_systemInfo.m_family > 0x19);
    }

    g_systemInfo.m_zen.m_isZen2 = isZen2;
    g_systemInfo.m_zen.m_isZen3 = isZen3;
    g_systemInfo.m_zen.m_isZen4AndAbove = isZen4AndAbove;

    if (isZen2 || isZen3 || isZen4AndAbove)
    {
        ReadCPUIDEx(aCPUInfo, CPUID_FnExtendedTopology, 0);

        isExtTopoAvailable = aCPUInfo[PWR_EBX_OFFSET] != 0;
        DRVPRINT("Is Extended topology available: %d\n", isExtTopoAvailable);

        // Check if extended topology information is available
        if (isExtTopoAvailable)
        {
            // Core Mask Width
            ReadCPUIDEx(aCPUInfo, CPUID_FnExtendedTopology, 1);
            maskWidth = aCPUInfo[PWR_EAX_OFFSET] & 0x1f;
            DRVPRINT("Mask Width %d\n", maskWidth);
        }

    }

    g_systemInfo.m_zen.m_socketMaskWidth = 1;
    g_systemInfo.m_zen.m_socketShiftWidth = isExtTopoAvailable ? maskWidth : 0;
    g_systemInfo.m_zen.m_coreShiftWidth = g_systemInfo.m_zen.m_isSmtEnabled ? 1 : 0;

    if (isZen2)
    {
        // TODO: Will this work for downcored Zen 2?
        g_systemInfo.m_zen.m_coreMaskWidth = 2;

        g_systemInfo.m_zen.m_ccxMaskWidth = 0x1;
        g_systemInfo.m_zen.m_ccxShiftWidth = g_systemInfo.m_zen.m_coreMaskWidth + g_systemInfo.m_zen.m_coreShiftWidth;

        g_systemInfo.m_zen.m_ccdShiftWidth = g_systemInfo.m_zen.m_ccxMaskWidth + g_systemInfo.m_zen.m_ccxShiftWidth;
        g_systemInfo.m_zen.m_ccdMaskWidth = 3;

        if (!isExtTopoAvailable)
        {
            g_systemInfo.m_zen.m_socketShiftWidth = g_systemInfo.m_zen.m_ccdShiftWidth + g_systemInfo.m_zen.m_ccdMaskWidth;
        }
    }
    else if (isZen3 || isZen4AndAbove)
    {
        ReadCPUIDEx(aCPUInfo, CPUID_FnCacheProperties, 3);

        threadsPerCcx = ((aCPUInfo[PWR_EAX_OFFSET] >> 14) & 0xFFF) + 1;
        coresPerCcx = g_systemInfo.m_zen.m_isSmtEnabled ? threadsPerCcx / 2 : threadsPerCcx;
        g_systemInfo.m_zen.m_coreMaskWidth = 0;

        DRVPRINT("Threads per ccx: %u", threadsPerCcx);
        DRVPRINT("Cores per ccx: %u", coresPerCcx);

        coresPerCcx--;

        if (coresPerCcx == 0)
        {
            coresPerCcx++;
        }

        while (coresPerCcx)
        {
            g_systemInfo.m_zen.m_coreMaskWidth++;
            coresPerCcx >>= 1;
        }

        g_systemInfo.m_zen.m_ccxMaskWidth = 0;
        g_systemInfo.m_zen.m_ccxShiftWidth = 0;

        g_systemInfo.m_zen.m_ccdMaskWidth = 0;
        ccxPerSocket = (g_systemInfo.m_zen.m_threadsPerSocket / threadsPerCcx) - 1;

        if (ccxPerSocket == 0)
        {
            ccxPerSocket++;
        }

        while (ccxPerSocket)
        {
            g_systemInfo.m_zen.m_ccdMaskWidth++;
            ccxPerSocket >>= 1;
        }

        if (isExtTopoAvailable)
        {
            g_systemInfo.m_zen.m_ccdShiftWidth = maskWidth - g_systemInfo.m_zen.m_ccdMaskWidth;
        }
        else
        {
            g_systemInfo.m_zen.m_ccdShiftWidth = g_systemInfo.m_zen.m_coreMaskWidth + g_systemInfo.m_zen.m_coreShiftWidth;
        }

        if (!isExtTopoAvailable)
        {
            g_systemInfo.m_zen.m_socketShiftWidth = g_systemInfo.m_zen.m_ccdShiftWidth + g_systemInfo.m_zen.m_ccdMaskWidth;
        }
    }

    DRVPRINT("coreMaskWidth(%u) coreShiftWidth(%u) ccxMaskWidth(%u) ccxShiftWidth(%u) ccdMaskWidth(%u) ccdShiftWidth(%u) socketMaskWidth(%u) socketShiftWidth(%u)",
             g_systemInfo.m_zen.m_coreMaskWidth, g_systemInfo.m_zen.m_coreShiftWidth,
             g_systemInfo.m_zen.m_ccxMaskWidth, g_systemInfo.m_zen.m_ccxShiftWidth,
             g_systemInfo.m_zen.m_ccdMaskWidth, g_systemInfo.m_zen.m_ccdShiftWidth,
             g_systemInfo.m_zen.m_socketMaskWidth, g_systemInfo.m_zen.m_socketShiftWidth);

    if (!PwrIsHyperVisor())
    {
        g_systemInfo.m_zen.m_pstateReg = ReadMSR(AMDT_PSTATE_BASE_REGISTER);
    }

    PwrSetExtPerfMonAndDbgInfo(&g_systemInfo);

    if (g_systemInfo.m_socketCount > 0)
    {
        for (cnt = 0; cnt < g_systemInfo.m_zen.m_totalThreads; cnt++)
        {
            if (isEpyc)
            {
                // TODO: This will fail for downcored/virtual instances on zen2
                socketId = (g_systemInfo.m_zen.m_apic[cnt].m_extdApic >> 6);
            }
            else if (isZen2 || isZen3 || isZen4AndAbove)
            {
                uint32 socketMask = 0;
                uint32 socketMaskWidth = g_systemInfo.m_zen.m_socketMaskWidth;

                while (socketMaskWidth)
                {
                    socketMask |= (1 << (socketMaskWidth - 1));
                    socketMaskWidth--;
                }

                socketId = (g_systemInfo.m_zen.m_apic[cnt].m_extdApic >> g_systemInfo.m_zen.m_socketShiftWidth) & socketMask;
            }

            if (g_systemInfo.m_zen.m_firstCore[socketId] == 0xFFFFFFFFUL)
            {
                g_systemInfo.m_zen.m_firstCore[socketId] = cnt;
                DRVPRINT("SOCKET CORE %d\n", cnt);
            }
        }
    }
}

void SetFirstBusIds(PTARGET_SYSTEM_INFO pTargetInfo)
{
    if (NULL != pTargetInfo)
    {
        uint32 cnt = 0;

        for (cnt = 0; cnt < pTargetInfo->m_socketCount; cnt++)
        {
            if (cnt < PWR_MAX_SOCKET_COUNT)
            {
                uint32 firstCoreOfSocket = pTargetInfo->m_zen.m_firstCore[cnt];

                if (firstCoreOfSocket < MAX_CORE_CNT)
                {
                    uint32 nodeId = pTargetInfo->m_zen.m_apic[firstCoreOfSocket].m_nodeId;
                    uint32 dev = 0x18U + nodeId;
                    uint32 func = 0x0U;
                    uint32 offset = pTargetInfo->m_zen.m_isZen4AndAbove ? 0xC04 : 0x84U;
                    pTargetInfo->m_zen.m_mmio[cnt].m_bus = ReadPCIDev(0x0U, dev, func, offset);
                    pTargetInfo->m_zen.m_mmio[cnt].m_threadId = pTargetInfo->m_zen.m_firstCore[cnt];
                    DRVPRINT("Info: core %d busId 0x%x \n", pTargetInfo->m_zen.m_mmio[cnt].m_threadId, pTargetInfo->m_zen.m_mmio[cnt].m_bus);
                }
                else
                {
                    DRVPRINT("Invalid CoreId(%lu) for Socket(%lu).", firstCoreOfSocket, cnt);
                }
            }
            else
            {
                DRVPRINT("Invalid socketId(&lu)", cnt);
            }
        }
    }
}

// GetTargetSystemInfo: Get the target system info
void GetTargetSystemInfo(PTARGET_SYSTEM_INFO* pTargetInfo)
{
    if (NULL == g_pSystemInfo)
    {
        uint32 platformId = PwrGetTargetPlatformId();
        memset(&g_systemInfo, 0, sizeof(TARGET_SYSTEM_INFO));
        g_systemInfo.m_isAmd = PwrIsAMDPlatform();
        GetCpuModelFamily(&g_systemInfo.m_family, &g_systemInfo.m_model);
        g_systemInfo.m_isZen = (0x17 <= g_systemInfo.m_family);
        g_systemInfo.m_platformId = platformId;
        g_systemInfo.m_socketCount = 1;

        if (1 == g_systemInfo.m_isAmd)
        {
            g_systemInfo.m_socketType = PwrGetSocketType();
            g_systemInfo.m_isCefAvailable = IsCefSupported();
            g_systemInfo.m_isGuest = PwrIsHyperVisor();
        }

        if (g_systemInfo.m_isZen)
        {
            GetZenSystemInfo();
            SetFirstBusIds(&g_systemInfo);
        }
        else if (PLATFORM_INVALID != platformId)
        {
            uint32 data = 0;
            int cnt = 0;
            // Other AMD supported platforms for Power profiler
            // Get compute unit count
            g_systemInfo.m_1516.m_coreCount = GetTargetCoreCount();

            // Get compute unit count ONLY FOR SUPPORTED AMD APU
            data = ReadPCIDev(0x0U, 0x18U, 0x5U, 0x80U);

            if (1 == g_systemInfo.m_1516.m_coreCount)
            {
                g_systemInfo.m_1516.m_cuCount = 1;
                g_systemInfo.m_1516.m_coresPerCu = 1;
            }
            else if (PLATFORM_MULLINS == g_systemInfo.m_platformId)
            {
                // Mullins has only one compute unit. Refer D1F5x80 Compute Unit Status 1
                g_systemInfo.m_1516.m_cuCount = 1;
                g_systemInfo.m_1516.m_coresPerCu = g_systemInfo.m_1516.m_coreCount;
            }
            else
            {
                DecodeCURegisterStatus(data,
                                       &g_systemInfo.m_1516.m_cuCount,
                                       &g_systemInfo.m_1516.m_coresPerCu);
            }

            g_systemInfo.m_1516.m_isIgpuAvailable = PwrIsIGPUAvailable();

            // P-state state
            for (cnt = 0; cnt < AMDT_MAX_PSTATES; cnt++)
            {
                if (!PwrIsHyperVisor())
                {
                    g_systemInfo.m_1516.m_pstateTable[cnt] = ReadMSR(AMDT_PSTATE_BASE_REGISTER + cnt);
                }
            }
        }
        else
        {
            // For non amd processors
            g_systemInfo.m_nonAmd.m_cores = GetTargetCoreCount();
        }

        g_pSystemInfo = &g_systemInfo;
    }

    *pTargetInfo = g_pSystemInfo;
}

// PwrGetSetBitIndex: Get the index of nth set set
uint32 PwrGetSetBitIndex(uint32 setBitId, uint32 bitMask)
{
    uint32 cnt = 0;
    uint32 setBitInstance = 0;
    uint32 pos = 0;

    for (cnt = 0; cnt < 32; cnt++)
    {
        if (bitMask & (1 << cnt))
        {
            setBitInstance++;
        }

        if (setBitInstance == setBitId)
        {
            pos = cnt;
            break;
        }
    }

    return pos;
}

// Note: Return accurate values for Zen 2 and Zen 3
uint32_t GetCcxCount()
{
    uint32_t ccxCnt = 0;
    uint32_t i = 0;
    uint32_t j = 0;
    PTARGET_SYSTEM_INFO pInfo = NULL;
    uint32_t ccxShiftWidth = 0;

    GetTargetSystemInfo(&pInfo);

    // Count the number of distinct apic ids at ccx level
    if (pInfo->m_zen.m_isZen2)
    {
        ccxShiftWidth = pInfo->m_zen.m_ccxShiftWidth;
    }
    // ccd = ccx for Zen3
    else if (pInfo->m_zen.m_isZen3 || pInfo->m_zen.m_isZen4AndAbove)
    {
        ccxShiftWidth = pInfo->m_zen.m_ccdShiftWidth;
    }

    // There will be atlest one distinct element
    ccxCnt = 1;

    for (i = 1; i < MAX_CORE_CNT; i++)
    {
        for (j = 0; j < i; j++)
        {
            if (pInfo->m_zen.m_apic[i].m_extdApic >> ccxShiftWidth ==
                pInfo->m_zen.m_apic[j].m_extdApic >> ccxShiftWidth)
            {
                break;
            }
        }

        if (i == j)
        {
            ccxCnt++;
        }
    }

    return ccxCnt;
}

uint32 GetSocketCount()
{
    PTARGET_SYSTEM_INFO pInfo = NULL;

    GetTargetSystemInfo(&pInfo);

    return pInfo->m_socketCount;
}

uint32_t GetZenVersion()
{
    uint32_t zenVer = 0;
    PTARGET_SYSTEM_INFO pInfo = NULL;

    GetTargetSystemInfo(&pInfo);

    if (pInfo->m_zen.m_isZen2)
    {
        zenVer = (uint32_t)PWR_ZEN2;
    }
    else if (pInfo->m_zen.m_isZen3)
    {
        zenVer = (uint32_t)PWR_ZEN3;
    }
    else if (pInfo->m_zen.m_isZen4AndAbove)
    {
        zenVer = (uint32_t)PWR_ZEN4;
    }

    return zenVer;
}

uint32_t GetNodeIdForCore(uint32_t coreId)
{
    uint32_t nodeId = 0;
    PTARGET_SYSTEM_INFO pInfo = NULL;

    GetTargetSystemInfo(&pInfo);

    if (coreId < MAX_CORE_CNT)
    {
        nodeId = pInfo->m_zen.m_apic[coreId].m_nodeId;
    }

    return nodeId;
}

uint32_t GetSocketIdForCore(uint32_t coreId)
{
    uint32_t socketId = 0;
    PTARGET_SYSTEM_INFO pInfo = NULL;

    GetTargetSystemInfo(&pInfo);

    if (coreId < MAX_CORE_CNT)
    {
        socketId = pInfo->m_zen.m_apic[coreId].m_extdApic >> pInfo->m_zen.m_socketShiftWidth &
                   ~(0xFFFFFFFFU << pInfo->m_zen.m_socketMaskWidth);
    }
    else
    {
        DRVPRINT("Invalid core id(%d)", coreId);
    }

    return socketId;
}
